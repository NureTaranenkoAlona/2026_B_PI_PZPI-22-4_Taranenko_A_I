import { useAppLanguage } from '../context/AppLanguageContext';

function NotFoundPage() {
  const { t } = useAppLanguage();
  return <h2>{t('miscUi.notFound')}</h2>;
}

export default NotFoundPage;
