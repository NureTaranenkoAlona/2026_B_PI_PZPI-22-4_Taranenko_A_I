import { useState } from 'react';
import { Eye, EyeOff, MessageCircle, ArrowRight } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAppLanguage } from '../context/AppLanguageContext';
import { verifyTwoFactorLogin } from '../api/authApi';
import useNotifications from '../hooks/useNotifications';
import useSystemTheme from '../hooks/useSystemTheme';
import getApiErrorMessage from '../utils/getApiErrorMessage';

function getLoginDestination(user) {
  if (user?.isOnboardingCompleted) {
    return { path: '/chats' };
  }

  if (user?.onboardingWorkspaceChoice === 'joined' || user?.onboardingWorkspaceChoice === 'created') {
    return {
      path: '/onboarding',
      state: {
        workspaceChoice: user.onboardingWorkspaceChoice,
      },
    };
  }

  return {
    path: '/post-login',
    state: {
      email: user?.email,
    },
  };
}

function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  useSystemTheme();
  const { login, finalizeAuthenticatedUser } = useAuth();
  const { playLoginSound } = useNotifications();
  const { t } = useAppLanguage();

  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState(() => location.state?.successMessage || '');
  const [form, setForm] = useState({
    email: location.state?.email || '',
    password: '',
    twoFactorCode: '',
  });
  const [errors, setErrors] = useState({});
  const [twoFactorChallenge, setTwoFactorChallenge] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: '',
      form: '',
      twoFactorCode: '',
    }));
    setSuccessMessage('');
  };

  const validateEmail = (value) => {
    const trimmed = value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!trimmed) return 'Email is required.';
    if (trimmed.length > 254) return 'Email is too long.';
    if (!trimmed.includes('@')) return 'Email must contain @.';
    if (!emailRegex.test(trimmed)) return 'Enter a valid email address.';

    return '';
  };

  const validatePassword = (value) => {
    if (!value.trim()) return 'Password is required.';
    return '';
  };

  const validateForm = () => {
    const newErrors = {
      email: validateEmail(form.email),
      password: validatePassword(form.password),
    };

    setErrors(newErrors);

    return !Object.values(newErrors).some(Boolean);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isSubmitting) return;
    if (!validateForm()) return;

    const submitLogin = async () => {
      setIsSubmitting(true);
      setErrors((prev) => ({ ...prev, form: '' }));

      try {
        const response = await login({
          email: form.email.trim().toLowerCase(),
          password: form.password,
        });

        if (response?.requiresTwoFactor) {
          setTwoFactorChallenge({
            tempToken: response.tempToken,
            email: response.user?.email || form.email.trim().toLowerCase(),
          });
          setForm((prev) => ({ ...prev, password: '', twoFactorCode: '' }));
          setSuccessMessage('');
          return;
        }

        const { user } = response;

        playLoginSound();

        const redirectParam = new URLSearchParams(location.search).get('redirect');
        if (redirectParam) {
          navigate(redirectParam, { replace: true });
          return;
        }

        const destination = getLoginDestination(user);
        navigate(destination.path, {
          replace: true,
          ...(destination.state ? { state: destination.state } : {}),
        });
      } catch (error) {
        const apiMessage =
          error.message === 'TOKEN_MISSING'
            ? 'Server did not return an authentication token.'
            : getApiErrorMessage(error, 'Unable to sign in. Please try again.');
        const message =
          apiMessage === 'Please verify your email before logging in.'
            ? 'Please verify your email before logging in.'
            : apiMessage;

        setErrors((prev) => ({
          ...prev,
          form: message,
        }));
      } finally {
        setIsSubmitting(false);
      }
    };

    submitLogin();
  };

  const handleVerifyTwoFactor = async (e) => {
    e.preventDefault();

    if (isSubmitting || !twoFactorChallenge) return;

    const code = form.twoFactorCode.trim();
    if (!code) {
      setErrors((prev) => ({ ...prev, twoFactorCode: 'Authentication code is required.' }));
      return;
    }

    setIsSubmitting(true);
    setErrors((prev) => ({ ...prev, form: '', twoFactorCode: '' }));

    try {
      const response = await verifyTwoFactorLogin({
        tempToken: twoFactorChallenge.tempToken,
        code,
      });

      const { user } = await finalizeAuthenticatedUser(response);
      setTwoFactorChallenge(null);
      setForm((prev) => ({ ...prev, twoFactorCode: '' }));

      playLoginSound();

      const redirectParam = new URLSearchParams(location.search).get('redirect');
      if (redirectParam) {
        navigate(redirectParam, { replace: true });
        return;
      }

      const destination = getLoginDestination(user);
      navigate(destination.path, {
        replace: true,
        ...(destination.state ? { state: destination.state } : {}),
      });
    } catch (error) {
      setErrors((prev) => ({
        ...prev,
        form: getApiErrorMessage(error, 'Unable to verify authentication code.'),
      }));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 py-8 sm:px-6 lg:px-8 bg-[#F5F6FA] dark:bg-[#181A20] transition-colors">
      <div className="w-full max-w-md">
        <div className="bg-white/85 dark:bg-[#1C1F26]/95 backdrop-blur-sm border border-indigo-100 dark:border-[#2F3440] rounded-2xl shadow-xl shadow-indigo-100/50 dark:shadow-none px-5 py-8 sm:px-8 sm:py-10 transition-colors">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center mb-4">
              <MessageCircle className="w-7 h-7 text-white" fill="white" strokeWidth={1.5} />
            </div>
            <h1 className="text-foreground tracking-tight text-center">Dialogly</h1>
            <p className="text-muted-foreground text-center mt-1 max-w-xs" style={{ fontSize: '0.9rem' }}>
              {t('auth.appTagline')}
            </p>
          </div>

          <h2 className="text-foreground mb-6 text-center sm:text-left">
            {twoFactorChallenge ? t('auth.twoFactorTitle') : t('auth.signInTitle')}
          </h2>

          {successMessage && (
            <p className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-300">
              {successMessage}
            </p>
          )}

          <form onSubmit={twoFactorChallenge ? handleVerifyTwoFactor : handleSubmit} className="flex flex-col gap-4">
            {twoFactorChallenge ? (
              <>
                <p className="text-sm text-muted-foreground">
                  {t('auth.twoFactorDescription', { email: twoFactorChallenge.email })}
                </p>

                <div className="flex flex-col gap-1.5">
                  <label htmlFor="twoFactorCode" style={{ fontSize: '0.875rem' }}>
                    {t('auth.authenticationCode')}
                  </label>
                  <input
                    id="twoFactorCode"
                    name="twoFactorCode"
                    type="text"
                    inputMode="numeric"
                    placeholder="123456"
                    value={form.twoFactorCode}
                    onChange={handleChange}
                    className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                  />
                  {errors.twoFactorCode && <p className="text-destructive text-sm">{errors.twoFactorCode}</p>}
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="mt-2 w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white py-3 rounded-xl shadow-md shadow-indigo-200 dark:shadow-none transition-all duration-200"
                >
                  {isSubmitting ? t('auth.verifying') : t('auth.verifyCode')}
                  <ArrowRight className="w-4 h-4" />
                </button>
                {errors.form && <p className="text-destructive text-sm">{errors.form}</p>}

                <button
                  type="button"
                  onClick={() => {
                    setTwoFactorChallenge(null);
                    setForm((prev) => ({ ...prev, password: '', twoFactorCode: '' }));
                    setErrors({});
                  }}
                  className="text-sm text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors"
                >
                  {t('auth.backToSignIn')}
                </button>
              </>
            ) : (
              <>
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" style={{ fontSize: '0.875rem' }}>
                {t('auth.email')}
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                placeholder={t('auth.emailPlaceholder')}
                value={form.email}
                onChange={handleChange}
                className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
              />
              {errors.email && <p className="text-destructive text-sm">{errors.email}</p>}
            </div>

            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label htmlFor="password" style={{ fontSize: '0.875rem' }}>
                  {t('auth.password')}
                </label>
                <Link
                  to="/forgot-password"
                  className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors"
                  style={{ fontSize: '0.8rem' }}
                >
                  {t('auth.forgotPasswordLink')}
                </Link>
              </div>

              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={handleChange}
                  className="w-full min-w-0 px-4 py-2.5 pr-11 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                />
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && <p className="text-destructive text-sm">{errors.password}</p>}
            </div>

            <label className="flex items-center gap-3 cursor-pointer group mt-1">
              <div
                onClick={() => setRememberMe(!rememberMe)}
                className={`w-5 h-5 flex-shrink-0 rounded-md border-2 flex items-center justify-center transition-all ${
                  rememberMe
                    ? 'bg-indigo-600 border-indigo-600'
                    : 'bg-white dark:bg-[#232833] border-border group-hover:border-indigo-400'
                }`}
              >
                {rememberMe && <span className="w-2.5 h-2.5 rounded-sm bg-white" />}
              </div>

              <span className="text-muted-foreground select-none" style={{ fontSize: '0.875rem' }}>
                {t('auth.rememberMe')}
              </span>
            </label>

            <button
              type="submit"
              disabled={isSubmitting}
              className="mt-2 w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white py-3 rounded-xl shadow-md shadow-indigo-200 dark:shadow-none transition-all duration-200"
            >
              {isSubmitting ? 'Signing in...' : t('auth.signIn')}
              <ArrowRight className="w-4 h-4" />
            </button>
            {errors.form && <p className="text-destructive text-sm">{errors.form}</p>}
              </>
            )}
          </form>

          <p className="text-center text-muted-foreground mt-6" style={{ fontSize: '0.875rem' }}>
            {t('auth.dontHaveAccount')}{' '}
            <Link
              to="/register"
              className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors"
            >
              {t('auth.signUp')}
            </Link>
          </p>
        </div>

        <div className="mt-5 text-center text-muted-foreground/60" style={{ fontSize: '0.78rem' }}>
          <p>
            © 2026 Dialogly ·{' '}
            <Link to="/terms" target="_blank" rel="noreferrer" className="hover:text-indigo-600 transition-colors">
              {t('auth.termsShort')}
            </Link>{' '}
            ·{' '}
            <Link to="/privacy" target="_blank" rel="noreferrer" className="hover:text-indigo-600 transition-colors">
              {t('auth.privacyShort')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
