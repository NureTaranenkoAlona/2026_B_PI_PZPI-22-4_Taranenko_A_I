import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Users } from 'lucide-react';
import { acceptWorkspaceInvite, validateWorkspaceInvite } from '../api/workspaceApi';
import { useAccountContext } from '../context/AccountContext';
import { useAppLanguage } from '../context/AppLanguageContext';
import { useAuth } from '../context/AuthContext';
import useSystemTheme from '../hooks/useSystemTheme';
import getApiErrorMessage from '../utils/getApiErrorMessage';

function JoinWorkspacePage() {
  useSystemTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { isAuthenticated, isAuthLoading, refreshCurrentUser } = useAuth();
  const { refreshContexts } = useAccountContext();
  const { t } = useAppLanguage();
  const code = (searchParams.get('code') || '').trim();

  const [invite, setInvite] = useState(null);
  const [isLoadingInvite, setIsLoadingInvite] = useState(true);
  const [isAccepting, setIsAccepting] = useState(false);
  const [pageError, setPageError] = useState('');

  const redirectTo = useMemo(
    () => `${location.pathname}${location.search}`,
    [location.pathname, location.search]
  );

  useEffect(() => {
    const loadInvite = async () => {
      if (!code) {
        setInvite({ isValid: false });
        setIsLoadingInvite(false);
        return;
      }

      setIsLoadingInvite(true);
      setPageError('');
      try {
        const response = await validateWorkspaceInvite(code);
        setInvite(response);
      } catch (error) {
        setPageError(getApiErrorMessage(error, 'Unable to verify invite link.'));
      } finally {
        setIsLoadingInvite(false);
      }
    };

    loadInvite();
  }, [code]);

  useEffect(() => {
    if (isAuthLoading || !invite?.isValid || isAuthenticated) return;

    navigate(`/login?redirect=${encodeURIComponent(redirectTo)}`, { replace: true });
  }, [invite?.isValid, isAuthLoading, isAuthenticated, navigate, redirectTo]);

  const handleAccept = async () => {
    if (!code) return;

    setIsAccepting(true);
    setPageError('');

    try {
      await acceptWorkspaceInvite(code);
      await refreshCurrentUser();
      await refreshContexts();
      navigate('/chats', { replace: true });
    } catch (error) {
      setPageError(getApiErrorMessage(error, 'Unable to accept workspace invitation.'));
    } finally {
      setIsAccepting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6FA] dark:bg-[#181A20] flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-xl rounded-[28px] border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] shadow-xl shadow-slate-200/40 dark:shadow-black/20 overflow-hidden">
        <div className="px-6 py-5 border-b border-[#F3F4F6] dark:border-[#2F3440] flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-[#EEF0FE] dark:bg-[#232842] text-[#5B6CF8] flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-[#1A1D23] dark:text-white">{t('join.title')}</h1>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">
              {t('join.description')}
            </p>
          </div>
        </div>

        <div className="p-6 space-y-5">
          {pageError && (
            <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
              {pageError}
            </div>
          )}

          {isLoadingInvite ? (
            <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] px-4 py-8 text-center text-sm text-[#6B7280] dark:text-[#9CA3AF]">
              {t('join.verifyingInvite')}
            </div>
          ) : invite?.isValid ? (
            <>
              <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-5 space-y-3">
                <div>
                  <p className="text-xs uppercase tracking-wider text-[#9CA3AF] mb-1">{t('join.workspace')}</p>
                  <p className="text-sm text-[#1A1D23] dark:text-white">{invite.workspaceName}</p>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-[#9CA3AF] mb-1">{t('join.role')}</p>
                  <p className="text-sm text-[#1A1D23] dark:text-white">{invite.role}</p>
                </div>
              </div>

              {isAuthenticated ? (
                <button
                  type="button"
                  onClick={handleAccept}
                  disabled={isAccepting}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-[var(--dialogly-accent)] text-white hover:bg-[var(--dialogly-accent-hover)] transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {isAccepting ? t('join.acceptingInvitation') : t('join.acceptInvitation')}
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <div className="rounded-2xl border border-[#D9DEFE] dark:border-[#39427A] bg-[#F5F7FF] dark:bg-[#202746] px-4 py-3 text-sm text-[#3F4B7A] dark:text-[#C7D0F4]">
                  {t('join.redirectingToSignIn')}
                </div>
              )}
            </>
          ) : (
            <div className="rounded-2xl border border-dashed border-[#D1D5DB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] px-4 py-8 text-center">
              <CheckCircle2 className="w-10 h-10 mx-auto text-[#9CA3AF] mb-3" />
              <p className="text-sm text-[#1A1D23] dark:text-white mb-1">{t('join.invalidInviteTitle')}</p>
              <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                {t('join.invalidInviteDescription')}
              </p>
            </div>
          )}

          <div className="text-center">
            <Link
              to={isAuthenticated ? '/chats' : '/login'}
              className="text-sm text-[#6B7280] hover:text-[#1A1D23] dark:text-[#9CA3AF] dark:hover:text-white transition-colors"
            >
              {isAuthenticated ? t('common.backToChats') : t('join.backToLogin')}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default JoinWorkspacePage;
