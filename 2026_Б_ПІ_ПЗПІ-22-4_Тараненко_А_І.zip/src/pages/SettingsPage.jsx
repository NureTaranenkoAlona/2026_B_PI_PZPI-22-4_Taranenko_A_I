import { useEffect, useMemo, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import {
  User,
  Building2,
  Plug,
  Bell,
  Palette,
  Globe,
  Shield,
  ArrowLeft,
  ChevronRight,
  Users,
} from 'lucide-react';

import AppLogo from '../components/common/AppLogo';
import ProfileSettings from '../components/settings/ProfileSettings';
import WorkspaceSettings from '../components/settings/WorkspaceSettings';
import IntegrationsSettings from '../components/settings/IntegrationsSettings';
import NotificationsSettings from '../components/settings/NotificationsSettings';
import AppearanceSettings from '../components/settings/AppearanceSettings';
import LanguageSettings from '../components/settings/LanguageSettings';
import SecuritySettings from '../components/settings/SecuritySettings';
import AccountsSettings from '../components/settings/AccountsSettings';
import { useAppLanguage } from '../context/AppLanguageContext';
import { getProfileInitials, getStoredProfile, profileUpdatedEvent } from '../utils/profileStorage';
import AccountSwitcher from '../components/account/AccountSwitcher';
import { useAuth } from '../context/AuthContext';
import { updateCurrentUserSettings } from '../api/userApi';

const NAV_ITEMS = [
  { id: 'accounts', labelKey: 'nav.accounts', icon: Users, group: 'personal' },
  { id: 'profile', labelKey: 'nav.profile', icon: User, group: 'personal' },
  { id: 'workspace', labelKey: 'nav.workspace', icon: Building2, group: 'workspace' },
  { id: 'integrations', labelKey: 'nav.integrations', icon: Plug, group: 'workspace', badge: '2' },
  { id: 'notifications', labelKey: 'nav.notifications', icon: Bell, group: 'preferences' },
  { id: 'appearance', labelKey: 'nav.appearance', icon: Palette, group: 'preferences' },
  { id: 'language', labelKey: 'nav.language', icon: Globe, group: 'preferences' },
  { id: 'security', labelKey: 'nav.security', icon: Shield, group: 'security' },
];

const GROUP_LABELS = {
  personal: 'groups.personal',
  workspace: 'groups.workspace',
  preferences: 'groups.preferences',
  security: 'groups.security',
};

const TAB_TITLES = {
  profile: {
    title: 'tabs.profileTitle',
    description: 'tabs.profileDescription',
  },
  accounts: {
    title: 'settingsUi.accountsTitle',
    description: 'settingsUi.accountsDescription',
  },
  workspace: {
    title: 'tabs.workspaceTitle',
    description: 'tabs.workspaceDescription',
  },
  integrations: {
    title: 'tabs.integrationsTitle',
    description: 'tabs.integrationsDescription',
  },
  notifications: {
    title: 'tabs.notificationsTitle',
    description: 'tabs.notificationsDescription',
  },
  appearance: {
    title: 'tabs.appearanceTitle',
    description: 'tabs.appearanceDescription',
  },
  language: {
    title: 'tabs.languageTitle',
    description: 'tabs.languageDescription',
  },
  security: {
    title: 'tabs.securityTitle',
    description: 'tabs.securityDescription',
  },
};

const PANELS = {
  accounts: <AccountsSettings />,
  profile: <ProfileSettings />,
  workspace: <WorkspaceSettings />,
  integrations: <IntegrationsSettings />,
  notifications: <NotificationsSettings />,
  appearance: <AppearanceSettings />,
  language: <LanguageSettings />,
  security: <SecuritySettings />,
};

function NavGroup({ group, items, active, onSelect, t, isRTL }) {
  return (
    <div>
      <p className={`px-4 mb-1 text-[10px] uppercase tracking-widest text-[#9CA3AF] ${isRTL ? 'text-right' : ''}`}>
        {t(GROUP_LABELS[group])}
      </p>

      <div className="space-y-0.5">
        {items.map((item) => {
          const isActive = active === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onSelect(item.id)}
              style={{
                paddingInline: 'var(--dialogly-density-sidebar-item-x)',
                paddingBlock: 'calc(var(--dialogly-density-sidebar-item-y) - 2px)',
              }}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-colors group relative ${
                isRTL ? 'flex-row-reverse text-right' : 'text-left'
              } ${
                isActive
                  ? 'bg-[var(--dialogly-accent-soft)] text-[var(--dialogly-accent)] dark:bg-[var(--dialogly-accent-soft-dark)]'
                  : 'text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F5F6FA] dark:hover:bg-[#232833] hover:text-[#1A1D23] dark:hover:text-white'
              }`}
            >
              <Icon
                className={`w-4 h-4 flex-shrink-0 transition-colors ${
                  isActive ? 'text-[var(--dialogly-accent)]' : 'text-[#9CA3AF] group-hover:text-[#6B7280]'
                }`}
              />
              <span className="flex-1 text-sm">{item.label || t(item.labelKey)}</span>

              {item.badge && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                    isActive
                      ? 'bg-[var(--dialogly-accent)] text-white'
                      : 'bg-[#E5E7EB] dark:bg-[#343842] text-[#6B7280] dark:text-[#9CA3AF]'
                  }`}
                >
                  {item.badge}
                </span>
              )}

              {isActive && (
                <ChevronRight className="w-3.5 h-3.5 text-[var(--dialogly-accent)] flex-shrink-0" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function SettingsPage() {
  const [profile, setProfile] = useState(() => getStoredProfile());
  const navigate = useNavigate();
  const { tab } = useParams();
  const { t, isRTL } = useAppLanguage();
  const { logout } = useAuth();

  const validTabs = useMemo(() => NAV_ITEMS.map((item) => item.id), []);
  const activeTab = validTabs.includes(tab || '') ? tab : 'profile';

  useEffect(() => {
    const handleProfileUpdate = (event) => {
      setProfile(event.detail || getStoredProfile());
    };

    window.addEventListener(profileUpdatedEvent, handleProfileUpdate);

    return () => {
      window.removeEventListener(profileUpdatedEvent, handleProfileUpdate);
    };
  }, []);

  const groups = [...new Set(NAV_ITEMS.map((item) => item.group))];
  const { title, description } = TAB_TITLES[activeTab];
  const resolveTabCopy = (value) => (typeof value === 'string' && value.includes('.') ? t(value) : value);
  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const handleRestartTour = async () => {
    try {
      await updateCurrentUserSettings({ isTourCompleted: false });
    } finally {
      navigate('/chats?tour=1');
    }
  };

  const handleSelectTab = (tabId) => {
    navigate(`/settings/${tabId}`);
  };

  if (tab && !validTabs.includes(tab)) {
    return <Navigate to="/settings/profile" replace />;
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-[#F5F6FA] dark:bg-[#181A20]">
      <div className="flex-shrink-0 min-h-14 bg-white dark:bg-[#1C1F26] border-b border-[#E5E7EB] dark:border-[#2F3440] flex items-center px-4 sm:px-6 gap-4">
        <button
          onClick={() => navigate('/chats')}
          className="flex items-center gap-2 text-sm text-[#6B7280] hover:text-[#1A1D23] dark:text-[#9CA3AF] dark:hover:text-white transition-colors group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          {t('common.backToChats')}
        </button>

        <div className="w-px h-5 bg-[#E5E7EB] dark:bg-[#2F3440]" />

        <div className="flex items-center gap-3 min-w-0">
          <AppLogo size={28} iconSize={13} />
          <div className="min-w-0">
            <p className="text-sm text-[#1A1D23] dark:text-white">Dialogly</p>
            <p className="text-xs text-[#9CA3AF] truncate">{`Dialogly / ${t('common.settings')}`}</p>
          </div>
        </div>

        <div className="ml-auto">
          <div className="flex items-center gap-2">
            <AccountSwitcher />
            <button
              type="button"
              onClick={handleLogout}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-sm text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors"
            >
              {t('settingsUi.signOut')}
            </button>
            <Link
              to="/team"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-sm text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors"
            >
              <Users className="w-4 h-4" />
              {t('settingsUi.team')}
            </Link>
          </div>
        </div>
      </div>

      <div className={`flex-1 flex overflow-hidden ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`w-64 flex-shrink-0 h-full flex flex-col bg-white dark:bg-[#1C1F26] ${isRTL ? 'border-l' : 'border-r'} border-[#E5E7EB] dark:border-[#2F3440] py-5 overflow-y-auto`}>
          <div className="px-4 mb-5 pb-5 border-b border-[#F3F4F6] dark:border-[#2F3440]">
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse text-right' : ''}`}>
              <div className="w-10 h-10 rounded-full bg-[var(--dialogly-accent)] flex items-center justify-center text-white text-sm flex-shrink-0 overflow-hidden">
                {profile.avatar ? (
                  <img src={profile.avatar} alt="User avatar" className="w-full h-full object-cover" />
                ) : (
                  getProfileInitials(profile)
                )}
              </div>
              <div className="min-w-0">
                <p className="text-sm text-[#1A1D23] dark:text-white truncate">
                  {`${profile.firstName} ${profile.lastName}`.trim() || t('common.yourAccount')}
                </p>
                <p className="text-xs text-[#9CA3AF] truncate">{profile.email}</p>
              </div>
            </div>
          </div>

          <div className="flex-1 px-3 space-y-5">
            {groups.map((group) => (
              <NavGroup
                key={group}
                group={group}
                items={NAV_ITEMS.filter((item) => item.group === group)}
                active={activeTab}
                onSelect={handleSelectTab}
                t={t}
                isRTL={isRTL}
              />
            ))}
          </div>
        </div>

        <div
          className={`flex-1 overflow-y-auto ${isRTL ? 'text-right' : ''}`}
          style={{ padding: 'var(--dialogly-density-page-padding)' }}
        >
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <h1 className="text-[#1A1D23] dark:text-white">{resolveTabCopy(title)}</h1>
                  <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mt-1">
                    {resolveTabCopy(description)}
                  </p>
                </div>

                {activeTab === 'profile' && (
                  <button
                    type="button"
                    onClick={handleRestartTour}
                    className="inline-flex items-center justify-center rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] px-4 py-2 text-sm text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors"
                  >
                    {t('settingsUi.takeTour')}
                  </button>
                )}
              </div>
            </div>

            {PANELS[activeTab]}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SettingsPage;
