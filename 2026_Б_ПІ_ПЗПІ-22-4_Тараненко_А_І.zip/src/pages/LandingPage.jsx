import { ArrowRight, CheckCircle2, MessageCircleMore, Users, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import AppLogo from '../components/common/AppLogo';
import { useAppLanguage } from '../context/AppLanguageContext';

function FeatureCard({ icon: Icon, title, description }) {
  return (
    <div className="rounded-3xl border border-[#D9DDF8] bg-white/88 p-6 shadow-[0_18px_45px_rgba(91,108,248,0.08)] backdrop-blur-sm transition-transform duration-200 hover:-translate-y-0.5 dark:border-[#343B63] dark:bg-[#171B26]/92 dark:shadow-none">
      <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#5b6cf8_0%,#7c3aed_100%)] text-white">
        <Icon className="h-5 w-5" />
      </div>
      <h3 className="mt-5 text-lg font-semibold text-[#151827] dark:text-white">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-[#5F6475] dark:text-[#AAB0C5]">{description}</p>
    </div>
  );
}

function HeroIllustration({ t }) {
  return (
    <div className="relative mx-auto w-full max-w-[560px]">
      <div className="absolute -left-8 top-8 h-32 w-32 rounded-full bg-[#7C3AED]/20 blur-3xl" />
      <div className="absolute -right-6 bottom-4 h-40 w-40 rounded-full bg-[#5B6CF8]/20 blur-3xl" />

      <div className="relative overflow-hidden rounded-[32px] border border-white/50 bg-white/90 p-4 shadow-[0_28px_80px_rgba(47,65,133,0.18)] backdrop-blur dark:border-[#343B63] dark:bg-[#151925]/92 dark:shadow-none">
        <div className="flex items-center justify-between rounded-2xl bg-[#F6F7FF] px-4 py-3 dark:bg-[#1E2434]">
              <div className="flex items-center gap-3">
                <AppLogo size={38} iconSize={17} className="rounded-xl" />
                <div>
                  <p className="text-sm font-semibold text-[#151827] dark:text-white">{t('landing.heroWorkspace')}</p>
                  <p className="text-xs text-[#7A8093] dark:text-[#97A0B8]">{t('landing.heroWorkspaceSubtitle')}</p>
                </div>
              </div>
              <div className="rounded-full bg-[#E9EEFF] px-3 py-1 text-xs font-medium text-[#4D5CE6] dark:bg-[#27304A] dark:text-[#CBD5FF]">
                {t('landing.heroLive')}
              </div>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-[210px_minmax(0,1fr)]">
          <div className="space-y-3 rounded-2xl bg-[#F7F8FC] p-3 dark:bg-[#1A1F2B]">
            {[
              { name: 'Telegram', preview: t('landing.heroPreviewTelegram'), accent: 'bg-[#2AABEE]' },
              { name: 'Messenger', preview: t('landing.heroPreviewMessenger'), accent: 'bg-[#0084FF]' },
              { name: 'Instagram', preview: t('landing.heroPreviewInstagram'), accent: 'bg-[#C13584]' },
            ].map((item) => (
              <div
                key={item.name}
                className="flex items-center gap-3 rounded-2xl border border-[#E6E9F5] bg-white px-3 py-3 dark:border-[#2A3042] dark:bg-[#131823]"
              >
                <div className={`h-9 w-9 rounded-2xl ${item.accent}`} />
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-[#151827] dark:text-white">{item.name}</p>
                  <p className="truncate text-xs text-[#7A8093] dark:text-[#97A0B8]">{item.preview}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-2xl bg-[linear-gradient(180deg,#F9FAFF_0%,#EEF2FF_100%)] p-4 dark:bg-[linear-gradient(180deg,#181D29_0%,#121722_100%)]">
            <div className="flex items-start gap-3">
              <div className="mt-1 flex h-10 w-10 items-center justify-center rounded-2xl bg-[#5B6CF8] text-white">
                <MessageCircleMore className="h-5 w-5" />
              </div>
              <div className="rounded-2xl bg-white px-4 py-3 shadow-sm dark:bg-[#202635]">
                <p className="text-sm font-medium text-[#151827] dark:text-white">{t('landing.heroBubbleTitle')}</p>
                <p className="mt-1 text-sm text-[#5F6475] dark:text-[#AAB0C5]">
                  {t('landing.heroBubbleDescription')}
                </p>
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <div className="max-w-[78%] rounded-2xl bg-[linear-gradient(135deg,#5b6cf8_0%,#7c3aed_100%)] px-4 py-3 text-sm text-white shadow-[0_16px_35px_rgba(91,108,248,0.22)]">
                {t('landing.heroReplyBubble')}
              </div>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-3">
              <div className="rounded-2xl bg-white/92 p-3 dark:bg-[#202635]">
                <div className="h-2 w-16 rounded-full bg-[#D7DEFF]" />
                <div className="mt-3 h-8 rounded-xl bg-[#EEF2FF] dark:bg-[#2B3245]" />
              </div>
              <div className="rounded-2xl bg-white/92 p-3 dark:bg-[#202635]">
                <div className="h-2 w-12 rounded-full bg-[#D7DEFF]" />
                <div className="mt-3 h-8 rounded-xl bg-[#EEF2FF] dark:bg-[#2B3245]" />
              </div>
              <div className="rounded-2xl bg-white/92 p-3 dark:bg-[#202635]">
                <div className="h-2 w-10 rounded-full bg-[#D7DEFF]" />
                <div className="mt-3 h-8 rounded-xl bg-[#EEF2FF] dark:bg-[#2B3245]" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LandingPage() {
  const { t } = useAppLanguage();

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(124,58,237,0.12),_transparent_34%),linear-gradient(180deg,#F7F8FF_0%,#EEF2FF_100%)] text-[#151827] transition-colors dark:bg-[radial-gradient(circle_at_top,_rgba(91,108,248,0.18),_transparent_28%),linear-gradient(180deg,#0D1018_0%,#121621_100%)] dark:text-white">
      <div className="mx-auto flex min-h-screen max-w-7xl flex-col px-5 sm:px-8 lg:px-10">
        <header className="flex items-center justify-between py-6 sm:py-8">
          <div className="flex items-center gap-3">
            <AppLogo size={44} iconSize={20} className="rounded-2xl shadow-[0_12px_30px_rgba(91,108,248,0.2)]" />
            <span className="text-lg font-semibold tracking-tight">Dialogly</span>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/login"
              className="rounded-xl border border-[#D6DBF8] bg-white/70 px-4 py-2 text-sm font-medium text-[#1F2540] transition hover:bg-white dark:border-[#313953] dark:bg-[#171C28] dark:text-white dark:hover:bg-[#1C2230]"
            >
              {t('auth.signIn')}
            </Link>
            <Link
              to="/register"
              className="inline-flex items-center gap-2 rounded-xl bg-[linear-gradient(135deg,#5b6cf8_0%,#7c3aed_100%)] px-4 py-2 text-sm font-medium text-white shadow-[0_16px_35px_rgba(91,108,248,0.2)] transition hover:translate-y-[-1px]"
            >
              {t('landing.getStarted')}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </header>

        <main className="flex flex-1 flex-col justify-center pb-12 pt-6 sm:pt-10 lg:pb-16">
          <section className="grid items-center gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,560px)] lg:gap-16">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-[#D8DEFF] bg-white/75 px-4 py-2 text-sm text-[#4D5CE6] shadow-sm backdrop-blur dark:border-[#2E3550] dark:bg-[#171C28] dark:text-[#CBD5FF]">
                <Sparkles className="h-4 w-4" />
                {t('landing.badge')}
              </div>

              <h1 className="mt-6 text-4xl font-semibold tracking-tight text-[#11131E] sm:text-5xl lg:text-6xl dark:text-white">
                {t('landing.headline')}
              </h1>

              <p className="mt-5 max-w-xl text-base leading-7 text-[#5F6475] sm:text-lg dark:text-[#AAB0C5]">
                {t('landing.subheadline')}
              </p>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link
                  to="/register"
                  className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#5b6cf8_0%,#7c3aed_100%)] px-6 py-3 text-base font-medium text-white shadow-[0_20px_45px_rgba(91,108,248,0.22)] transition hover:translate-y-[-1px]"
                >
                  {t('landing.getStarted')}
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  to="/login"
                  className="inline-flex items-center justify-center rounded-2xl border border-[#D6DBF8] bg-white/80 px-6 py-3 text-base font-medium text-[#1F2540] transition hover:bg-white dark:border-[#313953] dark:bg-[#171C28] dark:text-white dark:hover:bg-[#1C2230]"
                >
                  {t('auth.signIn')}
                </Link>
              </div>
            </div>

            <HeroIllustration t={t} />
          </section>

          <section className="mt-20">
            <div className="max-w-2xl">
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-[#5B6CF8] dark:text-[#AFC0FF]">
                {t('landing.whyDialogly')}
              </p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight text-[#11131E] dark:text-white">
                {t('landing.featuresTitle')}
              </h2>
            </div>

            <div className="mt-8 grid gap-5 md:grid-cols-3">
              <FeatureCard
                icon={MessageCircleMore}
                title={t('landing.featureInboxTitle')}
                description={t('landing.featureInboxDescription')}
              />
              <FeatureCard
                icon={Users}
                title={t('landing.featureWorkspaceTitle')}
                description={t('landing.featureWorkspaceDescription')}
              />
              <FeatureCard
                icon={CheckCircle2}
                title={t('landing.featureRichTitle')}
                description={t('landing.featureRichDescription')}
              />
            </div>
          </section>
        </main>

        <footer className="flex flex-col items-center justify-between gap-4 border-t border-[#D9DDF8] py-6 text-sm text-[#6B7280] sm:flex-row dark:border-[#2C3346] dark:text-[#9AA3B9]">
          <p>Dialogly © 2026</p>
          <div className="flex items-center gap-5">
            <Link to="/login" className="transition hover:text-[#11131E] dark:hover:text-white">
              {t('auth.signIn')}
            </Link>
            <Link to="/register" className="transition hover:text-[#11131E] dark:hover:text-white">
              {t('landing.getStarted')}
            </Link>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default LandingPage;
