import { ArrowLeft, Download } from 'lucide-react';
import { useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useAppLanguage } from '../context/AppLanguageContext';

function isPdf(type = '', fileName = '') {
  return type === 'application/pdf' || /\.pdf$/i.test(fileName);
}

function isImage(type = '') {
  return type.startsWith('image/');
}

function buildViewerUrl(sourceUrl, contentType, fileName) {
  if (!sourceUrl) return '';
  if (isPdf(contentType, fileName)) {
    return `${sourceUrl}#toolbar=0&navpanes=0&scrollbar=1`;
  }

  return sourceUrl;
}

function AttachmentPreviewPage() {
  const { t } = useAppLanguage();
  const [searchParams] = useSearchParams();
  const sourceUrl = searchParams.get('src') || '';
  const fileName = searchParams.get('name') || 'Attachment';
  const contentType = searchParams.get('type') || 'application/octet-stream';

  const viewerUrl = useMemo(() => buildViewerUrl(sourceUrl, contentType, fileName), [sourceUrl, contentType, fileName]);

  return (
    <div className="min-h-screen bg-[#0b1020] text-white">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-black/20 px-4 py-3 backdrop-blur">
        <div className="flex min-w-0 items-center gap-3">
          <Link
            to="/chats"
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white/80 transition hover:border-white/20 hover:bg-white/10 hover:text-white"
            aria-label={t('miscUi.backToChatsAria')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{fileName}</p>
            <p className="text-xs text-white/60">{contentType}</p>
          </div>
        </div>

        <a
          href={sourceUrl}
          download={fileName}
          className="inline-flex h-10 items-center gap-2 rounded-lg bg-indigo-500 px-4 text-sm font-medium text-white transition hover:bg-indigo-400"
        >
          <Download className="h-4 w-4" />
          {t('dashboard.downloadFile')}
        </a>
      </header>

      <main className="h-[calc(100vh-73px)] bg-[#0f172a] p-4">
        {!sourceUrl ? (
          <div className="flex h-full items-center justify-center rounded-2xl border border-dashed border-white/15 bg-white/5 px-6 text-center text-sm text-white/70">
            {t('miscUi.previewUnavailable')}
          </div>
        ) : isImage(contentType) ? (
          <div className="flex h-full items-center justify-center overflow-auto rounded-2xl border border-white/10 bg-black/30 p-4">
            <img src={sourceUrl} alt={fileName} className="max-h-full max-w-full object-contain" />
          </div>
        ) : (
          <iframe
            src={viewerUrl}
            title={fileName}
            className="h-full w-full rounded-2xl border border-white/10 bg-white"
          />
        )}
      </main>
    </div>
  );
}

export default AttachmentPreviewPage;
