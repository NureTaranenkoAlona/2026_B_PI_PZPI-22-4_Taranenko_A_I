import { useEffect, useMemo, useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Camera,
  CheckCircle2,
  LoaderCircle,
  MessageCircle,
  RefreshCw,
  Send,
  Shield,
  Smartphone,
  Unplug,
} from 'lucide-react';

import {
  connectIntegration,
  connectMessengerPage,
  connectTelegramBot,
  disconnectIntegration,
  getIntegrations,
  getPlatforms,
} from '../api/integrationApi';
import AppLogo from '../components/common/AppLogo';
import ConnectPlatformModal from '../components/onboarding/ConnectPlatformModal';
import { useAccountContext } from '../context/AccountContext';
import { useAppLanguage } from '../context/AppLanguageContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import useSystemTheme from '../hooks/useSystemTheme';
import getApiErrorMessage from '../utils/getApiErrorMessage';
import {
  buildMockConnectPayload,
  getIntegrationConflictMessage,
  getModalInitialValues,
  mapIntegrationData,
} from '../utils/integrationUi';

const PLATFORM_META = {
  telegram: {
    icon: Send,
    accent: 'from-sky-400 to-cyan-500',
  },
  messenger: {
    icon: MessageCircle,
    accent: 'from-blue-500 to-indigo-500',
  },
  instagram: {
    icon: Camera,
    accent: 'from-rose-500 to-orange-400',
  },
  whatsapp: {
    icon: Smartphone,
    accent: 'from-emerald-500 to-green-500',
  },
  viber: {
    icon: MessageCircle,
    accent: 'from-violet-500 to-purple-500',
  },
};

const STATUS_META = {
  connected: {
    label: 'Connected',
    badge:
      'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-200',
  },
  disconnected: {
    label: 'Disconnected',
    badge: 'bg-slate-100 text-slate-600 dark:bg-[#2A2F3A] dark:text-[#9CA3AF]',
  },
  connecting: {
    label: 'Connecting',
    badge: 'bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-200',
  },
  reconnecting: {
    label: 'Reconnect in progress',
    badge:
      'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-200',
  },
  unavailable: {
    label: 'Unavailable',
    badge: 'bg-[#F3F4F6] text-[#9CA3AF] dark:bg-[#232833] dark:text-[#6B7280]',
  },
};

function getHeaderContent(state, t) {
  if (state.mode === 'personal') {
    return {
      successLabel: t('onboardingWorkspace.personalAccountSetup'),
      title: t('onboarding.connectFirstChannelTitle'),
      description: t('onboarding.connectFirstChannelDescription'),
      bannerTitle: t('integrationsUi.personalIntegrations'),
      bannerDescription: t('integrationsUi.personalIntegrationsDescription'),
    };
  }

  if (state.workspaceChoice === 'created') {
    return {
      successLabel: t('onboardingWorkspace.workspaceCreatedSuccessfully'),
      title: t('onboardingWorkspace.connectWorkspaceChannels'),
      description: t('onboardingWorkspace.connectWorkspaceChannelsDescription'),
      bannerTitle: t('onboardingWorkspace.setupCompanyChannels'),
      bannerDescription: t('integrationsUi.workspaceIntegrationsDescription'),
    };
  }

  return {
    successLabel: t('onboardingWorkspace.workspaceJoinedSuccessfully'),
    title: t('onboardingWorkspace.reviewWorkspaceChannels'),
    description: t('onboardingWorkspace.reviewWorkspaceChannelsDescription', {
      name: state.workspace?.name || t('onboardingWorkspace.yourWorkspace'),
    }),
    bannerTitle: t('integrationsUi.workspaceLevelIntegrations'),
    bannerDescription: t('integrationsUi.workspaceIntegrationsDescription'),
  };
}

function formatDateTime(value) {
  if (!value) return 'Not synced yet';

  const normalized = value.includes('T') ? value : value.replace(' ', 'T');
  const date = new Date(normalized);

  if (Number.isNaN(date.getTime())) return value;

  return new Intl.DateTimeFormat('en', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

function OnboardingIntegrationCard({
  integration,
  onboardingState,
  busyAction,
  onConnect,
  onReconnect,
  onDisconnect,
}) {
  const meta = PLATFORM_META[integration.id] || PLATFORM_META.messenger;
  const Icon = meta.icon;
  const statusMeta = STATUS_META[integration.status] || STATUS_META.disconnected;
  const isBusy = Boolean(busyAction);
  const isPersonal = onboardingState.mode === 'personal';
  const canManage = isPersonal || onboardingState.canManageIntegrations;

  return (
    <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#1C1F26] p-5 shadow-sm shadow-black/[0.03]">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_420px] lg:items-start">
        <div className="flex gap-4 min-w-0">
          <div
            className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${meta.accent} flex items-center justify-center text-white flex-shrink-0`}
          >
            <Icon className="w-5 h-5" />
          </div>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm text-[#111827] dark:text-white">{integration.name}</h3>
              <span className={`px-2.5 py-1 rounded-full text-[11px] ${statusMeta.badge}`}>
                {statusMeta.label}
              </span>
              {integration.managedByWorkspace && onboardingState.hasWorkspace && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] bg-[#EEF2FF] text-[#4F46E5] dark:bg-[#312E81]/40 dark:text-[#C7D2FE]">
                  <Shield className="w-3 h-3" />
                  Managed centrally
                </span>
              )}
            </div>

            <p className="mt-1 text-sm leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
              {integration.description}
            </p>

            {integration.status === 'connected' || integration.status === 'reconnecting' ? (
              <div className="mt-3 rounded-xl border border-[#EEF2F7] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-3">
                <p className="text-sm text-[#111827] dark:text-white">{integration.displayName}</p>
                <p className="mt-1 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                  {isPersonal
                    ? 'This channel is connected to your personal account.'
                    : 'This channel is connected for the workspace and shared across the company.'}
                </p>
                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                  <span>Connected by {integration.connectedBy}</span>
                  <span>Last sync {formatDateTime(integration.lastSyncAt)}</span>
                </div>
              </div>
            ) : (
              <div className="mt-3 rounded-xl border border-dashed border-[#D1D5DB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-3">
                <p className="text-sm text-[#111827] dark:text-white">
                  {integration.status === 'unavailable'
                    ? 'Workspace required before connecting'
                    : isPersonal
                      ? 'No personal account connected yet'
                      : 'No corporate account connected yet'}
                </p>
                <p className="mt-1 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                  {integration.status === 'unavailable'
                    ? 'Create or join a workspace to connect channels.'
                    : isPersonal
                      ? 'Once connected, this channel will be available only in your personal account.'
                      : `Once connected, this workspace-owned channel will be shared with the whole company${onboardingState.workspace?.name ? ` in ${onboardingState.workspace.name}` : ''}.`}
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="lg:min-w-0 lg:self-stretch">
          {canManage ? (
            <div className="flex flex-wrap gap-2 lg:justify-end lg:pt-1">
              {integration.status === 'disconnected' ? (
                <button
                  type="button"
                  onClick={onConnect}
                  disabled={isBusy}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--dialogly-accent)] text-white text-sm hover:bg-[var(--dialogly-accent-hover)] transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {busyAction === 'connect' ? (
                    <LoaderCircle className="w-4 h-4 animate-spin" />
                  ) : (
                    <BadgeCheck className="w-4 h-4" />
                  )}
                  Connect
                </button>
              ) : integration.status === 'connected' ? (
                <>
                  <button
                    type="button"
                    onClick={onReconnect}
                    disabled={isBusy}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-sm text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {busyAction === 'reconnect' ? (
                      <LoaderCircle className="w-4 h-4 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4" />
                    )}
                    Reconnect
                  </button>
                  <button
                    type="button"
                    onClick={onDisconnect}
                    disabled={isBusy}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#FECACA] dark:border-[#7F1D1D] bg-white dark:bg-[#20242E] text-sm text-[#DC2626] dark:text-[#FCA5A5] hover:bg-[#FEF2F2] dark:hover:bg-[#311313] transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {busyAction === 'disconnect' ? (
                      <LoaderCircle className="w-4 h-4 animate-spin" />
                    ) : (
                      <Unplug className="w-4 h-4" />
                    )}
                    Disconnect
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  disabled
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-sm text-[#9CA3AF] cursor-not-allowed"
                >
                  {t('integrationsUi.unavailable')}
                </button>
              )}
            </div>
          ) : (
            <div className="h-full rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-4 h-4 text-[#F59E0B] mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-[#111827] dark:text-white">
                    {t('integrationsUi.workspaceOwnerOnlyTitle')}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                    {t('integrationsUi.workspaceOwnerOnlyDescription')}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function OnboardingPage() {
  useSystemTheme();
  const { showError } = useToast();
  const { t } = useAppLanguage();

  const navigate = useNavigate();
  const location = useLocation();
  const {
    activeContext,
    canManageActiveIntegrations,
    completeOnboarding,
    isLoadingContexts,
  } = useAccountContext();
  const { completeUserOnboarding, user } = useAuth();
  const workspaceChoice =
    location.state?.workspaceChoice ?? user?.onboardingWorkspaceChoice ?? 'skipped';
  const joinedRole = location.state?.joinedRole ?? 'Admin';
  const createdWorkspaceName = location.state?.workspaceName ?? 'New Workspace';
  const createdWorkspaceId = location.state?.workspaceId ?? null;
  const shouldAllowCompletedOnboardingView =
    workspaceChoice === 'created' || workspaceChoice === 'joined';

  const onboardingState = useMemo(
    () => ({
      mode: activeContext?.type === 'workspace' ? 'workspace' : 'personal',
      workspaceChoice,
      workspace:
        activeContext?.type === 'workspace'
          ? activeContext.workspace
          : workspaceChoice === 'created' || workspaceChoice === 'joined'
            ? {
                id: createdWorkspaceId,
                name: createdWorkspaceName,
              }
            : null,
      currentUserRole:
        activeContext?.type === 'workspace' ? activeContext.role : workspaceChoice === 'joined' ? joinedRole : null,
      ownershipLabel: activeContext?.type === 'workspace' ? 'Workspace' : 'Personal',
      canManageIntegrations:
        activeContext?.type === 'personal' ? true : canManageActiveIntegrations,
      hasWorkspace: activeContext?.type === 'workspace',
    }),
    [
      activeContext,
      canManageActiveIntegrations,
      createdWorkspaceId,
      createdWorkspaceName,
      joinedRole,
      workspaceChoice,
    ]
  );

  const header = useMemo(() => getHeaderContent(onboardingState, t), [onboardingState, t]);
  const [integrations, setIntegrations] = useState([]);
  const [busyMap, setBusyMap] = useState({});
  const [isLoadingIntegrations, setIsLoadingIntegrations] = useState(true);
  const [pageError, setPageError] = useState('');
  const [isModalSubmitting, setIsModalSubmitting] = useState(false);
  const [modalState, setModalState] = useState({
    open: false,
    mode: 'connect',
    integration: null,
  });
  const [isFinishing, setIsFinishing] = useState(false);
  const [submitError, setSubmitError] = useState('');

  useEffect(() => {
    setBusyMap({});
    setModalState({ open: false, mode: 'connect', integration: null });
  }, [activeContext?.id]);

  useEffect(() => {
    if (isLoadingContexts || !activeContext?.id) {
      return;
    }

    const load = async () => {
      setIsLoadingIntegrations(true);
      setPageError('');

      try {
        const [platforms, integrationAccounts] = await Promise.all([
          getPlatforms(),
          getIntegrations(),
        ]);

        setIntegrations(mapIntegrationData(platforms, integrationAccounts, activeContext));
      } catch (error) {
        setPageError(
          getApiErrorMessage(
            error,
            'Unable to load integrations right now. Please try again.'
          )
        );
      } finally {
        setIsLoadingIntegrations(false);
      }
    };

    load();
  }, [activeContext, isLoadingContexts]);

  const connectedCount = useMemo(
    () => integrations.filter((integration) => integration.status === 'connected').length,
    [integrations]
  );

  const updateIntegration = (id, updates) => {
    setIntegrations((current) =>
      current.map((integration) =>
        integration.id === id ? { ...integration, ...updates } : integration
      )
    );
  };

  const runDisconnect = async (integration) => {
    if (!integration.backendId) return;

    setBusyMap((current) => ({ ...current, [integration.id]: 'disconnect' }));
    updateIntegration(integration.id, { status: 'reconnecting' });

    try {
      const updatedIntegration = await disconnectIntegration(integration.backendId);
      setIntegrations((current) =>
        current.map((item) =>
          item.id === integration.id
            ? mapIntegrationData(
                [
                  {
                    id: updatedIntegration.id,
                    code: updatedIntegration.platformCode,
                    name: updatedIntegration.platformName,
                    shortDescription: item.description,
                  },
                ],
                [updatedIntegration],
                activeContext
              )[0]
            : item
        )
      );
      setPageError('');
    } catch (error) {
      updateIntegration(integration.id, { status: 'connected' });
      setPageError(
        getApiErrorMessage(
          error,
          'Unable to disconnect this integration right now.'
        )
      );
    } finally {
      setBusyMap((current) => ({ ...current, [integration.id]: '' }));
    }
  };

  const openConnectModal = (integration, mode) => {
    if (onboardingState.mode === 'workspace' && !onboardingState.canManageIntegrations) return;

    setModalState({
      open: true,
      mode,
      integration,
    });
  };

  const handleModalSubmit = async (values) => {
    const integration = modalState.integration;
    if (!integration) return;

    const action = modalState.mode === 'reconnect' ? 'reconnect' : 'connect';

    setIsModalSubmitting(true);

    try {
      setBusyMap((current) => ({ ...current, [integration.id]: action }));
      updateIntegration(integration.id, {
        status: action === 'reconnect' ? 'reconnecting' : 'connecting',
      });

      const connectedIntegration = integration.id === 'telegram'
        ? await connectTelegramBot({
            botToken: values.botToken.trim(),
          })
        : integration.id === 'messenger'
          ? await connectMessengerPage({
              pageId: values.pageId.trim(),
              pageAccessToken: values.pageAccessToken.trim(),
              pageName: values.pageName.trim(),
            })
          : await connectIntegration(buildMockConnectPayload(integration.id, values));

      setIntegrations((current) =>
        current.map((item) =>
          item.id === integration.id
            ? mapIntegrationData(
                [
                  {
                    id: connectedIntegration.id,
                    code: connectedIntegration.platformCode,
                    name: connectedIntegration.platformName,
                    shortDescription: item.description,
                  },
                ],
                [connectedIntegration],
                activeContext
              )[0]
            : item
        )
      );
      setPageError('');
      setModalState({ open: false, mode: 'connect', integration: null });
    } catch (error) {
      updateIntegration(integration.id, {
        status: integration.backendId ? 'connected' : 'disconnected',
      });
      const conflictMessage = getIntegrationConflictMessage(error, integration.id);
      setPageError(
        conflictMessage ||
          getApiErrorMessage(error, 'Unable to connect this integration right now.')
      );
      showError(conflictMessage || 'Failed to connect integration');
    } finally {
      setBusyMap((current) => ({ ...current, [integration.id]: '' }));
      setIsModalSubmitting(false);
    }
  };

  const handleContinue = () => {
    if (isFinishing) {
      return;
    }

    const finishOnboarding = async () => {
      setIsFinishing(true);
      setSubmitError('');

      try {
        await completeUserOnboarding(workspaceChoice);
        await completeOnboarding();
        navigate('/chats', { replace: true });
      } catch (error) {
        setSubmitError(
          getApiErrorMessage(error, 'Unable to finish onboarding. Please try again.')
        );
      } finally {
        setIsFinishing(false);
      }
    };

    finishOnboarding();
  };

  if (user?.isOnboardingCompleted && !shouldAllowCompletedOnboardingView) {
    return <Navigate to="/chats" replace />;
  }

  return (
    <div className="min-h-screen bg-[#F5F6FA] dark:bg-[#181A20] px-4 py-6 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <AppLogo size={34} iconSize={15} />
            <div>
              <p className="text-sm text-[#111827] dark:text-white">Dialogly</p>
              <p className="text-xs text-[#9CA3AF]">
                {onboardingState.mode === 'personal'
                  ? 'Personal account onboarding'
                  : `Workspace onboarding for ${onboardingState.workspace?.name || 'your workspace'}`}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigate('/post-login')}
            className="inline-flex items-center gap-2 text-sm text-[#6B7280] dark:text-[#9CA3AF] hover:text-[#111827] dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
        </div>

        <div className="rounded-[28px] border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] shadow-xl shadow-black/[0.04] overflow-hidden">
          <div className="px-6 py-6 sm:px-8 sm:py-8 border-b border-[#EEF2F7] dark:border-[#2F3440]">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
              <div className="max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EEF2FF] text-[#4F46E5] dark:bg-[#312E81]/30 dark:text-[#C7D2FE] text-xs mb-4">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {header.successLabel}
                </div>
                <h1 className="text-[#111827] dark:text-white">{header.title}</h1>
                <p className="mt-2 text-sm leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                  {header.description}
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-3 lg:min-w-[320px]">
                <div className="rounded-2xl border border-[#EEF2F7] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4">
                  <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">{t('onboardingWorkspace.mode')}</p>
                  <p className="mt-1 text-sm text-[#111827] dark:text-white capitalize">
                    {onboardingState.mode}
                  </p>
                </div>
                <div className="rounded-2xl border border-[#EEF2F7] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4">
                  <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">
                    Connected
                  </p>
                  <p className="mt-1 text-sm text-[#111827] dark:text-white">{connectedCount}</p>
                </div>
                <div className="rounded-2xl border border-[#EEF2F7] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4">
                  <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">
                    Ownership
                  </p>
                  <p className="mt-1 text-sm text-[#111827] dark:text-white">
                    {onboardingState.ownershipLabel || 'Not set yet'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="px-6 py-6 sm:px-8 sm:py-8 space-y-5">
            <div className="rounded-2xl border border-[#D9E3FF] dark:border-[#2E3A59] bg-gradient-to-br from-[#EEF4FF] to-[#F8FAFF] dark:from-[#1D2635] dark:to-[#18202D] p-5">
              <div className="flex gap-3">
                <div className="w-11 h-11 rounded-2xl bg-white dark:bg-[#111827] flex items-center justify-center text-[#4F46E5] shadow-sm flex-shrink-0">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-[#111827] dark:text-white">{header.bannerTitle}</p>
                  <p className="mt-1 text-sm leading-relaxed text-[#52607A] dark:text-[#A8B3C7]">
                    {header.bannerDescription}
                  </p>
                </div>
              </div>
            </div>

            {onboardingState.mode === 'workspace' && !onboardingState.canManageIntegrations && (
              <div className="rounded-2xl border border-[#FDE68A] dark:border-[#5B4B1F] bg-[#FFFBEB] dark:bg-[#2B2413] p-4 flex gap-3">
                <AlertCircle className="w-5 h-5 text-[#D97706] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-[#111827] dark:text-white">
                    {t('integrationsUi.workspaceOwnerOnlyTitle')}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                    {t('onboardingWorkspace.workspaceOwnerReviewOnly')}
                  </p>
                </div>
              </div>
            )}

            {pageError && (
              <div className="rounded-2xl border border-[#FECACA] dark:border-[#7F1D1D] bg-[#FEF2F2] dark:bg-[#311313] p-4 flex gap-3">
                <AlertCircle className="w-5 h-5 text-[#DC2626] flex-shrink-0 mt-0.5" />
                <p className="text-sm text-[#991B1B] dark:text-[#FCA5A5]">{pageError}</p>
              </div>
            )}

            <div className="space-y-4">
              {isLoadingIntegrations ? (
                <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#1C1F26] p-8 flex items-center justify-center gap-3 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                  <LoaderCircle className="w-4 h-4 animate-spin" />
                  Loading available channels...
                </div>
              ) : (
                integrations.map((integration) => (
                  <OnboardingIntegrationCard
                    key={integration.id}
                    integration={integration}
                    onboardingState={onboardingState}
                    busyAction={busyMap[integration.id]}
                    onConnect={() => openConnectModal(integration, 'connect')}
                    onReconnect={() => openConnectModal(integration, 'reconnect')}
                    onDisconnect={() => runDisconnect(integration)}
                  />
                ))
              )}
            </div>
          </div>

          <div className="px-6 py-5 sm:px-8 border-t border-[#EEF2F7] dark:border-[#2F3440] bg-[#FCFCFD] dark:bg-[#181C24] flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                You can finish setup now and manage accounts and integrations later from Settings.
              </p>
              {submitError && (
                <p className="mt-2 text-sm text-[#EF4444]">{submitError}</p>
              )}
            </div>

            <button
              type="button"
              onClick={handleContinue}
              disabled={isFinishing}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--dialogly-accent)] text-white text-sm hover:bg-[var(--dialogly-accent-hover)] transition-colors"
            >
              {isFinishing ? 'Saving...' : 'Continue to dashboard'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <ConnectPlatformModal
        isOpen={modalState.open}
        mode={modalState.mode}
        integration={modalState.integration}
        workspaceName={
          onboardingState.mode === 'personal'
            ? 'Personal account'
            : onboardingState.workspace?.name
        }
        initialValues={getModalInitialValues(modalState.integration)}
        isSubmitting={isModalSubmitting}
        onClose={() => setModalState({ open: false, mode: 'connect', integration: null })}
        onSubmit={handleModalSubmit}
      />
    </div>
  );
}

export default OnboardingPage;
