import PolicyLayout from '../components/common/PolicyLayout';
import { useAppLanguage } from '../context/AppLanguageContext';

function Section({ number, title, paragraphs }) {
  return (
    <section>
      <h2 className="text-lg font-semibold text-[#111827] dark:text-white">
        {number}. {title}
      </h2>
      <div className="mt-2 space-y-3">
        {paragraphs.map((paragraph, index) => (
          <p key={`${number}-${index}`}>{paragraph}</p>
        ))}
      </div>
    </section>
  );
}

function PrivacyPage() {
  const { t } = useAppLanguage();

  const sections = [
    { number: '1', title: t('policy.privacy.introductionTitle'), paragraphs: [t('policy.privacy.introductionBody1'), t('policy.privacy.introductionBody2')] },
    { number: '2', title: t('policy.privacy.collectTitle'), paragraphs: [t('policy.privacy.collectBody1'), t('policy.privacy.collectBody2'), t('policy.privacy.collectBody3'), t('policy.privacy.collectBody4')] },
    { number: '3', title: t('policy.privacy.useTitle'), paragraphs: [t('policy.privacy.useBody1'), t('policy.privacy.useBody2'), t('policy.privacy.useBody3'), t('policy.privacy.useBody4')] },
    { number: '4', title: t('policy.privacy.storageTitle'), paragraphs: [t('policy.privacy.storageBody1'), t('policy.privacy.storageBody2'), t('policy.privacy.storageBody3')] },
    { number: '5', title: t('policy.privacy.retentionTitle'), paragraphs: [t('policy.privacy.retentionBody1'), t('policy.privacy.retentionBody2'), t('policy.privacy.retentionBody3')] },
    { number: '6', title: t('policy.privacy.rightsTitle'), paragraphs: [t('policy.privacy.rightsBody1'), t('policy.privacy.rightsBody2'), t('policy.privacy.rightsBody3')] },
    { number: '7', title: t('policy.privacy.cookiesTitle'), paragraphs: [t('policy.privacy.cookiesBody1'), t('policy.privacy.cookiesBody2')] },
    { number: '8', title: t('policy.privacy.thirdPartyTitle'), paragraphs: [t('policy.privacy.thirdPartyBody1'), t('policy.privacy.thirdPartyBody2')] },
    { number: '9', title: t('policy.privacy.securityTitle'), paragraphs: [t('policy.privacy.securityBody1'), t('policy.privacy.securityBody2'), t('policy.privacy.securityBody3')] },
    { number: '10', title: t('policy.privacy.contactTitle'), paragraphs: [t('policy.privacy.contactBody1'), t('policy.privacy.contactBody2')] },
  ];

  return (
    <PolicyLayout
      title={t('policy.privacy.pageTitle')}
      lastUpdated={t('policy.lastUpdated')}
      alternateLink="/terms"
      alternateLabel={t('policy.terms.pageTitle')}
    >
      {sections.map((section) => (
        <Section key={section.number} {...section} />
      ))}
    </PolicyLayout>
  );
}

export default PrivacyPage;
