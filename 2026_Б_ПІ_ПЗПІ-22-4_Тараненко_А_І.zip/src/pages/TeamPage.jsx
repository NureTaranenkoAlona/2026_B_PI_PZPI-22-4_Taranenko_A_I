import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, UserPlus, Users } from 'lucide-react';
import MemberItem from '../components/team/MemberItem';
import InviteModal from '../components/team/InviteModal';
import { useAccountContext } from '../context/AccountContext';
import { useAppLanguage } from '../context/AppLanguageContext';
import { useAuth } from '../context/AuthContext';
import {
  createWorkspaceInvite,
  getWorkspaceInvites,
  getWorkspaceMembers,
  removeWorkspaceMember,
  revokeWorkspaceInvite,
} from '../api/workspaceApi';
import getApiErrorMessage from '../utils/getApiErrorMessage';

function mapMember(member, currentUserId) {
  return {
    userId: member.userId,
    name: `${member.firstName || ''} ${member.lastName || ''}`.trim() || member.email,
    email: member.email,
    role: member.role,
    status: member.status,
    joinedAt: member.joinedAt,
    isCurrentUser: member.userId === currentUserId,
  };
}

function TeamMemberSkeleton() {
  return (
    <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] px-5 py-4 shadow-sm shadow-slate-200/40 dark:shadow-none animate-pulse">
      <div className="flex items-center gap-4">
        <div className="w-11 h-11 rounded-full bg-gray-200 dark:bg-gray-700 shrink-0" />
        <div className="flex-1 min-w-0 space-y-2">
          <div className="h-3 rounded bg-gray-200 dark:bg-gray-700 w-1/3" />
          <div className="h-3 rounded bg-gray-200 dark:bg-gray-700 w-1/2" />
        </div>
        <div className="h-8 w-20 rounded-xl bg-gray-200 dark:bg-gray-700 shrink-0" />
      </div>
    </div>
  );
}

function TeamPage() {
  const navigate = useNavigate();
  const { activeContext } = useAccountContext();
  const { user } = useAuth();
  const { t } = useAppLanguage();
  const workspaceId = activeContext?.type === 'workspace' ? activeContext.workspaceId : null;
  const currentUserRole = activeContext?.role || 'Member';
  const canInvite = currentUserRole === 'Owner' || currentUserRole === 'Admin';

  const [members, setMembers] = useState([]);
  const [invites, setInvites] = useState([]);
  const [isLoadingMembers, setIsLoadingMembers] = useState(false);
  const [isLoadingInvites, setIsLoadingInvites] = useState(false);
  const [isGeneratingInvite, setIsGeneratingInvite] = useState(false);
  const [revokingToken, setRevokingToken] = useState('');
  const [removingUserId, setRemovingUserId] = useState('');
  const [pageError, setPageError] = useState('');
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [activeMenuId, setActiveMenuId] = useState(null);
  const menuContainerRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (!menuContainerRef.current?.contains(event.target)) {
        setActiveMenuId(null);
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, []);

  const loadMembers = async () => {
    if (!workspaceId) {
      setMembers([]);
      return;
    }

    setIsLoadingMembers(true);
    setPageError('');

    try {
      const response = await getWorkspaceMembers(workspaceId);
      setMembers(response.map((member) => mapMember(member, user?.id)));
    } catch (error) {
      setPageError(getApiErrorMessage(error, 'Unable to load workspace members.'));
    } finally {
      setIsLoadingMembers(false);
    }
  };

  const loadInvites = async () => {
    if (!workspaceId || !canInvite) {
      setInvites([]);
      return;
    }

    setIsLoadingInvites(true);
    try {
      const response = await getWorkspaceInvites(workspaceId);
      setInvites(response);
    } catch (error) {
      setPageError(getApiErrorMessage(error, 'Unable to load workspace invites.'));
    } finally {
      setIsLoadingInvites(false);
    }
  };

  useEffect(() => {
    loadMembers();
    loadInvites();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspaceId, canInvite, user?.id]);

  const summary = useMemo(() => {
    const activeCount = members.filter((member) => member.status === 'Active').length;
    const invitedCount = invites.filter((invite) => invite.status === 'Active').length;
    return { activeCount, invitedCount };
  }, [invites, members]);

  const handleRemoveMember = async (memberUserId) => {
    if (!workspaceId) return;

    setRemovingUserId(memberUserId);
    try {
      await removeWorkspaceMember(workspaceId, memberUserId);
      setMembers((prev) => prev.filter((member) => member.userId !== memberUserId));
    } catch (error) {
      setPageError(getApiErrorMessage(error, 'Unable to remove workspace member.'));
    } finally {
      setRemovingUserId('');
    }
  };

  const handleGenerateInvite = async (role) => {
    if (!workspaceId) return null;

    setIsGeneratingInvite(true);
    setPageError('');

    try {
      const nextInvite = await createWorkspaceInvite(workspaceId, { role });
      setInvites((prev) => [nextInvite, ...prev]);
      return nextInvite;
    } catch (error) {
      setPageError(getApiErrorMessage(error, 'Unable to generate workspace invite.'));
      return null;
    } finally {
      setIsGeneratingInvite(false);
    }
  };

  const handleRevokeInvite = async (token) => {
    if (!workspaceId) return;

    setRevokingToken(token);
    try {
      const updatedInvite = await revokeWorkspaceInvite(workspaceId, token);
      setInvites((prev) => prev.map((invite) => (invite.token === token ? updatedInvite : invite)));
    } catch (error) {
      setPageError(getApiErrorMessage(error, 'Unable to revoke invite.'));
    } finally {
      setRevokingToken('');
    }
  };

  if (!workspaceId) {
    return (
      <div className="min-h-screen bg-[#F5F6FA] dark:bg-[#181A20] flex items-center justify-center px-4">
        <div className="max-w-md w-full rounded-3xl border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] p-8 text-center shadow-sm shadow-slate-200/40 dark:shadow-none">
          <h1 className="text-[#1A1D23] dark:text-white mb-2">{t('team.workspaceTeam')}</h1>
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] mb-6">
            {t('team.workspaceTeamDescription')}
          </p>
          <button
            type="button"
            onClick={() => navigate('/settings')}
            className="inline-flex items-center justify-center px-4 py-3 rounded-2xl bg-[var(--dialogly-accent)] text-white hover:bg-[var(--dialogly-accent-hover)] transition-colors"
          >
            {t('team.goToSettings')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F6FA] dark:bg-[#181A20]">
      <div className="min-h-14 bg-white dark:bg-[#1C1F26] border-b border-[#E5E7EB] dark:border-[#2F3440] flex items-center justify-between px-4 sm:px-6 gap-4">
        <button
          type="button"
          onClick={() => navigate('/settings')}
          className="flex items-center gap-2 text-sm text-[#6B7280] hover:text-[#1A1D23] dark:text-[#9CA3AF] dark:hover:text-white transition-colors group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          {t('team.backToSettings')}
        </button>

        <Link
          to="/chats"
          className="text-sm text-[#6B7280] hover:text-[#1A1D23] dark:text-[#9CA3AF] dark:hover:text-white transition-colors"
        >
          {t('team.goToChats')}
        </Link>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#EEF0FE] dark:bg-[#232842] text-[#5B6CF8] text-xs mb-4">
              <Users className="w-3.5 h-3.5" />
              {t('team.workspaceTeam')}
            </div>
            <h1 className="text-[#1A1D23] dark:text-white mb-2">{t('team.teamMembers')}</h1>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] max-w-2xl">
              {t('team.teamMembersDescription')}
            </p>
          </div>

          <button
            type="button"
            onClick={() => canInvite && setIsInviteOpen(true)}
            disabled={!canInvite}
            className={`inline-flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-sm transition-colors ${
              canInvite
                ? 'bg-[var(--dialogly-accent)] text-white hover:bg-[var(--dialogly-accent-hover)] shadow-md shadow-indigo-200/50 dark:shadow-none'
                : 'bg-[#E5E7EB] dark:bg-[#2A2F3A] text-[#9CA3AF] cursor-not-allowed'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            {t('team.inviteMember')}
          </button>
        </div>

        {pageError && (
          <div className="mb-6 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
            {pageError}
          </div>
        )}

        <div className="grid grid-cols-1 xl:grid-cols-[1fr,280px] gap-6">
          <div ref={menuContainerRef} className="space-y-4">
            {isLoadingMembers && (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, index) => (
                  <TeamMemberSkeleton key={index} />
                ))}
              </div>
            )}

            {!isLoadingMembers && members.length === 0 && (
              <div className="rounded-2xl border border-dashed border-[#D1D5DB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] px-5 py-10 text-center text-sm text-[#6B7280] dark:text-[#9CA3AF] shadow-sm shadow-slate-200/40 dark:shadow-none">
                {t('team.noMembersYet')}
              </div>
            )}

            {members.map((member) => (
              <MemberItem
                key={member.userId}
                member={member}
                isMenuOpen={activeMenuId === member.userId}
                onToggleMenu={() => setActiveMenuId((prev) => (prev === member.userId ? null : member.userId))}
                onCloseMenu={() => setActiveMenuId(null)}
                onRemove={handleRemoveMember}
                canManage={canInvite && !member.isCurrentUser && removingUserId !== member.userId}
              />
            ))}
          </div>

          <div className="space-y-4">
            <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] p-5 shadow-sm shadow-slate-200/40 dark:shadow-none">
              <p className="text-sm text-[#1A1D23] dark:text-white mb-4">{t('team.workspaceAccess')}</p>
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">{t('team.totalMembers')}</span>
                  <span className="text-sm text-[#1A1D23] dark:text-white">{members.length}</span>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">{t('team.active')}</span>
                  <span className="text-sm text-[#1A1D23] dark:text-white">{summary.activeCount}</span>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">{t('team.invited')}</span>
                  <span className="text-sm text-[#1A1D23] dark:text-white">{summary.invitedCount}</span>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] p-5 shadow-sm shadow-slate-200/40 dark:shadow-none">
              <p className="text-sm text-[#1A1D23] dark:text-white mb-2">{t('team.permissions')}</p>
              <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] leading-relaxed">
                {t('team.permissionsDescription')}
              </p>
            </div>
          </div>
        </div>
      </div>

      <InviteModal
        open={isInviteOpen}
        onClose={() => setIsInviteOpen(false)}
        invites={invites}
        onGenerateInvite={handleGenerateInvite}
        onRevokeInvite={handleRevokeInvite}
        isLoadingInvites={isLoadingInvites}
        isGeneratingInvite={isGeneratingInvite}
        revokingToken={revokingToken}
      />
    </div>
  );
}

export default TeamPage;
