import Sidebar from '../components/Sidebar';
import { useAppLanguage } from '../context/AppLanguageContext';

function ChatsPage() {
  const { t } = useAppLanguage();

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <div style={{ width: '300px', borderRight: '1px solid #ccc' }}>
        <Sidebar />
      </div>

      <div style={{ flex: 1 }}>
        {t('tour.chatTitle')}
      </div>
    </div>
  );
}

export default ChatsPage;
