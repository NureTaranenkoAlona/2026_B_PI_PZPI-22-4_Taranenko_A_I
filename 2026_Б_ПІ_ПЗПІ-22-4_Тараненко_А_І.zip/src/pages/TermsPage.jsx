import PolicyLayout from '../components/common/PolicyLayout';
import { useAppLanguage } from '../context/AppLanguageContext';

function Section({ number, title, paragraphs }) {
  return (
    <section>
      <h2 className="text-lg font-semibold text-[#111827] dark:text-white">
        {number}. {title}
      </h2>
      <div className="mt-2 space-y-3">
        {paragraphs.map((paragraph, index) => (
          <p key={`${number}-${index}`}>{paragraph}</p>
        ))}
      </div>
    </section>
  );
}

function TermsPage() {
  const { t } = useAppLanguage();

  const sections = [
    { number: '1', title: t('policy.terms.acceptanceTitle'), paragraphs: [t('policy.terms.acceptanceBody1'), t('policy.terms.acceptanceBody2')] },
    { number: '2', title: t('policy.terms.serviceTitle'), paragraphs: [t('policy.terms.serviceBody1'), t('policy.terms.serviceBody2'), t('policy.terms.serviceBody3')] },
    { number: '3', title: t('policy.terms.accountsTitle'), paragraphs: [t('policy.terms.accountsBody1'), t('policy.terms.accountsBody2'), t('policy.terms.accountsBody3'), t('policy.terms.accountsBody4')] },
    { number: '4', title: t('policy.terms.useTitle'), paragraphs: [t('policy.terms.useBody1'), t('policy.terms.useBody2'), t('policy.terms.useBody3'), t('policy.terms.useBody4')] },
    { number: '5', title: t('policy.terms.integrationsTitle'), paragraphs: [t('policy.terms.integrationsBody1'), t('policy.terms.integrationsBody2')] },
    { number: '6', title: t('policy.terms.privacyTitle'), paragraphs: [t('policy.terms.privacyBody1'), t('policy.terms.privacyBody2')] },
    { number: '7', title: t('policy.terms.terminationTitle'), paragraphs: [t('policy.terms.terminationBody1'), t('policy.terms.terminationBody2')] },
    { number: '8', title: t('policy.terms.liabilityTitle'), paragraphs: [t('policy.terms.liabilityBody1'), t('policy.terms.liabilityBody2')] },
    { number: '9', title: t('policy.terms.changesTitle'), paragraphs: [t('policy.terms.changesBody1'), t('policy.terms.changesBody2')] },
    { number: '10', title: t('policy.terms.contactTitle'), paragraphs: [t('policy.terms.contactBody1')] },
  ];

  return (
    <PolicyLayout
      title={t('policy.terms.pageTitle')}
      lastUpdated={t('policy.lastUpdated')}
      alternateLink="/privacy"
      alternateLabel={t('policy.privacy.pageTitle')}
    >
      {sections.map((section) => (
        <Section key={section.number} {...section} />
      ))}
    </PolicyLayout>
  );
}

export default TermsPage;
