import WorkspaceModal from '../components/onboarding/WorkspaceModal';
import useSystemTheme from '../hooks/useSystemTheme';

function AddAccountPage() {
  useSystemTheme();

  return (
    <div className="min-h-screen bg-[#F5F6FA] dark:bg-[#181A20]">
      <WorkspaceModal allowSkip={false} closeTo="/settings" />
    </div>
  );
}

export default AddAccountPage;
