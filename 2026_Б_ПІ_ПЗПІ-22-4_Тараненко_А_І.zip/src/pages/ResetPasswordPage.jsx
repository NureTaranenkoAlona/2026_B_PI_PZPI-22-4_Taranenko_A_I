import { useEffect, useState } from 'react';
import { Eye, EyeOff, MessageCircle, RefreshCcw } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { resendPasswordResetCode, resetPassword } from '../api/authApi';
import { useAppLanguage } from '../context/AppLanguageContext';
import useSystemTheme from '../hooks/useSystemTheme';
import getApiErrorMessage from '../utils/getApiErrorMessage';

const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{8,}$/;

function validateEmail(value) {
  const trimmed = value.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!trimmed) return 'Email is required.';
  if (trimmed.length > 254) return 'Email is too long.';
  if (!trimmed.includes('@')) return 'Email must contain @.';
  if (!emailRegex.test(trimmed)) return 'Enter a valid email address.';

  return '';
}

function validateForm(form) {
  const emailError = validateEmail(form.email);
  if (emailError) return emailError;

  if (!/^\d{6}$/.test(form.code.trim())) {
    return 'Reset code must contain exactly 6 digits.';
  }

  if (!passwordRegex.test(form.newPassword)) {
    return 'Password must be at least 8 characters and include uppercase, lowercase, digit, and special character.';
  }

  if (form.newPassword !== form.confirmPassword) {
    return 'Passwords do not match.';
  }

  return '';
}

function ResetPasswordPage() {
  useSystemTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useAppLanguage();
  const initialEmail = location.state?.email || '';

  const [form, setForm] = useState({
    email: initialEmail,
    code: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(initialEmail ? 60 : 0);
  const [infoMessage, setInfoMessage] = useState(location.state?.infoMessage || '');
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (resendCooldown <= 0) {
      return undefined;
    }

    const timer = window.setInterval(() => {
      setResendCooldown((previous) => Math.max(previous - 1, 0));
    }, 1000);

    return () => window.clearInterval(timer);
  }, [resendCooldown]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    const nextValue = name === 'code' ? value.replace(/\D/g, '').slice(0, 6) : value;

    setForm((previous) => ({
      ...previous,
      [name]: nextValue,
    }));
    setError('');
    setInfoMessage('');
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (isSubmitting || successMessage) return;

    const validationError = validateForm(form);
    if (validationError) {
      setError(validationError);
      return;
    }

    const normalizedEmail = form.email.trim().toLowerCase();

    setIsSubmitting(true);
    setError('');

    try {
      const response = await resetPassword({
        email: normalizedEmail,
        code: form.code.trim(),
        newPassword: form.newPassword,
        confirmPassword: form.confirmPassword,
      });
      const responseMessage = response?.message || 'Password reset successfully. You can now log in.';

      setSuccessMessage(responseMessage);
      window.setTimeout(() => {
        navigate('/login', {
          replace: true,
          state: {
            email: normalizedEmail,
            successMessage: responseMessage,
          },
        });
      }, 2000);
    } catch (submitError) {
      setError(getApiErrorMessage(submitError, 'Code expired or invalid'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResend = async () => {
    if (isResending || resendCooldown > 0 || successMessage) return;

    const emailError = validateEmail(form.email);
    if (emailError) {
      setError(emailError);
      return;
    }

    const normalizedEmail = form.email.trim().toLowerCase();

    setIsResending(true);
    setError('');
    setInfoMessage('');

    try {
      const response = await resendPasswordResetCode(normalizedEmail);
      setInfoMessage(response?.message || 'If this email exists, we sent a new password reset code.');
      setResendCooldown(60);
    } catch (resendError) {
      setError(getApiErrorMessage(resendError, 'Unable to resend password reset code. Please try again.'));
      setResendCooldown(60);
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 py-8 sm:px-6 lg:px-8 bg-[#F5F6FA] dark:bg-[#181A20] transition-colors">
      <div className="w-full max-w-md">
        <div className="bg-white/85 dark:bg-[#1C1F26]/95 backdrop-blur-sm border border-indigo-100 dark:border-[#2F3440] rounded-2xl shadow-xl shadow-indigo-100/50 dark:shadow-none px-5 py-8 sm:px-8 sm:py-10 transition-colors">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center mb-4">
              <MessageCircle className="w-7 h-7 text-white" fill="white" strokeWidth={1.5} />
            </div>
            <h1 className="text-foreground tracking-tight text-center">Dialogly</h1>
            <p className="text-muted-foreground text-center mt-1 max-w-xs" style={{ fontSize: '0.9rem' }}>
              {t('auth.chooseNewPassword')}
            </p>
          </div>

          <h2 className="text-foreground mb-3 text-center sm:text-left">{t('auth.resetPasswordTitle')}</h2>
          <p className="text-sm text-muted-foreground mb-6">
            {t('auth.resetPasswordDescription')}
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" style={{ fontSize: '0.875rem' }}>
                {t('auth.email')}
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                value={form.email}
                onChange={handleChange}
                className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="code" style={{ fontSize: '0.875rem' }}>
                {t('auth.resetCode')}
              </label>
              <input
                id="code"
                name="code"
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={6}
                placeholder="123456"
                value={form.code}
                onChange={handleChange}
                className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="newPassword" style={{ fontSize: '0.875rem' }}>
                {t('auth.newPassword')}
              </label>
              <div className="relative">
                <input
                  id="newPassword"
                  name="newPassword"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={form.newPassword}
                  onChange={handleChange}
                  className="w-full min-w-0 px-4 py-2.5 pr-11 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                />
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={() => setShowPassword((previous) => !previous)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="confirmPassword" style={{ fontSize: '0.875rem' }}>
                {t('auth.confirmNewPassword')}
              </label>
              <div className="relative">
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  className="w-full min-w-0 px-4 py-2.5 pr-11 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                />
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={() => setShowConfirmPassword((previous) => !previous)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || Boolean(successMessage)}
              className="mt-2 w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white py-3 rounded-xl shadow-md shadow-indigo-200 dark:shadow-none transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isSubmitting ? t('auth.updatingPassword') : t('auth.resetPasswordTitle')}
            </button>

            <button
              type="button"
              onClick={handleResend}
              disabled={isResending || resendCooldown > 0 || Boolean(successMessage)}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl border border-indigo-200 bg-white px-4 py-2.5 text-sm text-indigo-700 transition hover:bg-indigo-50 disabled:cursor-not-allowed disabled:opacity-60 dark:border-[#37405A] dark:bg-[#151A25] dark:text-[#CBD5FF] dark:hover:bg-[#1E2433]"
            >
              <RefreshCcw className="w-4 h-4" />
              {isResending
                ? t('auth.sendingNewCode')
                : resendCooldown > 0
                  ? t('auth.resendCodeIn', { seconds: resendCooldown })
                  : t('auth.resendCode')}
            </button>

            {error ? <p className="text-destructive text-sm">{error}</p> : null}
            {infoMessage ? <p className="text-sm text-[#374151] dark:text-[#D1D5DB]">{infoMessage}</p> : null}
            {successMessage ? <p className="text-sm text-[#10B981]">{successMessage}</p> : null}
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {t('auth.returnTo')}{' '}
            <Link to="/login" className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors">
              {t('auth.signIn')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default ResetPasswordPage;
