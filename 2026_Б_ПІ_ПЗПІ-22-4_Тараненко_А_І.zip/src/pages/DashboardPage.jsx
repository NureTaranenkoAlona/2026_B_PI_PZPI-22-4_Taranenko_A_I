import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar from '../components/dashboard/Sidebar';
import ChatArea from '../components/dashboard/ChatArea';
import NoChatSelected from '../components/dashboard/NoChatSelected';
import NoChatsPage from '../components/dashboard/NoChatsPage';
import OnboardingTour from '../components/common/OnboardingTour';
import { useAccountContext } from '../context/AccountContext';
import { useAppLanguage } from '../context/AppLanguageContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import useNotifications from '../hooks/useNotifications';
import { getCurrentUserSettings, updateCurrentUserSettings } from '../api/userApi';
import { getArchivedChats, getChatById, getChats, getChatMessages, markChatAsRead, sendMessage, updateChatArchive, updateChatCustomDetails, updateMessageReaction } from '../api/chatApi';
import getApiErrorMessage from '../utils/getApiErrorMessage';
import { formatSidebarLastMessagePreview, mapChatDetails, mapChatListItem, mapChatMessage } from '../utils/chatUi';

const chatThemeStorageKey = 'dialogly-chat-theme';
const chatThemePreferenceKey = 'dialogly-chat-theme-preference';
const systemThemeQuery = '(prefers-color-scheme: dark)';

const sortChats = (chatList) =>
  [...chatList].sort((left, right) => {
    if (Boolean(left.isPinned) !== Boolean(right.isPinned)) {
      return left.isPinned ? -1 : 1;
    }

    const leftTime = left.timestampAt ? new Date(left.timestampAt).getTime() : 0;
    const rightTime = right.timestampAt ? new Date(right.timestampAt).getTime() : 0;
    return rightTime - leftTime;
  });

const buildMessageReactions = (dialoglyReaction, telegramReaction) => [
  dialoglyReaction ? { source: 'dialogly', emoji: dialoglyReaction } : null,
  telegramReaction ? { source: 'telegram', emoji: telegramReaction } : null,
].filter(Boolean);

const withDialoglyReaction = (message, dialoglyReaction) => {
  const telegramReaction = message.telegramReaction
    ?? message.reactions?.find((reaction) => reaction.source === 'telegram')?.emoji
    ?? null;

  return {
    ...message,
    reaction: dialoglyReaction,
    dialoglyReaction,
    telegramReaction,
    reactions: buildMessageReactions(dialoglyReaction, telegramReaction),
  };
};

const getInitialChatTheme = () => {
  const savedPreference = localStorage.getItem(chatThemePreferenceKey);
  const savedTheme = localStorage.getItem(chatThemeStorageKey);

  if (savedPreference === 'manual') {
    if (savedTheme === 'dark') return true;
    if (savedTheme === 'light') return false;
  }

  return window.matchMedia(systemThemeQuery).matches;
};

function DashboardPage() {
  const location = useLocation();
  const { activeContext } = useAccountContext();
  const { user } = useAuth();
  const { isRTL, t } = useAppLanguage();
  const { playSound, showPushNotification } = useNotifications();
  const { showError } = useToast();
  const [selectedId, setSelectedId] = useState(null);
  const [messages, setMessages] = useState({});
  const [chatDetails, setChatDetails] = useState({});
  const [chats, setChats] = useState([]);
  const [archivedChats, setArchivedChats] = useState([]);
  const [isLoadingChats, setIsLoadingChats] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isLoadingChatDetails, setIsLoadingChatDetails] = useState(false);
  const [pageError, setPageError] = useState('');
  const [chatListError, setChatListError] = useState('');
  const [messageLoadError, setMessageLoadError] = useState('');
  const [darkMode, setDarkMode] = useState(getInitialChatTheme);
  const [hasManualTheme, setHasManualTheme] = useState(() => {
    return localStorage.getItem(chatThemePreferenceKey) === 'manual';
  });
  const [tourStep, setTourStep] = useState(0);
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [hasLoadedTourSettings, setHasLoadedTourSettings] = useState(false);
  const hasBootstrappedChatsRef = useRef(false);
  const selectedIdRef = useRef(null);
  const sidebarRef = useRef(null);
  const filtersRef = useRef(null);
  const chatShellRef = useRef(null);
  const chatWindowRef = useRef(null);
  const composerRef = useRef(null);
  const settingsButtonRef = useRef(null);
  useEffect(() => {
    const root = document.documentElement;

    root.classList.toggle('dark', darkMode);
  }, [darkMode]);

  useEffect(() => {
    selectedIdRef.current = selectedId;
  }, [selectedId]);

  useEffect(() => {
    hasBootstrappedChatsRef.current = false;
    selectedIdRef.current = null;
    setSelectedId(null);
    setMessages({});
    setChatDetails({});
    setChats([]);
    setArchivedChats([]);
    setPageError('');
    setChatListError('');
    setMessageLoadError('');
    setIsLoadingChats(Boolean(user?.id));
    setIsLoadingMessages(false);
    setIsLoadingChatDetails(false);
  }, [user?.id]);

  useEffect(() => {
    if (hasManualTheme) {
      localStorage.setItem(chatThemePreferenceKey, 'manual');
      localStorage.setItem(chatThemeStorageKey, darkMode ? 'dark' : 'light');
      return;
    }

    localStorage.removeItem(chatThemePreferenceKey);
    localStorage.removeItem(chatThemeStorageKey);

    const matcher = window.matchMedia(systemThemeQuery);
    const handleChange = (event) => {
      setDarkMode(event.matches);
    };

    matcher.addEventListener('change', handleChange);

    return () => {
      matcher.removeEventListener('change', handleChange);
    };
  }, [darkMode, hasManualTheme]);

  const moveChatToTop = (chatList, chatId, updater) => {
    const targetChat = chatList.find((chat) => chat.id === chatId);
    if (!targetChat) return chatList;

    const updatedChat = updater(targetChat);
    const otherChats = chatList.filter((chat) => chat.id !== chatId);

    return [updatedChat, ...otherChats];
  };

  const loadChats = useCallback(async ({ resetSelection = false } = {}) => {
    if (!activeContext?.id || !user?.id) return;

    if (resetSelection) {
      setIsLoadingChats(true);
      setSelectedId(null);
      setMessages({});
      setChatDetails({});
      setArchivedChats([]);
    }

    setPageError('');
    setChatListError('');

    try {
      const response = await getChats();
      const nextChats = sortChats(response.map(mapChatListItem));

      setChats((previousChats) => {
        if (hasBootstrappedChatsRef.current && !resetSelection) {
          const previousById = new Map(previousChats.map((chat) => [chat.id, chat]));

          nextChats.forEach((chat) => {
            const previousChat = previousById.get(chat.id);
            const previousUnreadCount = previousChat?.unreadCount ?? 0;

            if (chat.id !== selectedIdRef.current && chat.unreadCount > previousUnreadCount) {
              playSound();
              showPushNotification(
                `New message from ${chat.name}`,
                chat.lastMessage || 'New attachment'
              );
            }
          });
        }

        hasBootstrappedChatsRef.current = true;
        return nextChats;
      });
    } catch (error) {
      if (resetSelection) {
        setChats([]);
      }

      setChatListError(getApiErrorMessage(error, 'Unable to load chats right now. Please try again.'));
    } finally {
      if (resetSelection) {
        setIsLoadingChats(false);
      }
    }
  }, [activeContext?.id, playSound, showPushNotification, user?.id]);

  const loadArchivedChats = useCallback(async () => {
    if (!activeContext?.id || !user?.id) return;

    try {
      const response = await getArchivedChats();
      setArchivedChats(sortChats(response.map(mapChatListItem)));
    } catch (error) {
      setChatListError(getApiErrorMessage(error, 'Unable to load archived chats right now.'));
    }
  }, [activeContext?.id, user?.id]);

  const loadChatMessages = useCallback(async (chatId, { markAsSeen = false, silent = false } = {}) => {
    if (!chatId) return;

    if (!silent) {
      setIsLoadingMessages(true);
    }

    setPageError('');
    if (!silent) {
      setMessageLoadError('');
    }

    try {
      const response = await getChatMessages(chatId);
      setMessages((prev) => ({
        ...prev,
        [chatId]: response.map(mapChatMessage),
      }));

      if (markAsSeen) {
        await markChatAsRead(chatId);
        setChats((prevChats) =>
          sortChats(prevChats.map((chat) =>
            chat.id === chatId ? { ...chat, unreadCount: 0 } : chat
          ))
        );
      }
    } catch (error) {
      if (!silent) {
        setMessageLoadError(getApiErrorMessage(error, 'Unable to load this conversation right now.'));
      }
    } finally {
      if (!silent) {
        setIsLoadingMessages(false);
      }
    }
  }, []);

  const loadChatDetails = useCallback(async (chatId) => {
    if (!chatId) return;

    setIsLoadingChatDetails(true);

    try {
      const response = await getChatById(chatId);
      setChatDetails((prev) => ({
        ...prev,
        [chatId]: mapChatDetails(response),
      }));
    } catch (error) {
      setPageError(
        getApiErrorMessage(error, 'Unable to load this contact right now.')
      );
    } finally {
      setIsLoadingChatDetails(false);
    }
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    loadChats({ resetSelection: true });
    loadArchivedChats();
  }, [loadArchivedChats, loadChats, user?.id]);

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const shouldForceTour = searchParams.get('tour') === '1';

    let isCancelled = false;

    const loadTourSettings = async () => {
      try {
        const settings = await getCurrentUserSettings();
        if (isCancelled) return;

        if (shouldForceTour || settings.isTourCompleted === false) {
          setTourStep(0);
          setIsTourOpen(true);
        } else {
          setIsTourOpen(false);
        }
      } catch {
        if (!isCancelled) {
          setIsTourOpen(false);
        }
      } finally {
        if (!isCancelled) {
          setHasLoadedTourSettings(true);
        }
      }
    };

    setHasLoadedTourSettings(false);
    loadTourSettings();

    return () => {
      isCancelled = true;
    };
  }, [location.search]);

  const handleSelectChat = async (chatId) => {
    setSelectedId(chatId);
    await Promise.all([
      loadChatMessages(chatId, { markAsSeen: true, silent: false }),
      loadChatDetails(chatId),
    ]);
  };

  const handleSendMessage = async ({ text, attachments = [], gifUrl = '' }) => {
    if (selectedId === null) return;

    const trimmedText = text.trim();
    const trimmedGifUrl = gifUrl.trim();
    const payloadText =
      trimmedText || trimmedGifUrl || (attachments.length > 0 ? `Sent ${attachments.length} attachment` : '');

    if (!payloadText) return;

    try {
      const response = await sendMessage(selectedId, {
        text: trimmedText,
        gifUrl: trimmedGifUrl,
        attachments,
      });
      const newMessage = mapChatMessage(response);

      setMessages((prev) => ({
        ...prev,
        [selectedId]: [...(prev[selectedId] ?? []), newMessage],
      }));

      setChats((prevChats) =>
        sortChats(moveChatToTop(prevChats, selectedId, (chat) => ({
          ...chat,
          lastMessage: formatSidebarLastMessagePreview(
            response.gifUrl
              ? 'GIF'
              : response.text || (response.attachments?.length > 0
                ? ((response.attachments[0]?.contentType || response.attachments[0]?.mimeType || '').startsWith('image/')
                  ? 'Photo'
                  : 'File')
                : 'No messages yet')
          ),
          timestampAt: response.createdAt,
          unreadCount: 0,
        })))
      );
      return response;
    } catch (error) {
      setPageError(getApiErrorMessage(error, 'Unable to send your message right now.'));
      throw error;
    }
  };

  const handleToggleReaction = async (messageId, emoji) => {
    if (!selectedId || !messageId || !emoji) return;

    const chatId = selectedId;
    const chatMessages = messages[chatId] ?? [];
    const targetMessage = chatMessages.find((message) => message.id === messageId);

    if (!targetMessage) return;

    const previousReaction = targetMessage.dialoglyReaction ?? targetMessage.reaction ?? null;
    const nextReaction = previousReaction === emoji ? null : emoji;

    try {
      setMessages((prev) => {
        const currentChatMessages = prev[chatId];
        if (!Array.isArray(currentChatMessages)) {
          return prev;
        }

        return {
          ...prev,
          [chatId]: currentChatMessages.map((message) =>
            message.id === messageId ? withDialoglyReaction(message, nextReaction) : message
          ),
        };
      });

      const response = await updateMessageReaction(messageId, nextReaction);
      const updatedMessage = mapChatMessage(response);

      setMessages((prev) => {
        const currentChatMessages = prev[chatId];
        if (!Array.isArray(currentChatMessages)) {
          return prev;
        }

        return {
          ...prev,
          [chatId]: currentChatMessages.map((message) =>
            message.id === messageId ? { ...message, ...updatedMessage } : message
          ),
        };
      });
    } catch (error) {
      console.error('Failed to toggle message reaction', error);
      setMessages((prev) => {
        const currentChatMessages = prev[chatId];
        if (!Array.isArray(currentChatMessages)) {
          return prev;
        }

        return {
          ...prev,
          [chatId]: currentChatMessages.map((message) =>
            message.id === messageId ? withDialoglyReaction(message, previousReaction) : message
          ),
        };
      });
      showError(getApiErrorMessage(error, 'Unable to update this reaction right now.'));
    }
  };

  const handleUpdateChatDetails = async (chatId, payload) => {
    const response = await updateChatCustomDetails(chatId, payload);
    const mappedDetails = mapChatDetails(response);

    setChatDetails((prev) => ({
      ...prev,
      [chatId]: mappedDetails,
    }));

    setChats((prevChats) =>
      sortChats(prevChats.map((chat) =>
        chat.id === chatId
          ? {
              ...chat,
              name: mappedDetails.name,
              originalName: mappedDetails.originalName,
              customName: mappedDetails.customName,
              initials: mappedDetails.initials,
              avatarColor: mappedDetails.avatarColor,
              isPinned: mappedDetails.isPinned,
              isArchived: mappedDetails.isArchived,
            }
          : chat
      ))
    );

    setArchivedChats((prevChats) =>
      sortChats(prevChats.map((chat) =>
        chat.id === chatId
          ? {
              ...chat,
              name: mappedDetails.name,
              originalName: mappedDetails.originalName,
              customName: mappedDetails.customName,
              initials: mappedDetails.initials,
              avatarColor: mappedDetails.avatarColor,
              isPinned: mappedDetails.isPinned,
              isArchived: mappedDetails.isArchived,
            }
          : chat
      ))
    );
  };

  const handleTogglePin = async (chatId) => {
    const currentChat = chats.find((chat) => chat.id === chatId) ?? archivedChats.find((chat) => chat.id === chatId);
    if (!currentChat) return;

    try {
      const response = await updateChatCustomDetails(chatId, {
        isPinned: !currentChat.isPinned,
      });
      const mappedDetails = mapChatDetails(response);

      const applyUpdate = (chat) =>
        chat.id === chatId
          ? {
              ...chat,
              name: mappedDetails.name,
              originalName: mappedDetails.originalName,
              customName: mappedDetails.customName,
              initials: mappedDetails.initials,
              avatarColor: mappedDetails.avatarColor,
              isPinned: mappedDetails.isPinned,
              isArchived: mappedDetails.isArchived,
            }
          : chat;

      setChatDetails((prev) => ({
        ...prev,
        [chatId]: mappedDetails,
      }));
      setChats((prev) => sortChats(prev.map(applyUpdate)));
      setArchivedChats((prev) => sortChats(prev.map(applyUpdate)));
    } catch (error) {
      const nextError = getApiErrorMessage(error, 'Unable to update the pinned state right now.');
      setPageError(nextError);
      showError(nextError);
    }
  };

  const handleArchiveToggle = async (chatId, isArchived) => {
    const currentChat = chats.find((chat) => chat.id === chatId) ?? archivedChats.find((chat) => chat.id === chatId);
    if (!currentChat) return;

    try {
      const response = await updateChatArchive(chatId, { isArchived });
      const mappedDetails = mapChatDetails(response);
      const mappedChat = {
        ...currentChat,
        name: mappedDetails.name,
        originalName: mappedDetails.originalName,
        customName: mappedDetails.customName,
        initials: mappedDetails.initials,
        avatarColor: mappedDetails.avatarColor,
        isPinned: mappedDetails.isPinned,
        isArchived: mappedDetails.isArchived,
      };

      setChatDetails((prev) => ({
        ...prev,
        [chatId]: mappedDetails,
      }));

      if (isArchived) {
        setChats((prev) => prev.filter((chat) => chat.id !== chatId));
        setArchivedChats((prev) => sortChats([mappedChat, ...prev.filter((chat) => chat.id !== chatId)]));
        if (selectedId === chatId) {
          setSelectedId(null);
        }
      } else {
        setArchivedChats((prev) => prev.filter((chat) => chat.id !== chatId));
        setChats((prev) => sortChats([mappedChat, ...prev.filter((chat) => chat.id !== chatId)]));
      }
    } catch (error) {
      const nextError = getApiErrorMessage(error, 'Unable to update archive state right now.');
      setPageError(nextError);
      showError(nextError);
    }
  };

  const selectedChatListItem =
    chats.find((chat) => chat.id === selectedId)
    ?? archivedChats.find((chat) => chat.id === selectedId)
    ?? null;
  const selectedChat = selectedId !== null
    ? {
        ...(selectedChatListItem ?? {}),
        ...(chatDetails[selectedId] ?? {}),
      }
    : null;
  const currentMessages = selectedId !== null ? messages[selectedId] ?? [] : [];

  useEffect(() => {
    if (!activeContext?.id || !user?.id) return undefined;

    const intervalId = window.setInterval(() => {
      loadChats({ resetSelection: false });
      loadArchivedChats();
    }, 5000);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [activeContext?.id, loadArchivedChats, loadChats, user?.id]);

  useEffect(() => {
    if (!activeContext?.id || !selectedId || !user?.id) return undefined;

    const intervalId = window.setInterval(() => {
      loadChatMessages(selectedId, { markAsSeen: true, silent: true });
    }, 5000);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [activeContext?.id, loadChatMessages, selectedId, user?.id]);

  const handleToggleTheme = () => {
    setHasManualTheme(true);
    setDarkMode((prev) => !prev);
  };

  const tourSteps = useMemo(() => {
    const getRectFromRef = (targetRef, fallbackRef = null) => () =>
      targetRef.current?.getBoundingClientRect() ?? fallbackRef?.current?.getBoundingClientRect() ?? null;

    return [
      {
        id: 'welcome',
        kind: 'welcome',
      },
      {
        id: 'sidebar',
        title: t('tour.sidebarTitle'),
        text: t('tour.sidebarText'),
        placement: 'right',
        getRect: getRectFromRef(sidebarRef),
      },
      {
        id: 'filters',
        title: t('tour.filtersTitle'),
        text: t('tour.filtersText'),
        placement: 'bottom-left',
        getRect: getRectFromRef(filtersRef, sidebarRef),
      },
      {
        id: 'chat',
        title: t('tour.chatTitle'),
        text: t('tour.chatText'),
        placement: 'top-right',
        getRect: () => null,
      },
      {
        id: 'composer',
        title: t('tour.composerTitle'),
        text: t('tour.composerText'),
        placement: 'top-left',
        getRect: getRectFromRef(composerRef, chatShellRef),
      },
      {
        id: 'settings',
        title: t('tour.settingsTitle'),
        text: t('tour.settingsText'),
        placement: 'top-right',
        getRect: getRectFromRef(settingsButtonRef, sidebarRef),
      },
    ];
  }, [t]);

  const handleNextTourStep = () => {
    setTourStep((currentStep) => {
      if (currentStep >= tourSteps.length - 1) {
        void updateCurrentUserSettings({ isTourCompleted: true });
        setIsTourOpen(false);
        return currentStep;
      }

      return currentStep + 1;
    });
  };

  const handleSkipTour = () => {
    void updateCurrentUserSettings({ isTourCompleted: true });
    setIsTourOpen(false);
  };

  return (
    <div className={`h-screen flex overflow-hidden bg-white dark:bg-[#181A20] ${isRTL ? 'flex-row-reverse' : ''}`}>
      <Sidebar
        chats={chats}
        archivedChats={archivedChats}
        selectedId={selectedId}
        onSelect={handleSelectChat}
        onTogglePin={handleTogglePin}
        onArchive={handleArchiveToggle}
        darkMode={darkMode}
        onToggleTheme={handleToggleTheme}
        isLoading={isLoadingChats}
        errorMessage={chatListError}
        onRetry={() => {
          loadChats({ resetSelection: true });
          loadArchivedChats();
        }}
        tourSidebarRef={sidebarRef}
        tourFiltersRef={filtersRef}
        tourSettingsButtonRef={settingsButtonRef}
      />

      <div ref={chatShellRef} className="flex-1 flex flex-col overflow-hidden">
        {pageError && chats.length === 0 && !isLoadingChats ? (
          <div className="flex-1 flex items-center justify-center bg-[#F5F6FA] dark:bg-[#181A20] px-6">
            <div className="rounded-2xl border border-[#FECACA] dark:border-[#7F1D1D] bg-[#FEF2F2] dark:bg-[#311313] p-5 text-sm text-[#991B1B] dark:text-[#FCA5A5] max-w-md text-center">
              {pageError}
            </div>
          </div>
        ) : isLoadingChats ? (
          <div className="flex-1 flex items-center justify-center bg-[#F5F6FA] dark:bg-[#181A20] px-6">
            <div className="flex items-center gap-3 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
              <div className="w-5 h-5 rounded-full border-2 border-[#EEF0FE] border-t-[#5B6CF8] animate-spin" />
              Loading chats...
            </div>
          </div>
        ) : chats.length === 0 && archivedChats.length === 0 ? (
          <NoChatsPage />
        ) : selectedChat === null ? (
          <NoChatSelected />
        ) : (
          <ChatArea
            key={selectedChat.id}
            chat={selectedChat}
            messages={currentMessages}
            onSendMessage={handleSendMessage}
            onToggleReaction={handleToggleReaction}
            onUpdateChatDetails={handleUpdateChatDetails}
            isLoadingMessages={isLoadingMessages}
            isLoadingChatDetails={isLoadingChatDetails}
            messageLoadError={messageLoadError}
            onRetryMessages={() => loadChatMessages(selectedChat.id, { markAsSeen: true, silent: false })}
            tourChatWindowRef={chatWindowRef}
            tourComposerRef={composerRef}
          />
        )}
      </div>

      <OnboardingTour
        isOpen={hasLoadedTourSettings && isTourOpen}
        steps={tourSteps}
        currentStep={tourStep}
        onNext={handleNextTourStep}
        onSkip={handleSkipTour}
      />
    </div>
  );
}

export default DashboardPage;
