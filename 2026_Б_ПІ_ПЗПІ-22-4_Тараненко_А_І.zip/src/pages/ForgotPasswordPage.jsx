import { useState } from 'react';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { forgotPassword } from '../api/authApi';
import { useAppLanguage } from '../context/AppLanguageContext';
import useSystemTheme from '../hooks/useSystemTheme';
import getApiErrorMessage from '../utils/getApiErrorMessage';

const neutralMessage = 'If this email exists, we sent a password reset code.';

function validateEmail(value) {
  const trimmed = value.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!trimmed) return 'Email is required.';
  if (trimmed.length > 254) return 'Email is too long.';
  if (!trimmed.includes('@')) return 'Email must contain @.';
  if (!emailRegex.test(trimmed)) return 'Enter a valid email address.';

  return '';
}

function ForgotPasswordPage() {
  useSystemTheme();
  const navigate = useNavigate();
  const { t } = useAppLanguage();

  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (isSubmitting) return;

    const validationError = validateEmail(email);
    if (validationError) {
      setError(validationError);
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();

    setIsSubmitting(true);
    setError('');
    setMessage('');

    try {
      const response = await forgotPassword(normalizedEmail);
      const responseMessage = response?.message || neutralMessage;

      setMessage(responseMessage);
      window.setTimeout(() => {
        navigate('/reset-password', {
          state: {
            email: normalizedEmail,
            infoMessage: responseMessage,
          },
        });
      }, 700);
    } catch (submitError) {
      setError(getApiErrorMessage(submitError, 'Unable to send password reset code. Please try again.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 py-8 sm:px-6 lg:px-8 bg-[#F5F6FA] dark:bg-[#181A20] transition-colors">
      <div className="w-full max-w-md">
        <div className="bg-white/85 dark:bg-[#1C1F26]/95 backdrop-blur-sm border border-indigo-100 dark:border-[#2F3440] rounded-2xl shadow-xl shadow-indigo-100/50 dark:shadow-none px-5 py-8 sm:px-8 sm:py-10 transition-colors">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center mb-4">
              <MessageCircle className="w-7 h-7 text-white" fill="white" strokeWidth={1.5} />
            </div>
            <h1 className="text-foreground tracking-tight text-center">Dialogly</h1>
            <p className="text-muted-foreground text-center mt-1 max-w-xs" style={{ fontSize: '0.9rem' }}>
              {t('auth.resetAccess')}
            </p>
          </div>

          <h2 className="text-foreground mb-3 text-center sm:text-left">{t('auth.forgotPasswordTitle')}</h2>
          <p className="text-sm text-muted-foreground mb-6">
            {t('auth.forgotPasswordDescription')}
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" style={{ fontSize: '0.875rem' }}>
                {t('auth.email')}
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                placeholder={t('auth.emailPlaceholder')}
                value={email}
                onChange={(event) => {
                  setEmail(event.target.value);
                  setError('');
                  setMessage('');
                }}
                className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="mt-2 w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white py-3 rounded-xl shadow-md shadow-indigo-200 dark:shadow-none transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isSubmitting ? t('auth.sendingCode') : t('auth.sendResetCode')}
              <ArrowRight className="w-4 h-4" />
            </button>

            {error ? <p className="text-destructive text-sm">{error}</p> : null}
            {message ? <p className="text-sm text-[#10B981]">{message}</p> : null}
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {t('auth.rememberedPassword')}{' '}
            <Link to="/login" className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors">
              {t('auth.signIn')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default ForgotPasswordPage;
