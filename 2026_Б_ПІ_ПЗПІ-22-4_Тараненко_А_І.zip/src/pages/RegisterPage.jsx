import { useEffect, useState } from 'react';
import { Check, Eye, EyeOff, MessageCircle, ArrowRight, MailCheck, RefreshCw } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { resendVerificationCode, verifyEmail } from '../api/authApi';
import { useAuth } from '../context/AuthContext';
import { useAppLanguage } from '../context/AppLanguageContext';
import useSystemTheme from '../hooks/useSystemTheme';
import getApiErrorMessage from '../utils/getApiErrorMessage';

function RegisterPage() {
  const navigate = useNavigate();
  useSystemTheme();
  const { register } = useAuth();
  const { t } = useAppLanguage();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [verificationEmail, setVerificationEmail] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [verificationError, setVerificationError] = useState('');
  const [verificationMessage, setVerificationMessage] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [resendCountdown, setResendCountdown] = useState(0);

  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (!verificationEmail || resendCountdown <= 0) return undefined;

    const timer = window.setInterval(() => {
      setResendCountdown((current) => Math.max(current - 1, 0));
    }, 1000);

    return () => window.clearInterval(timer);
  }, [resendCountdown, verificationEmail]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: '',
      form: '',
    }));
  };

  const validateName = (value, fieldLabel) => {
    const trimmed = value.trim();
    const nameRegex = /^[A-Za-zА-Яа-яІіЇїЄєҐґ'’-]+$/;

    if (!trimmed) return `${fieldLabel} is required.`;
    if (trimmed.length > 40) return `${fieldLabel} must be no longer than 40 characters.`;
    if (!nameRegex.test(trimmed)) {
      return `${fieldLabel} can contain only letters, apostrophe, or hyphen.`;
    }

    return '';
  };

  const validateDateOfBirth = (value) => {
    if (!value) return 'Date of birth is required.';

    const birthDate = new Date(value);
    const today = new Date();

    if (birthDate > today) return 'Date of birth cannot be in the future.';

    const minDate = new Date();
    minDate.setFullYear(today.getFullYear() - 120);

    if (birthDate < minDate) return 'Age cannot be more than 120 years.';

    return '';
  };

  const validateEmail = (value) => {
    const trimmed = value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!trimmed) return 'Email is required.';
    if (trimmed.length > 254) return 'Email is too long.';
    if (!trimmed.includes('@')) return 'Email must contain @.';
    if (!emailRegex.test(trimmed)) return 'Enter a valid email address.';

    return '';
  };

  const validatePassword = (value) => {
    if (!value) return 'Password is required.';
    if (value.length < 8) return 'Password must be at least 8 characters long.';
    if (!/[A-Z]/.test(value)) return 'Password must contain at least one uppercase letter.';
    if (!/[a-z]/.test(value)) return 'Password must contain at least one lowercase letter.';
    if (!/\d/.test(value)) return 'Password must contain at least one digit.';
    if (!/[^A-Za-z0-9]/.test(value)) {
      return 'Password must contain at least one special character.';
    }

    return '';
  };

  const validateConfirmPassword = (password, confirmPassword) => {
    if (!confirmPassword) return 'Please confirm your password.';
    if (password !== confirmPassword) return 'Passwords do not match.';
    return '';
  };

  const validateForm = () => {
    const newErrors = {
      firstName: validateName(form.firstName, 'First name'),
      lastName: validateName(form.lastName, 'Last name'),
      dateOfBirth: validateDateOfBirth(form.dateOfBirth),
      email: validateEmail(form.email),
      password: validatePassword(form.password),
      confirmPassword: validateConfirmPassword(form.password, form.confirmPassword),
      agreed: !agreed ? t('auth.mustAgreeToTerms') : '',
    };

    setErrors(newErrors);

    return !Object.values(newErrors).some(Boolean);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isSubmitting) return;
    if (!validateForm()) return;

    const submitRegistration = async () => {
      setIsSubmitting(true);
      setErrors((prev) => ({ ...prev, form: '' }));

      try {
        const registrationResult = await register({
          firstName: form.firstName.trim(),
          lastName: form.lastName.trim(),
          dateOfBirth: form.dateOfBirth,
          email: form.email.trim().toLowerCase(),
          password: form.password,
          confirmPassword: form.confirmPassword,
          agreedToTerms: Boolean(agreed),
        });

        if (registrationResult?.requiresVerification) {
          const email = form.email.trim().toLowerCase();
          setVerificationEmail(email);
          setVerificationCode('');
          setVerificationError('');
          setVerificationMessage(
            registrationResult.message || 'We sent a verification code to your email'
          );
          setResendCountdown(60);
          return;
        }

        const { user } = registrationResult;

        if (!user?.isOnboardingCompleted) {
          navigate('/post-login', {
            state: {
              email: form.email.trim().toLowerCase(),
            },
            replace: true,
          });
          return;
        }

        navigate('/chats', { replace: true });
      } catch (error) {
        const message =
          error.message === 'TOKEN_MISSING'
            ? 'Server did not return an authentication token.'
            : getApiErrorMessage(error, 'Unable to create your account. Please try again.');

        setErrors((prev) => ({
          ...prev,
          form: message,
        }));
      } finally {
        setIsSubmitting(false);
      }
    };

    submitRegistration();
  };

  const handleVerificationCodeChange = (e) => {
    setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6));
    setVerificationError('');
  };

  const handleVerifyEmail = (e) => {
    e.preventDefault();

    if (isVerifying) return;

    if (verificationCode.length !== 6) {
      setVerificationError('Verification code must contain exactly 6 digits.');
      return;
    }

    const submitVerification = async () => {
      setIsVerifying(true);
      setVerificationError('');

      try {
        const response = await verifyEmail(verificationEmail, verificationCode);
        setVerificationMessage(response.message || 'Email verified successfully');

        window.setTimeout(() => {
          navigate('/login', {
            replace: true,
            state: {
              email: verificationEmail,
              successMessage: 'Email verified. You can now log in.',
            },
          });
        }, 800);
      } catch (error) {
        setVerificationError(getApiErrorMessage(error, 'Unable to verify email. Please try again.'));
      } finally {
        setIsVerifying(false);
      }
    };

    submitVerification();
  };

  const handleResendVerificationCode = () => {
    if (isResending || resendCountdown > 0) return;

    const submitResend = async () => {
      setIsResending(true);
      setVerificationError('');

      try {
        const response = await resendVerificationCode(verificationEmail);
        setVerificationMessage(response.message || 'New verification code sent');
        setResendCountdown(60);
      } catch (error) {
        setVerificationError(getApiErrorMessage(error, 'Unable to resend verification code.'));
      } finally {
        setIsResending(false);
      }
    };

    submitResend();
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 py-8 sm:px-6 lg:px-8 bg-[#F5F6FA] dark:bg-[#181A20] transition-colors">
      <div className="w-full max-w-md">
        <div className="bg-white/85 dark:bg-[#1C1F26]/95 backdrop-blur-sm border border-indigo-100 dark:border-[#2F3440] rounded-2xl shadow-xl shadow-indigo-100/50 dark:shadow-none px-5 py-8 sm:px-8 sm:py-10 transition-colors">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center mb-4">
              <MessageCircle className="w-7 h-7 text-white" fill="white" strokeWidth={1.5} />
            </div>
            <h1 className="text-foreground tracking-tight text-center">Dialogly</h1>
            <p className="text-muted-foreground text-center mt-1 max-w-xs" style={{ fontSize: '0.9rem' }}>
              {t('auth.appTagline')}
            </p>
          </div>

          {verificationEmail ? (
            <div className="flex flex-col gap-5">
              <div className="text-center">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-50 dark:bg-[#232842] text-indigo-600 dark:text-indigo-300 flex items-center justify-center mb-4">
                  <MailCheck className="w-7 h-7" />
                </div>
                <h2 className="text-foreground mb-2">{t('auth.verifyEmailTitle')}</h2>
                <p className="text-muted-foreground" style={{ fontSize: '0.9rem' }}>
                  {t('auth.verificationSent')}
                </p>
                <p className="text-foreground mt-2 break-all" style={{ fontSize: '0.9rem' }}>
                  {verificationEmail}
                </p>
              </div>

              {verificationMessage && (
                <p className="text-emerald-600 dark:text-emerald-400 text-sm text-center">
                  {verificationMessage}
                </p>
              )}

              <form onSubmit={handleVerifyEmail} className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="verificationCode" style={{ fontSize: '0.875rem' }}>
                    {t('auth.verificationCode')}
                  </label>
                  <input
                    id="verificationCode"
                    name="verificationCode"
                    type="text"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    placeholder="123456"
                    value={verificationCode}
                    onChange={handleVerificationCodeChange}
                    maxLength={6}
                    className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60 tracking-[0.35em] text-center"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isVerifying}
                  className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white py-3 rounded-xl shadow-md shadow-indigo-200 dark:shadow-none transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isVerifying ? t('auth.verifying') : t('auth.verify')}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {verificationError && (
                <p className="text-destructive text-sm text-center">{verificationError}</p>
              )}

              <button
                type="button"
                onClick={handleResendVerificationCode}
                disabled={isResending || resendCountdown > 0}
                className="w-full flex items-center justify-center gap-2 rounded-xl border border-border bg-white dark:bg-[#232833] px-4 py-3 text-sm text-foreground hover:border-indigo-400 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
              >
                <RefreshCw className={`w-4 h-4 ${isResending ? 'animate-spin' : ''}`} />
                {resendCountdown > 0
                  ? t('auth.resendCodeIn', { seconds: resendCountdown })
                  : isResending
                    ? t('auth.sendingCode')
                    : t('auth.resendCode')}
              </button>

              <p className="text-center text-muted-foreground" style={{ fontSize: '0.875rem' }}>
                {t('auth.alreadyVerified')}{' '}
                <Link
                  to="/login"
                  state={{ email: verificationEmail }}
                  className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors"
                >
                  {t('auth.signIn')}
                </Link>
              </p>
            </div>
          ) : (
            <>
            <h2 className="text-foreground mb-6 text-center sm:text-left">{t('auth.createAccountTitle')}</h2>

            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <label htmlFor="firstName" style={{ fontSize: '0.875rem' }}>{t('auth.firstName')}</label>
                <input
                  id="firstName"
                  name="firstName"
                  type="text"
                  autoComplete="given-name"
                  placeholder={t('auth.firstNamePlaceholder')}
                  value={form.firstName}
                  onChange={handleChange}
                  className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                />
                {errors.firstName && <p className="text-destructive text-sm">{errors.firstName}</p>}
              </div>

              <div className="flex flex-col gap-1.5">
                <label htmlFor="lastName" style={{ fontSize: '0.875rem' }}>{t('auth.lastName')}</label>
                <input
                  id="lastName"
                  name="lastName"
                  type="text"
                  autoComplete="family-name"
                  placeholder={t('auth.lastNamePlaceholder')}
                  value={form.lastName}
                  onChange={handleChange}
                  className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                />
                {errors.lastName && <p className="text-destructive text-sm">{errors.lastName}</p>}
              </div>

              <div className="flex flex-col gap-1.5">
                <label htmlFor="dateOfBirth" style={{ fontSize: '0.875rem' }}>{t('auth.dateOfBirth')}</label>
                <input
                  id="dateOfBirth"
                  name="dateOfBirth"
                  type="date"
                  value={form.dateOfBirth}
                  onChange={handleChange}
                  className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all"
                />
                {errors.dateOfBirth && <p className="text-destructive text-sm">{errors.dateOfBirth}</p>}
              </div>

              <div className="flex flex-col gap-1.5">
                <label htmlFor="email" style={{ fontSize: '0.875rem' }}>{t('auth.email')}</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  placeholder={t('auth.emailPlaceholder')}
                  value={form.email}
                  onChange={handleChange}
                  className="w-full min-w-0 px-4 py-2.5 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                />
                {errors.email && <p className="text-destructive text-sm">{errors.email}</p>}
              </div>

              <div className="flex flex-col gap-1.5">
                <label htmlFor="password" style={{ fontSize: '0.875rem' }}>{t('auth.password')}</label>
                <div className="relative">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="new-password"
                    placeholder="••••••••"
                    value={form.password}
                    onChange={handleChange}
                    className="w-full min-w-0 px-4 py-2.5 pr-11 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errors.password && <p className="text-destructive text-sm">{errors.password}</p>}
              </div>

              <div className="flex flex-col gap-1.5">
                <label htmlFor="confirmPassword" style={{ fontSize: '0.875rem' }}>{t('auth.confirmNewPassword')}</label>
                <div className="relative">
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showConfirm ? 'text' : 'password'}
                    autoComplete="new-password"
                    placeholder="••••••••"
                    value={form.confirmPassword}
                    onChange={handleChange}
                    className="w-full min-w-0 px-4 py-2.5 pr-11 rounded-xl border border-border bg-input-background dark:bg-[#232833] focus:bg-white dark:focus:bg-[#1F2430] focus:outline-none focus:ring-2 focus:ring-indigo-400/60 focus:border-indigo-400 transition-all placeholder:text-muted-foreground/60"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setShowConfirm(!showConfirm)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="text-destructive text-sm">{errors.confirmPassword}</p>
                )}
              </div>

              <label className="flex items-start gap-3 cursor-pointer group mt-1">
                <div
                  onClick={() => {
                    setAgreed(!agreed);
                    setErrors((prev) => ({ ...prev, agreed: '' }));
                  }}
                  className={`mt-0.5 w-5 h-5 flex-shrink-0 rounded-md border-2 flex items-center justify-center transition-all ${
                    agreed
                      ? 'bg-indigo-600 border-indigo-600'
                      : 'bg-white dark:bg-[#232833] border-border group-hover:border-indigo-400'
                  }`}
                >
                  {agreed && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                </div>

                <span className="text-muted-foreground select-none leading-6" style={{ fontSize: '0.875rem' }}>
                  {t('auth.agreePrefix')}
                  <Link
                    to="/terms"
                    target="_blank"
                    rel="noreferrer"
                    className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors"
                  >
                    {t('auth.termsOfUse')}
                  </Link>{' '}
                  {t('auth.agreeMiddle')}
                  <Link
                    to="/privacy"
                    target="_blank"
                    rel="noreferrer"
                    className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors"
                  >
                    {t('auth.privacyPolicy')}
                  </Link>
                </span>
              </label>
              {errors.agreed && <p className="text-destructive text-sm">{errors.agreed}</p>}

              <button
                type="submit"
                disabled={isSubmitting}
                className="mt-2 w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white py-3 rounded-xl shadow-md shadow-indigo-200 dark:shadow-none transition-all duration-200"
              >
                {isSubmitting ? t('auth.creatingAccount') : t('auth.signUpButton')}
                <ArrowRight className="w-4 h-4" />
              </button>
              {errors.form && <p className="text-destructive text-sm">{errors.form}</p>}
            </form>

            <p className="text-center text-muted-foreground mt-6" style={{ fontSize: '0.875rem' }}>
              {t('auth.alreadyHaveAccount')}{' '}
              <Link
                to="/login"
                className="text-indigo-600 hover:text-indigo-700 underline underline-offset-2 transition-colors"
              >
                {t('auth.signIn')}
              </Link>
            </p>
            </>
          )}
        </div>

        <div className="mt-5 text-center text-muted-foreground/60" style={{ fontSize: '0.78rem' }}>
          <p>
            © 2026 Dialogly ·{' '}
            <Link to="/terms" target="_blank" rel="noreferrer" className="hover:text-indigo-600 transition-colors">
              {t('auth.termsShort')}
            </Link>{' '}
            ·{' '}
            <Link to="/privacy" target="_blank" rel="noreferrer" className="hover:text-indigo-600 transition-colors">
              {t('auth.privacyShort')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default RegisterPage;
