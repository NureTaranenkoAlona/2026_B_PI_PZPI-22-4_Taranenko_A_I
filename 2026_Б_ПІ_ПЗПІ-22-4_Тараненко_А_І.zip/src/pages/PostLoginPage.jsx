import { Navigate } from 'react-router-dom';
import WorkspaceModal from '../components/onboarding/WorkspaceModal';
import { useAuth } from '../context/AuthContext';
import useSystemTheme from '../hooks/useSystemTheme';

function PostLoginPage() {
  useSystemTheme();
  const { user } = useAuth();

  if (user?.isOnboardingCompleted) {
    return <Navigate to="/chats" replace />;
  }

  if (
    user?.onboardingWorkspaceChoice === 'joined'
    || user?.onboardingWorkspaceChoice === 'created'
    || user?.onboardingWorkspaceChoice === 'personal'
  ) {
    return (
      <Navigate
        to="/onboarding"
        replace
        state={{ workspaceChoice: user.onboardingWorkspaceChoice }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F6FA] dark:bg-[#181A20]">
      <WorkspaceModal />
    </div>
  );
}

export default PostLoginPage;
