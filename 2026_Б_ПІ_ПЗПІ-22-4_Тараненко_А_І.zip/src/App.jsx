import { useState } from 'react';
import AppRouter from './router/AppRouter';
import { AuthProvider } from './context/AuthContext';
import { AppLanguageProvider } from './context/AppLanguageContext';
import { AppPreferencesProvider } from './context/AppPreferencesContext';
import { AccountProvider } from './context/AccountContext';
import { ToastProvider } from './context/ToastContext';
import SplashScreen from './components/common/SplashScreen';

function App() {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <AppLanguageProvider>
      <>
        <AuthProvider>
          <AccountProvider>
            <AppPreferencesProvider>
              <ToastProvider>
                <AppRouter />
              </ToastProvider>
            </AppPreferencesProvider>
          </AccountProvider>
        </AuthProvider>

        {showSplash ? <SplashScreen onFinish={() => setShowSplash(false)} /> : null}
      </>
    </AppLanguageProvider>
  );
}

export default App;
