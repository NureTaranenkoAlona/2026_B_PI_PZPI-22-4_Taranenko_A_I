const createTimestamp = (dayOffset, hours, minutes) => {
  const date = new Date();
  date.setSeconds(0, 0);
  date.setDate(date.getDate() + dayOffset);
  date.setHours(hours, minutes, 0, 0);

  return date.toISOString();
};

export const mockChats = [
  {
    id: 1,
    name: 'Alex Johnson',
    initials: 'AJ',
    avatarColor: '#5B6CF8',
    lastMessage: 'Sure, sounds good! Keep me posted',
    timestampAt: createTimestamp(0, 10, 42),
    unreadCount: 2,
    online: true,
    platform: 'telegram',
  },
  {
    id: 2,
    name: 'Team Design',
    initials: 'TD',
    avatarColor: '#10B981',
    lastMessage: "I'll share the files tomorrow morning",
    timestampAt: createTimestamp(0, 9, 30),
    unreadCount: 3,
    online: false,
    platform: 'messenger',
  },
  {
    id: 3,
    name: 'Sarah Miller',
    initials: 'SM',
    avatarColor: '#8B5CF6',
    lastMessage: 'Can we meet tomorrow to discuss?',
    timestampAt: createTimestamp(-1, 18, 40),
    unreadCount: 5,
    online: true,
    platform: 'telegram',
  },
  {
    id: 4,
    name: 'John Doe',
    initials: 'JD',
    avatarColor: '#F59E0B',
    lastMessage: 'Thanks for the update! Looking good',
    timestampAt: createTimestamp(-1, 16, 25),
    unreadCount: 0,
    online: false,
    platform: 'messenger',
  },
];

export const mockMessages = {
  1: [
    {
      id: 1,
      chatId: 1,
      text: "Hey! Hope you're doing well 👋",
      sender: 'them',
      createdAt: createTimestamp(0, 10, 15),
    },
    {
      id: 2,
      chatId: 1,
      text: "Hey Alex! I'm doing great, thanks. Been working on something really exciting lately.",
      sender: 'me',
      createdAt: createTimestamp(0, 10, 18),
    },
    {
      id: 3,
      chatId: 1,
      text: 'Oh nice, what is it? Tell me more!',
      sender: 'them',
      createdAt: createTimestamp(0, 10, 22),
    },
    {
      id: 4,
      chatId: 1,
      text: "It's a new messaging platform that centralizes all your conversations from different apps into one dashboard.",
      sender: 'me',
      createdAt: createTimestamp(0, 10, 25),
    },
    {
      id: 5,
      chatId: 1,
      text: 'That sounds really useful! I hate jumping between apps all day.',
      sender: 'them',
      createdAt: createTimestamp(0, 10, 30),
    },
  ],
  2: [
    {
      id: 6,
      chatId: 2,
      text: 'Can you review the latest design version?',
      sender: 'them',
      createdAt: createTimestamp(0, 9, 10),
    },
  ],
  3: [
    {
      id: 7,
      chatId: 3,
      text: 'Reminder about tomorrow’s meeting.',
      sender: 'them',
      createdAt: createTimestamp(-1, 18, 40),
    },
  ],
  4: [
    {
      id: 8,
      chatId: 4,
      text: 'Everything looks good from my side.',
      sender: 'them',
      createdAt: createTimestamp(-1, 16, 25),
    },
  ],
};
