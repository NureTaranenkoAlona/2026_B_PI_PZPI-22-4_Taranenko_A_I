import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import PageTransition from '../components/common/PageTransition';
import ProtectedRoute from '../components/auth/ProtectedRoute';
import { useAuth } from '../context/AuthContext';
import AddAccountPage from '../pages/AddAccountPage';
import AttachmentPreviewPage from '../pages/AttachmentPreviewPage';
import DashboardPage from '../pages/DashboardPage';
import ForgotPasswordPage from '../pages/ForgotPasswordPage';
import JoinWorkspacePage from '../pages/JoinWorkspacePage';
import LandingPage from '../pages/LandingPage';
import LoginPage from '../pages/LoginPage';
import NotFoundPage from '../pages/NotFoundPage';
import OnboardingPage from '../pages/OnboardingPage';
import PostLoginPage from '../pages/PostLoginPage';
import PrivacyPage from '../pages/PrivacyPage';
import RegisterPage from '../pages/RegisterPage';
import ResetPasswordPage from '../pages/ResetPasswordPage';
import SettingsPage from '../pages/SettingsPage';
import TeamPage from '../pages/TeamPage';
import TermsPage from '../pages/TermsPage';

function RootRoute() {
  const { isAuthenticated, isAuthLoading } = useAuth();

  if (isAuthLoading) {
    return <div className="min-h-screen bg-background" />;
  }

  if (isAuthenticated) {
    return <Navigate to="/chats" replace />;
  }

  return <LandingPage />;
}

function withPageTransition(element, key) {
  return <PageTransition key={key}>{element}</PageTransition>;
}

function AnimatedRoutes() {
  const location = useLocation();
  const { user } = useAuth();
  const routeKey = `${location.pathname}:${user?.id || 'guest'}`;

  return (
    <Routes location={location}>
      <Route path="/" element={withPageTransition(<RootRoute />, routeKey)} />
      <Route path="/login" element={withPageTransition(<LoginPage />, routeKey)} />
      <Route path="/register" element={withPageTransition(<RegisterPage />, routeKey)} />
      <Route path="/terms" element={withPageTransition(<TermsPage />, routeKey)} />
      <Route path="/privacy" element={withPageTransition(<PrivacyPage />, routeKey)} />
      <Route path="/forgot-password" element={withPageTransition(<ForgotPasswordPage />, routeKey)} />
      <Route path="/reset-password" element={withPageTransition(<ResetPasswordPage />, routeKey)} />
      <Route path="/join" element={withPageTransition(<JoinWorkspacePage />, routeKey)} />
      <Route
        path="/post-login"
        element={
          <ProtectedRoute requireIncompleteOnboarding>
            {withPageTransition(<PostLoginPage />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route
        path="/add-account"
        element={
          <ProtectedRoute allowDuringOnboarding>
            {withPageTransition(<AddAccountPage />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route
        path="/onboarding"
        element={
          <ProtectedRoute allowDuringOnboarding>
            {withPageTransition(<OnboardingPage />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route
        path="/chats"
        element={
          <ProtectedRoute requireCompletedOnboarding>
            {withPageTransition(<DashboardPage />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route
        path="/attachment-preview"
        element={
          <ProtectedRoute requireCompletedOnboarding>
            {withPageTransition(<AttachmentPreviewPage />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route
        path="/settings"
        element={
          <ProtectedRoute requireCompletedOnboarding>
            {withPageTransition(<Navigate to="/settings/profile" replace />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route
        path="/settings/:tab"
        element={
          <ProtectedRoute requireCompletedOnboarding>
            {withPageTransition(<SettingsPage />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route
        path="/team"
        element={
          <ProtectedRoute requireCompletedOnboarding>
            {withPageTransition(<TeamPage />, routeKey)}
          </ProtectedRoute>
        }
      />
      <Route path="*" element={withPageTransition(<NotFoundPage />, routeKey)} />
    </Routes>
  );
}

function AppRouter() {
  return (
    <BrowserRouter>
      <AnimatedRoutes />
    </BrowserRouter>
  );
}

export default AppRouter;
