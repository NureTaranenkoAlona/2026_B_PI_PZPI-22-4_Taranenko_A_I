import axios from 'axios';

export const TOKEN_KEY = 'dialogly_token';
export const AUTH_UNAUTHORIZED_EVENT = 'dialogly-auth-unauthorized';

const baseURL =
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:5122/api';

const axiosClient = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem(TOKEN_KEY);

    if (token) {
      const normalizedToken = token.startsWith('Bearer ')
        ? token.slice('Bearer '.length)
        : token;

      config.headers.Authorization = `Bearer ${normalizedToken}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    const hadToken = Boolean(localStorage.getItem(TOKEN_KEY));
    const requestUrl = error.config?.url || '';
    const isLoginRequest = requestUrl.includes('/auth/login');

    if (status === 401 && hadToken && !isLoginRequest) {
      localStorage.removeItem(TOKEN_KEY);

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event(AUTH_UNAUTHORIZED_EVENT));
      }
    }

    return Promise.reject(error);
  }
);

export default axiosClient;
