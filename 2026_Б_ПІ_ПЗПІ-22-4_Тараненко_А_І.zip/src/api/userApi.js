import axiosClient from './axiosClient';

export async function getCurrentUser() {
  const response = await axiosClient.get('/users/me');
  return response.data;
}

export async function updateCurrentUserProfile(payload) {
  const response = await axiosClient.patch('/users/me', payload);
  return response.data;
}

export async function getCurrentUserSettings() {
  const response = await axiosClient.get('/users/me/settings');
  return response.data;
}

export async function updateCurrentUserSettings(payload) {
  const response = await axiosClient.patch('/users/me/settings', payload);
  return response.data;
}

export async function getSecuritySettings() {
  const response = await axiosClient.get('/settings/security');
  return response.data;
}

export async function updateSecuritySettings(payload) {
  const response = await axiosClient.patch('/settings/security', payload);
  return response.data;
}

export async function updateOnboardingState(payload) {
  const response = await axiosClient.patch('/users/me/onboarding', payload);
  return response.data;
}

export async function completeOnboarding(workspaceChoice = null) {
  return updateOnboardingState({
    completed: true,
    ...(workspaceChoice ? { workspaceChoice } : {}),
  });
}

export default {
  getCurrentUser,
  getCurrentUserSettings,
  getSecuritySettings,
  updateCurrentUserProfile,
  updateCurrentUserSettings,
  updateSecuritySettings,
  updateOnboardingState,
  completeOnboarding,
};
