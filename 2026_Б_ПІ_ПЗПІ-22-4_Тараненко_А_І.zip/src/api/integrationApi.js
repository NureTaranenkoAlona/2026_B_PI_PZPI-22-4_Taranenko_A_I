import axiosClient from './axiosClient';

export async function getPlatforms() {
  const response = await axiosClient.get('/platforms');
  return response.data;
}

export async function getIntegrations() {
  const response = await axiosClient.get('/integrations');
  return response.data;
}

export async function connectIntegration(payload) {
  const response = await axiosClient.post('/integrations/connect', payload);
  return response.data;
}

export async function connectTelegramBot(payload) {
  const response = await axiosClient.post('/integrations/telegram/connect', payload);
  return response.data;
}

export async function connectMessengerPage(payload) {
  const response = await axiosClient.post('/integrations/messenger/connect', payload);
  return response.data;
}

export async function disconnectIntegration(id) {
  const response = await axiosClient.patch(`/integrations/${id}/disconnect`);
  return response.data;
}

export async function setTelegramWebhook(integrationAccountId, payload) {
  const response = await axiosClient.post(
    `/integrations/telegram/${integrationAccountId}/set-webhook`,
    payload
  );
  return response.data;
}
