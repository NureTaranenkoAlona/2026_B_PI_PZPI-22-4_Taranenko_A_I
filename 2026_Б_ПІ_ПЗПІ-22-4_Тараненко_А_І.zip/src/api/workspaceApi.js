import axiosClient from './axiosClient';

export async function createWorkspace(payload) {
  const response = await axiosClient.post('/workspaces', payload);
  return response.data;
}

export async function getMyWorkspaces() {
  const response = await axiosClient.get('/workspaces/my');
  return response.data;
}

export async function joinWorkspace(inviteCode) {
  const response = await axiosClient.post('/workspaces/join', { inviteCode });
  return response.data;
}

export async function createWorkspaceInvite(workspaceId, payload = {}) {
  const response = await axiosClient.post(`/workspaces/${workspaceId}/invites`, payload);
  return response.data;
}

export async function getWorkspace(workspaceId) {
  const response = await axiosClient.get(`/workspaces/${workspaceId}`);
  return response.data;
}

export async function updateWorkspace(workspaceId, payload) {
  const response = await axiosClient.patch(`/workspaces/${workspaceId}`, payload);
  return response.data;
}

export async function getWorkspaceMembers(workspaceId) {
  const response = await axiosClient.get(`/workspaces/${workspaceId}/members`);
  return response.data;
}

export async function removeWorkspaceMember(workspaceId, userId) {
  await axiosClient.delete(`/workspaces/${workspaceId}/members/${userId}`);
}

export async function getWorkspaceInvites(workspaceId) {
  const response = await axiosClient.get(`/workspaces/${workspaceId}/invites`);
  return response.data;
}

export async function revokeWorkspaceInvite(workspaceId, token) {
  const response = await axiosClient.delete(`/workspaces/${workspaceId}/invites/${encodeURIComponent(token)}`);
  return response.data;
}

export async function validateWorkspaceInvite(token) {
  const response = await axiosClient.get(`/invite/${encodeURIComponent(token)}`);
  return response.data;
}

export async function acceptWorkspaceInvite(token) {
  const response = await axiosClient.post(`/invite/${encodeURIComponent(token)}/accept`);
  return response.data;
}
