import axiosClient from './axiosClient';

export async function getAccountContexts() {
  const response = await axiosClient.get('/account-contexts');
  return response.data;
}

export async function updateActiveContext(payload) {
  const response = await axiosClient.patch('/users/me/active-context', payload);
  return response.data;
}
