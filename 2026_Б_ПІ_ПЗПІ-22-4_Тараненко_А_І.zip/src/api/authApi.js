import axiosClient, { TOKEN_KEY } from './axiosClient';

export async function registerUser(payload) {
  const response = await axiosClient.post('/auth/register', payload);
  return response.data;
}

export async function loginUser(payload) {
  const response = await axiosClient.post('/auth/login', payload);
  return response.data;
}

export async function verifyEmail(email, code) {
  const response = await axiosClient.post('/auth/verify-email', { email, code });
  return response.data;
}

export async function resendVerificationCode(email) {
  const response = await axiosClient.post('/auth/resend-verification-code', { email });
  return response.data;
}

function toEmailPayload(emailOrPayload) {
  if (typeof emailOrPayload === 'string') {
    return { email: emailOrPayload };
  }

  return emailOrPayload;
}

export async function forgotPassword(emailOrPayload) {
  const payload = toEmailPayload(emailOrPayload);
  const response = await axiosClient.post('/auth/forgot-password', payload);
  return response.data;
}

export async function resendPasswordResetCode(emailOrPayload) {
  const payload = toEmailPayload(emailOrPayload);
  const response = await axiosClient.post('/auth/resend-password-reset-code', payload);
  return response.data;
}

export async function resetPassword(emailOrPayload, code, newPassword, confirmPassword) {
  const payload =
    typeof emailOrPayload === 'string'
      ? { email: emailOrPayload, code, newPassword, confirmPassword }
      : emailOrPayload;

  const response = await axiosClient.post('/auth/reset-password', payload);
  return response.data;
}

export async function changePassword(payload) {
  const response = await axiosClient.post('/auth/change-password', payload);
  return response.data;
}

export async function requestAccountDeletionCode() {
  const response = await axiosClient.post('/auth/delete-account/request');
  return response.data;
}

export async function confirmAccountDeletion(code) {
  const response = await axiosClient.post('/auth/delete-account/confirm', { code });
  return response.data;
}

export async function resendAccountDeletionCode() {
  const response = await axiosClient.post('/auth/delete-account/resend-code');
  return response.data;
}

export async function getActiveSessions() {
  const response = await axiosClient.get('/auth/sessions');
  return response.data;
}

export async function revokeSession(sessionId) {
  const response = await axiosClient.delete(`/auth/sessions/${sessionId}`);
  return response.data;
}

export async function getTwoFactorSetup() {
  const response = await axiosClient.get('/auth/2fa/setup');
  return response.data;
}

export async function getTwoFactorStatus() {
  const response = await axiosClient.get('/auth/2fa/status');
  return response.data;
}

export async function confirmTwoFactorSetup(payload) {
  const response = await axiosClient.post('/auth/2fa/confirm-setup', payload);
  return response.data;
}

export async function enableTwoFactor(payload) {
  const response = await axiosClient.post('/auth/2fa/enable', payload);
  return response.data;
}

export async function disableTwoFactor(payload) {
  const response = await axiosClient.post('/auth/2fa/disable', payload);
  return response.data;
}

export async function verifyTwoFactorLogin(payload) {
  const response = await axiosClient.post('/auth/2fa/verify', payload);
  return response.data;
}

export function logoutUser() {
  localStorage.removeItem(TOKEN_KEY);
}

export default {
  registerUser,
  loginUser,
  verifyEmail,
  resendVerificationCode,
  forgotPassword,
  resendPasswordResetCode,
  resetPassword,
  changePassword,
  requestAccountDeletionCode,
  confirmAccountDeletion,
  resendAccountDeletionCode,
  getActiveSessions,
  revokeSession,
  getTwoFactorSetup,
  getTwoFactorStatus,
  confirmTwoFactorSetup,
  enableTwoFactor,
  disableTwoFactor,
  verifyTwoFactorLogin,
  logoutUser,
};
