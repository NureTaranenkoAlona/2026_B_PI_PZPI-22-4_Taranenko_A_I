import axiosClient from './axiosClient';

function extractFilenameFromResponse(response) {
  const disposition = response.headers['content-disposition'] || response.headers['Content-Disposition'];
  if (disposition) {
    const utf8Match = disposition.match(/filename\*=UTF-8''([^;]+)/i);
    if (utf8Match) return decodeURIComponent(utf8Match[1]);

    const simpleMatch = disposition.match(/filename="?([^";\n]+)"?/i);
    if (simpleMatch) return simpleMatch[1];
  }

  return null;
}

export async function getChats() {
  const response = await axiosClient.get('/chats');
  return response.data;
}

export async function getArchivedChats() {
  const response = await axiosClient.get('/chats/archived');
  return response.data;
}

export async function getChatById(id) {
  const response = await axiosClient.get(`/chats/${id}`);
  return response.data;
}

export async function updateChatCustomDetails(id, payload) {
  const response = await axiosClient.patch(`/chats/${id}/custom`, payload);
  return response.data;
}

export async function updateChatArchive(id, payload) {
  const response = await axiosClient.patch(`/chats/${id}/archive`, payload);
  return response.data;
}

export async function getChatMessages(id) {
  const response = await axiosClient.get(`/chats/${id}/messages`);
  return response.data;
}

export async function downloadAttachment(attachmentId, options = {}) {
  const response = await axiosClient.get(`/chats/attachments/${attachmentId}`, {
    params: {
      download: options.download === true,
    },
    responseType: 'blob',
  });

  const contentType = response.headers['content-type'] || response.data?.type || 'application/octet-stream';
  const fileName = extractFilenameFromResponse(response);
  const file = new File([response.data], fileName || 'document', { type: contentType });

  return {
    blob: response.data,
    file,
    contentType,
    fileName,
  };
}

export async function sendMessage(chatId, payload) {
  const formData = new FormData();
  formData.append('text', payload.text || '');
  formData.append('gifUrl', payload.gifUrl || '');

  (payload.attachments || []).forEach((attachment) => {
    if (attachment.file instanceof File) {
      formData.append('attachments', attachment.file, attachment.name || attachment.file.name);
    }
  });

  const response = await axiosClient.post(`/chats/${chatId}/messages`, formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });

  return response.data;
}

export async function updateMessageReaction(messageId, emoji) {
  const response = await axiosClient.patch(`/chats/messages/${messageId}/reaction`, { emoji });
  return response.data;
}

export async function markChatAsRead(chatId) {
  const response = await axiosClient.patch(`/chats/${chatId}/read`);
  return response.data;
}

export async function createMockChat(payload = {}) {
  const response = await axiosClient.post('/chats/mock', payload);
  return response.data;
}
