const AVATAR_COLORS = ['#5B6CF8', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#0EA5E9'];
const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5122/api';
const apiOrigin = apiBaseUrl.replace(/\/api\/?$/, '');

function hashString(value) {
  return [...String(value || '')].reduce((accumulator, character) => {
    return accumulator + character.charCodeAt(0);
  }, 0);
}

function getInitials(name) {
  const parts = String(name || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (parts.length === 0) return '??';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
}

function hasImageExtension(fileName = '') {
  return /\.(jpg|jpeg|png|webp|gif)$/i.test(fileName);
}

function hasVideoExtension(fileName = '') {
  return /\.(mp4|mov|webm|m4v|avi)$/i.test(fileName);
}

function hasPdfExtension(fileName = '') {
  return /\.pdf$/i.test(fileName);
}

function buildAttachmentKind(mimeType = '', fileName = '') {
  if (mimeType.startsWith('image/') || hasImageExtension(fileName)) return 'image';
  if (mimeType.startsWith('video/') || hasVideoExtension(fileName)) return 'video';
  return 'file';
}

function buildFileTypeLabel(mimeType = '', fileName = '') {
  if (mimeType === 'application/pdf' || hasPdfExtension(fileName)) return 'PDF';
  return mimeType || 'File';
}

function resolveAttachmentUrl(fileUrl) {
  if (!fileUrl) return '';
  if (/^https?:\/\//i.test(fileUrl) || fileUrl.startsWith('blob:') || fileUrl.startsWith('data:')) {
    return fileUrl;
  }

  return `${apiOrigin}${fileUrl.startsWith('/') ? '' : '/'}${fileUrl}`;
}

export function formatSidebarLastMessagePreview(lastMessage = '') {
  const value = String(lastMessage || '').trim();
  if (!value) return 'No messages yet';

  const lowerValue = value.toLowerCase();

  if (
    lowerValue.startsWith('https://media')
    || lowerValue.includes('giphy.com')
    || lowerValue === 'gif'
    || lowerValue === 'gif sent'
  ) {
    return '🎬 GIF';
  }

  if (
    lowerValue === 'photo'
    || lowerValue === 'photo received'
    || lowerValue === 'image received'
  ) {
    return '📷 Photo';
  }

  if (
    lowerValue === 'file'
    || lowerValue === 'file received'
    || lowerValue === 'pdf received'
  ) {
    return '📎 File';
  }

  if (/\.pdf$/i.test(value)) {
    return '📎 File';
  }

  return value;
}

export function mapChatListItem(chat) {
  const originalName = chat.title || 'Unknown chat';
  const customName = chat.customName || '';
  const name = customName || originalName;
  const color = AVATAR_COLORS[hashString(chat.id) % AVATAR_COLORS.length];

  return {
    id: chat.id,
    name,
    originalName,
    customName,
    initials: getInitials(name),
    avatarColor: color,
    avatarUrl: chat.avatarUrl || '',
    lastMessage: formatSidebarLastMessagePreview(chat.lastMessageText),
    timestampAt: chat.lastMessageAt || null,
    unreadCount: chat.unreadCount || 0,
    platform: chat.platformCode,
    platformName: chat.platformName,
    status: chat.status,
    isPinned: Boolean(chat.isPinned),
    isArchived: Boolean(chat.isArchived),
    integrationAccountId: chat.integrationAccountId,
    externalChatId: chat.externalChatId,
  };
}

export function mapChatDetails(chat) {
  const originalName = chat.title || 'Unknown chat';
  const customName = chat.customName || '';
  const name = customName || originalName;
  const color = AVATAR_COLORS[hashString(chat.id) % AVATAR_COLORS.length];

  return {
    id: chat.id,
    name,
    originalName,
    customName,
    notes: chat.notes || '',
    firstMessageAt: chat.firstMessageAt || null,
    initials: getInitials(name),
    avatarColor: color,
    avatarUrl: chat.avatarUrl || '',
    platform: chat.platformCode,
    platformName: chat.platformName,
    status: chat.status,
    isPinned: Boolean(chat.isPinned),
    isArchived: Boolean(chat.isArchived),
    integrationAccountId: chat.integrationAccountId,
    externalChatId: chat.externalChatId,
  };
}

export function mapChatMessage(message) {
  const dialoglyReaction = message.dialoglyReaction || message.reaction || null;
  const telegramReaction = message.telegramReaction || null;
  const reactions = Array.isArray(message.reactions) && message.reactions.length > 0
    ? message.reactions
    : [
        dialoglyReaction ? { source: 'dialogly', emoji: dialoglyReaction } : null,
        telegramReaction ? { source: 'telegram', emoji: telegramReaction } : null,
      ].filter(Boolean);
  const mappedAttachments = (message.attachments || []).map((attachment) => {
    const contentType = attachment.contentType || attachment.mimeType || '';
    const previewUrl = resolveAttachmentUrl(attachment.fileUrl);
    const downloadUrl = resolveAttachmentUrl(attachment.downloadUrl || attachment.fileUrl);
    const fileName = attachment.fileName || 'File';

    return {
      id: attachment.id,
      name: fileName,
      url: previewUrl || downloadUrl,
      downloadUrl,
      type: contentType,
      kind: buildAttachmentKind(contentType, fileName),
      fileTypeLabel: buildFileTypeLabel(contentType, fileName),
      size: attachment.size ?? attachment.fileSize ?? 0,
      local: false,
    };
  });
  const attachments = mappedAttachments.filter((attachment, index, items) => {
    const firstMatchIndex = items.findIndex((candidate) =>
      candidate.url === attachment.url
      && candidate.name === attachment.name
      && candidate.type === attachment.type
    );

    return firstMatchIndex === index;
  });

  return {
    id: message.id,
    chatId: message.chatId,
    text: message.text || '',
    gifUrl: message.gifUrl || '',
    sender: message.direction === 'Outgoing' ? 'me' : 'them',
    createdAt: message.createdAt,
    senderName: message.senderName || null,
    reaction: dialoglyReaction,
    dialoglyReaction,
    telegramReaction,
    reactions,
    attachments,
  };
}
