const DEFAULT_PLATFORM_ORDER = ['telegram', 'messenger'];

const INTEGRATION_CONFLICT_MESSAGES = {
  telegram: 'This Telegram bot is already connected to another Dialogly account.',
  messenger: 'This Facebook Page is already connected to another Dialogly account.',
};

const DEFAULT_CONNECT_VALUES = {
  telegram: {
    platformCode: 'telegram',
    displayName: 'Test Telegram Bot',
    externalAccountId: 'mock-telegram-001',
    username: '@test_bot',
  },
  messenger: {
    platformCode: 'messenger',
    displayName: 'Test Messenger Page',
    externalAccountId: 'mock-messenger-001',
    username: 'test_page',
  },
};

function normalizeStatus(status) {
  if (!status) return 'disconnected';

  const normalized = status.trim().toLowerCase();
  if (normalized === 'connected') return 'connected';
  if (normalized === 'disconnected') return 'disconnected';
  return normalized;
}

export function buildMockConnectPayload(platformCode, values = {}) {
  if (platformCode === 'messenger') {
    const username = values.pageName?.trim() || DEFAULT_CONNECT_VALUES.messenger.username;

    return {
      platformCode: 'messenger',
      displayName: values.displayName?.trim() || DEFAULT_CONNECT_VALUES.messenger.displayName,
      externalAccountId: username,
      username,
    };
  }

  return {
    platformCode,
    displayName: values.displayName?.trim() || 'Mock Integration',
    externalAccountId: values.externalAccountId?.trim() || `mock-${platformCode}-001`,
    username: values.username?.trim() || null,
  };
}

export function getModalInitialValues(integration) {
  if (!integration) return {};

  if (integration.id === 'telegram') {
    return {
      botToken: '',
    };
  }

  if (integration.id === 'messenger') {
    return {
      pageId: integration.externalAccountId || '',
      pageName: integration.displayName || integration.username || '',
      pageAccessToken: '',
    };
  }

  return {
    accessToken: '',
    displayName: integration.displayName || '',
  };
}

export function getIntegrationConflictMessage(error, platformCode) {
  if (error?.response?.status !== 409) {
    return null;
  }

  return INTEGRATION_CONFLICT_MESSAGES[platformCode] ||
    'This integration account is already connected to another Dialogly account.';
}

export function mapIntegrationData(platforms, integrations, activeContext) {
  const integrationMap = new Map(
    integrations.map((integration) => [integration.platformCode?.toLowerCase(), integration])
  );

  return [...platforms]
    .sort((left, right) => {
      const leftIndex = DEFAULT_PLATFORM_ORDER.indexOf(left.code);
      const rightIndex = DEFAULT_PLATFORM_ORDER.indexOf(right.code);
      return (leftIndex === -1 ? 999 : leftIndex) - (rightIndex === -1 ? 999 : rightIndex);
    })
    .map((platform) => {
      const integration = integrationMap.get(platform.code.toLowerCase());
      const status = integration ? normalizeStatus(integration.status) : 'disconnected';

      return {
        id: platform.code,
        backendId: integration?.id || null,
        name: platform.name,
        description: platform.shortDescription || `${platform.name} integration`,
        status,
        workspaceId:
          integration?.workspaceId ||
          (activeContext.type === 'workspace' ? activeContext.workspaceId : null),
        externalAccountId: integration?.externalAccountId || '',
        displayName: integration?.displayName || '',
        username: integration?.username || '',
        connectedBy: integration?.connectedByName || '',
        connectedAt: integration?.connectedAt || '',
        lastSyncAt: integration?.lastSyncAt || '',
        disconnectedAt: integration?.disconnectedAt || '',
        managedByWorkspace: activeContext.type === 'workspace',
        ownerType: activeContext.type,
      };
    });
}
