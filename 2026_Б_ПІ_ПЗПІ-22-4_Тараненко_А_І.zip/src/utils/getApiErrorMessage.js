export function getApiErrorMessage(
  error,
  fallback = 'Сталася помилка. Спробуйте ще раз.'
) {
  const data = error.response?.data;

  if (typeof data?.message === 'string' && data.message.trim()) {
    return data.message;
  }

  if (data?.errors && typeof data.errors === 'object') {
    const messages = Object.values(data.errors)
      .flat()
      .filter(Boolean);

    if (messages.length > 0) {
      return messages.join(' ');
    }
  }

  if (typeof data?.title === 'string' && data.title.trim()) {
    return data.title;
  }

  if (!error.response) {
    return 'Не вдалося з’єднатися із сервером. Перевірте, чи запущений backend.';
  }

  return fallback;
}

export default getApiErrorMessage;
