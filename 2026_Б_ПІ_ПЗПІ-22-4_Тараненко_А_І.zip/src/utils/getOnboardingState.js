import { currentWorkspace, workspaceIntegrations } from '../mocks/workspaceData';
import canManageIntegrations from './canManageIntegrations';

function cloneIntegration(integration, overrides = {}) {
  return {
    ...integration,
    ...overrides,
  };
}

function createPersonalIntegrations() {
  return workspaceIntegrations.map((integration) =>
    cloneIntegration(integration, {
      status: 'disconnected',
      externalAccountId: '',
      displayName: '',
      connectedBy: '',
      connectedAt: '',
      lastSyncAt: '',
      managedByWorkspace: false,
      ownerType: 'personal',
      workspaceId: null,
    })
  );
}

function createDisconnectedWorkspaceIntegrations(workspaceId) {
  return workspaceIntegrations.map((integration) =>
    cloneIntegration(integration, {
      status: 'disconnected',
      workspaceId,
      externalAccountId: '',
      displayName: '',
      connectedBy: '',
      connectedAt: '',
      lastSyncAt: '',
      managedByWorkspace: true,
      ownerType: 'workspace',
    })
  );
}

function getOnboardingState(workspaceChoice, options = {}) {
  const { joinedRole = 'Admin', workspaceName = 'New Workspace' } = options;

  if (workspaceChoice === 'created') {
    const workspace = {
      id: 'w-new',
      name: workspaceName || 'New Workspace',
      publicSenderName: `${workspaceName || 'New Workspace'} Support`,
    };

    return {
      workspaceChoice: 'created',
      mode: 'workspace',
      workspace,
      currentUserRole: 'Owner',
      ownershipLabel: 'Workspace',
      platformStatuses: createDisconnectedWorkspaceIntegrations(workspace.id),
      canManageIntegrations: true,
      hasWorkspace: true,
      activeContext: {
        type: 'workspace',
        workspaceId: workspace.id,
        role: 'Owner',
      },
    };
  }

  if (workspaceChoice === 'joined') {
    return {
      workspaceChoice: 'joined',
      mode: 'workspace',
      workspace: currentWorkspace,
      currentUserRole: joinedRole,
      ownershipLabel: 'Workspace',
      platformStatuses: workspaceIntegrations.map((integration) =>
        cloneIntegration(integration, {
          ownerType: 'workspace',
        })
      ),
      canManageIntegrations: canManageIntegrations(joinedRole),
      hasWorkspace: true,
      activeContext: {
        type: 'workspace',
        workspaceId: currentWorkspace.id,
        role: joinedRole,
      },
    };
  }

  return {
    workspaceChoice: 'skipped',
    mode: 'personal',
    workspace: null,
    currentUserRole: null,
    ownershipLabel: 'Personal',
    platformStatuses: createPersonalIntegrations(),
    canManageIntegrations: true,
    hasWorkspace: false,
    activeContext: {
      type: 'personal',
    },
  };
}

export default getOnboardingState;
