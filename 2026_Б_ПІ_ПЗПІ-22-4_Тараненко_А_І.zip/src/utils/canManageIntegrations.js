function canManageIntegrations(role) {
  return role === 'Owner';
}

export default canManageIntegrations;
