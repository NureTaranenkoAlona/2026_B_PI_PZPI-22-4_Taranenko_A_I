const profileStorageKey = 'dialogly-user-profile';
export const profileUpdatedEvent = 'dialogly-profile-updated';

const defaultProfile = {
  firstName: '',
  lastName: '',
  email: '',
  jobTitle: '',
  phone: '',
  avatar: '',
};

export function getStoredProfile() {
  const raw = localStorage.getItem(profileStorageKey);

  if (!raw) return defaultProfile;

  try {
    return { ...defaultProfile, ...JSON.parse(raw) };
  } catch {
    return defaultProfile;
  }
}

export function saveStoredProfile(profile) {
  localStorage.setItem(profileStorageKey, JSON.stringify(profile));
  window.dispatchEvent(new CustomEvent(profileUpdatedEvent, { detail: profile }));
}

export function clearStoredProfile() {
  localStorage.removeItem(profileStorageKey);
  window.dispatchEvent(new CustomEvent(profileUpdatedEvent, { detail: defaultProfile }));
}

export function getProfileInitials(profile) {
  const first = profile.firstName?.trim()?.[0] || '';
  const last = profile.lastName?.trim()?.[0] || '';
  const initials = `${first}${last}`.toUpperCase();

  return initials || '??';
}

export default defaultProfile;
