import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useAppLanguage } from './AppLanguageContext';

const storageKey = 'dialogly-regional-settings';
const appearanceStorageKey = 'dialogly-appearance-settings';

const defaultSettings = {
  dateFormat: 'DD.MM.YYYY',
  timeFormat: '24-hour',
  firstDayOfWeek: 'monday',
};

const defaultAppearanceSettings = {
  accent: 'Indigo',
  density: 'Comfortable',
  typography: 'Medium',
};

export const accentOptions = [
  {
    name: 'Indigo',
    color: '#5B6CF8',
    hover: '#4A58E0',
    soft: '#EEF0FE',
    softDark: '#232842',
    border: '#C7D2FE',
    borderDark: '#3A4160',
    softHover: '#DDE3FF',
    softDarkHover: '#39416A',
  },
  {
    name: 'Emerald',
    color: '#10B981',
    hover: '#059669',
    soft: '#ECFDF5',
    softDark: '#1B3A33',
    border: '#A7F3D0',
    borderDark: '#275C50',
    softHover: '#D1FAE5',
    softDarkHover: '#22453D',
  },
  {
    name: 'Amber',
    color: '#F59E0B',
    hover: '#D97706',
    soft: '#FFFBEB',
    softDark: '#3B2F1D',
    border: '#FDE68A',
    borderDark: '#5B4627',
    softHover: '#FEF3C7',
    softDarkHover: '#463722',
  },
  {
    name: 'Rose',
    color: '#F43F5E',
    hover: '#E11D48',
    soft: '#FFF1F2',
    softDark: '#3B2229',
    border: '#FECDD3',
    borderDark: '#5D2C37',
    softHover: '#FFE4E6',
    softDarkHover: '#472830',
  },
  {
    name: 'Violet',
    color: '#8B5CF6',
    hover: '#7C3AED',
    soft: '#F5F3FF',
    softDark: '#2F2744',
    border: '#DDD6FE',
    borderDark: '#4A3E68',
    softHover: '#EDE9FE',
    softDarkHover: '#382F52',
  },
  {
    name: 'Cyan',
    color: '#06B6D4',
    hover: '#0891B2',
    soft: '#ECFEFF',
    softDark: '#1E3640',
    border: '#A5F3FC',
    borderDark: '#2B5160',
    softHover: '#CFFAFE',
    softDarkHover: '#27424D',
  },
];

function getStoredAppearanceSettings() {
  const raw = localStorage.getItem(appearanceStorageKey);

  if (!raw) return defaultAppearanceSettings;

  try {
    return { ...defaultAppearanceSettings, ...JSON.parse(raw) };
  } catch {
    return defaultAppearanceSettings;
  }
}

function getAccentPalette(accentName) {
  return accentOptions.find((accent) => accent.name === accentName) ?? accentOptions[0];
}

function applyAccentTheme(accentName) {
  const palette = getAccentPalette(accentName);
  const root = document.documentElement;

  root.style.setProperty('--dialogly-accent', palette.color);
  root.style.setProperty('--dialogly-accent-hover', palette.hover);
  root.style.setProperty('--dialogly-accent-soft', palette.soft);
  root.style.setProperty('--dialogly-accent-soft-dark', palette.softDark);
  root.style.setProperty('--dialogly-accent-border', palette.border);
  root.style.setProperty('--dialogly-accent-border-dark', palette.borderDark);
  root.style.setProperty('--dialogly-accent-soft-hover', palette.softHover);
  root.style.setProperty('--dialogly-accent-soft-dark-hover', palette.softDarkHover);
}

const densityOptions = {
  Compact: {
    pagePadding: '18px',
    sectionHeaderY: '16px',
    sectionBodyY: '16px',
    sectionX: '20px',
    sidebarItemY: '10px',
    sidebarItemX: '14px',
    sidebarSectionY: '10px',
    chatHeaderX: '20px',
    chatHeaderY: '0px',
    chatBodyX: '20px',
    chatBodyY: '16px',
    composerPadding: '16px',
    composerInnerY: '10px',
    composerInnerX: '14px',
  },
  Comfortable: {
    pagePadding: '24px',
    sectionHeaderY: '20px',
    sectionBodyY: '20px',
    sectionX: '24px',
    sidebarItemY: '12px',
    sidebarItemX: '16px',
    sidebarSectionY: '12px',
    chatHeaderX: '24px',
    chatHeaderY: '0px',
    chatBodyX: '24px',
    chatBodyY: '20px',
    composerPadding: '20px',
    composerInnerY: '12px',
    composerInnerX: '16px',
  },
  Spacious: {
    pagePadding: '30px',
    sectionHeaderY: '24px',
    sectionBodyY: '24px',
    sectionX: '28px',
    sidebarItemY: '14px',
    sidebarItemX: '18px',
    sidebarSectionY: '14px',
    chatHeaderX: '28px',
    chatHeaderY: '0px',
    chatBodyX: '28px',
    chatBodyY: '24px',
    composerPadding: '24px',
    composerInnerY: '14px',
    composerInnerX: '18px',
  },
};

function applyDensityTheme(densityName) {
  const density = densityOptions[densityName] ?? densityOptions.Comfortable;
  const root = document.documentElement;

  root.style.setProperty('--dialogly-density-page-padding', density.pagePadding);
  root.style.setProperty('--dialogly-density-section-header-y', density.sectionHeaderY);
  root.style.setProperty('--dialogly-density-section-body-y', density.sectionBodyY);
  root.style.setProperty('--dialogly-density-section-x', density.sectionX);
  root.style.setProperty('--dialogly-density-sidebar-item-y', density.sidebarItemY);
  root.style.setProperty('--dialogly-density-sidebar-item-x', density.sidebarItemX);
  root.style.setProperty('--dialogly-density-sidebar-section-y', density.sidebarSectionY);
  root.style.setProperty('--dialogly-density-chat-header-x', density.chatHeaderX);
  root.style.setProperty('--dialogly-density-chat-header-y', density.chatHeaderY);
  root.style.setProperty('--dialogly-density-chat-body-x', density.chatBodyX);
  root.style.setProperty('--dialogly-density-chat-body-y', density.chatBodyY);
  root.style.setProperty('--dialogly-density-composer-padding', density.composerPadding);
  root.style.setProperty('--dialogly-density-composer-inner-y', density.composerInnerY);
  root.style.setProperty('--dialogly-density-composer-inner-x', density.composerInnerX);
}

const typographyOptions = {
  Small: {
    rootFontSize: '15px',
  },
  Medium: {
    rootFontSize: '16px',
  },
  Large: {
    rootFontSize: '17px',
  },
};

function applyTypographyTheme(typographyName) {
  const typography = typographyOptions[typographyName] ?? typographyOptions.Medium;
  document.documentElement.style.setProperty('--font-size', typography.rootFontSize);
}

const localeMap = {
  en: 'en-US',
  uk: 'uk-UA',
  de: 'de-DE',
  fr: 'fr-FR',
  es: 'es-ES',
  pl: 'pl-PL',
  pt: 'pt-PT',
  it: 'it-IT',
  nl: 'nl-NL',
  tr: 'tr-TR',
  cs: 'cs-CZ',
  sk: 'sk-SK',
  ro: 'ro-RO',
  hu: 'hu-HU',
  bg: 'bg-BG',
  ar: 'ar',
  zh: 'zh-CN',
  ja: 'ja-JP',
  ko: 'ko-KR',
  hi: 'hi-IN',
};

function getStoredSettings() {
  const raw = localStorage.getItem(storageKey);

  if (!raw) return defaultSettings;

  try {
    return { ...defaultSettings, ...JSON.parse(raw) };
  } catch {
    return defaultSettings;
  }
}

function normalizeDate(dateInput) {
  return dateInput instanceof Date ? dateInput : new Date(dateInput);
}

function getWeekStart(dateInput, firstDayOfWeek) {
  const date = normalizeDate(dateInput);
  const start = new Date(date);
  const currentDay = start.getDay();
  const weekStartsOn = firstDayOfWeek === 'sunday' ? 0 : firstDayOfWeek === 'saturday' ? 6 : 1;
  const offset = (currentDay - weekStartsOn + 7) % 7;

  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - offset);

  return start;
}

const AppPreferencesContext = createContext(null);

export function AppPreferencesProvider({ children }) {
  const { language, t } = useAppLanguage();
  const [regionalSettings, setRegionalSettingsState] = useState(getStoredSettings);
  const [appearanceSettings, setAppearanceSettingsState] = useState(getStoredAppearanceSettings);

  useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify(regionalSettings));
  }, [regionalSettings]);

  useEffect(() => {
    localStorage.setItem(appearanceStorageKey, JSON.stringify(appearanceSettings));
    applyAccentTheme(appearanceSettings.accent);
    applyDensityTheme(appearanceSettings.density);
    applyTypographyTheme(appearanceSettings.typography);
  }, [appearanceSettings]);

  const locale = localeMap[language] || 'en-US';

  const value = useMemo(() => {
    const relativeFormatter = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });

    const setRegionalSettings = (updates) => {
      setRegionalSettingsState((prev) => ({ ...prev, ...updates }));
    };

    const setAppearanceSettings = (updates) => {
      setAppearanceSettingsState((prev) => ({ ...prev, ...updates }));
    };

    const formatTime = (dateInput) => {
      const date = normalizeDate(dateInput);

      return new Intl.DateTimeFormat(locale, {
        hour: 'numeric',
        minute: '2-digit',
        hour12: regionalSettings.timeFormat === '12-hour',
      }).format(date);
    };

    const formatDate = (dateInput) => {
      const date = normalizeDate(dateInput);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = String(date.getFullYear());

      if (regionalSettings.dateFormat === 'MM/DD/YYYY') {
        return `${month}/${day}/${year}`;
      }

      if (regionalSettings.dateFormat === 'YYYY-MM-DD') {
        return `${year}-${month}-${day}`;
      }

      return `${day}.${month}.${year}`;
    };

    const formatWeekday = (dateInput, style = 'short') => {
      const date = normalizeDate(dateInput);
      return new Intl.DateTimeFormat(locale, { weekday: style }).format(date);
    };

    const isSameDay = (left, right) => {
      const leftDate = normalizeDate(left);
      const rightDate = normalizeDate(right);

      return (
        leftDate.getFullYear() === rightDate.getFullYear() &&
        leftDate.getMonth() === rightDate.getMonth() &&
        leftDate.getDate() === rightDate.getDate()
      );
    };

    const isYesterday = (dateInput) => {
      const date = normalizeDate(dateInput);
      const yesterday = new Date();
      yesterday.setHours(0, 0, 0, 0);
      yesterday.setDate(yesterday.getDate() - 1);

      return isSameDay(date, yesterday);
    };

    const isSameWeek = (dateInput) => {
      const date = normalizeDate(dateInput);
      const now = new Date();
      return getWeekStart(date, regionalSettings.firstDayOfWeek).getTime() === getWeekStart(now, regionalSettings.firstDayOfWeek).getTime();
    };

    const formatRelativeDay = (dateInput) => {
      const date = normalizeDate(dateInput);
      const target = new Date(date);
      target.setHours(0, 0, 0, 0);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const difference = Math.round((target.getTime() - today.getTime()) / 86400000);

      return relativeFormatter.format(difference, 'day');
    };

    const formatChatTimestamp = (dateInput) => {
      const date = normalizeDate(dateInput);

      if (isSameDay(date, new Date())) return formatTime(date);
      if (isYesterday(date)) return formatRelativeDay(date);
      if (isSameWeek(date)) return formatWeekday(date);

      return formatDate(date);
    };

    const formatConversationDayLabel = (dateInput) => {
      const date = normalizeDate(dateInput);

      if (isSameDay(date, new Date())) return formatRelativeDay(date);
      if (isYesterday(date)) return formatRelativeDay(date);
      if (isSameWeek(date)) return formatWeekday(date, 'long');

      return formatDate(date);
    };

    return {
      regionalSettings,
      setRegionalSettings,
      appearanceSettings,
      setAppearanceSettings,
      accentOptions,
      densityOptions: Object.keys(densityOptions),
      typographyOptions: Object.keys(typographyOptions),
      accentPalette: getAccentPalette(appearanceSettings.accent),
      formatTime,
      formatDate,
      formatChatTimestamp,
      formatConversationDayLabel,
      t,
    };
  }, [appearanceSettings.accent, appearanceSettings.density, appearanceSettings.typography, language, locale, regionalSettings, t]);

  return <AppPreferencesContext.Provider value={value}>{children}</AppPreferencesContext.Provider>;
}

export function useAppPreferences() {
  const context = useContext(AppPreferencesContext);

  if (!context) {
    throw new Error('useAppPreferences must be used within AppPreferencesProvider');
  }

  return context;
}

export default AppPreferencesContext;
