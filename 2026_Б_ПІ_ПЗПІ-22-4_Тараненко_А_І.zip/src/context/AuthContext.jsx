/* eslint-disable react-refresh/only-export-components */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

import { loginUser, logoutUser, registerUser } from '../api/authApi';
import {
  AUTH_UNAUTHORIZED_EVENT,
  TOKEN_KEY,
} from '../api/axiosClient';
import {
  completeOnboarding,
  getCurrentUser,
  updateOnboardingState,
} from '../api/userApi';
import { clearStoredProfile, getStoredProfile, saveStoredProfile } from '../utils/profileStorage';

const AuthContext = createContext(null);

function extractToken(responseData) {
  if (typeof responseData?.token === 'string' && responseData.token.trim()) {
    return responseData.token;
  }

  if (typeof responseData?.accessToken === 'string' && responseData.accessToken.trim()) {
    return responseData.accessToken;
  }

  return '';
}

function normalizeToken(token) {
  if (!token) return '';
  return token.startsWith('Bearer ') ? token.slice('Bearer '.length) : token;
}

function extractUser(payload) {
  if (payload?.user && typeof payload.user === 'object') {
    return payload.user;
  }

  if (payload && typeof payload === 'object') {
    return payload;
  }

  return null;
}

function syncStoredProfileFromUser(user) {
  if (!user) return;

  saveStoredProfile({
    firstName: user.firstName || '',
    lastName: user.lastName || '',
    email: user.email || '',
    jobTitle: '',
    phone: '',
    avatar: '',
  });
}

function clearSessionStorageArtifacts() {
  if (typeof window === 'undefined') return;

  window.sessionStorage.removeItem('dialogly-play-login-sound');
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);

  const clearAuthState = useCallback(() => {
    logoutUser();
    clearStoredProfile();
    clearSessionStorageArtifacts();
    setUser(null);
  }, []);

  const refreshCurrentUser = useCallback(async () => {
    const currentUser = await getCurrentUser();
    const normalizedUser = extractUser(currentUser);
    setUser(normalizedUser);
    if (normalizedUser) {
      saveStoredProfile({
        ...getStoredProfile(),
        firstName: normalizedUser.firstName || '',
        lastName: normalizedUser.lastName || '',
        email: normalizedUser.email || '',
      });
    }
    return normalizedUser;
  }, []);

  const finalizeAuthenticatedUser = useCallback(async (response) => {
    const token = normalizeToken(extractToken(response));

    if (!token) {
      throw new Error('TOKEN_MISSING');
    }

    localStorage.setItem(TOKEN_KEY, token);

    const responseUser = extractUser(response?.user);
    const nextUser = responseUser || (await refreshCurrentUser());

    setUser(nextUser);
    syncStoredProfileFromUser(nextUser);

    return {
      token,
      user: nextUser,
    };
  }, [refreshCurrentUser]);

  useEffect(() => {
    const bootstrapAuth = async () => {
      const token = localStorage.getItem(TOKEN_KEY);

      if (!token) {
        setUser(null);
        setIsAuthLoading(false);
        return;
      }

      try {
        await refreshCurrentUser();
      } catch {
        clearAuthState();
      } finally {
        setIsAuthLoading(false);
      }
    };

    bootstrapAuth();
  }, [clearAuthState, refreshCurrentUser]);

  useEffect(() => {
    const handleUnauthorized = () => {
      setUser(null);
      setIsAuthLoading(false);
    };

    window.addEventListener(AUTH_UNAUTHORIZED_EVENT, handleUnauthorized);

    return () => {
      window.removeEventListener(AUTH_UNAUTHORIZED_EVENT, handleUnauthorized);
    };
  }, []);

  const login = useCallback(async (payload) => {
    clearStoredProfile();
    setUser(null);
    const response = await loginUser(payload);

    if (response?.requiresTwoFactor) {
      return {
        requiresTwoFactor: true,
        tempToken: response.tempToken || '',
        user: extractUser(response?.user),
      };
    }

    return finalizeAuthenticatedUser(response);
  }, [finalizeAuthenticatedUser]);

  const register = useCallback(async (payload) => {
    clearStoredProfile();
    setUser(null);
    const response = await registerUser(payload);
    if (response?.requiresVerification) {
      return {
        ...response,
        token: normalizeToken(extractToken(response)),
        user: extractUser(response?.user),
      };
    }

    return finalizeAuthenticatedUser(response);
  }, [finalizeAuthenticatedUser]);

  const logout = useCallback(() => {
    clearAuthState();
  }, [clearAuthState]);

  const saveOnboardingChoice = useCallback(async (workspaceChoice) => {
    const updatedUser = await updateOnboardingState({
      workspaceChoice,
    });
    const normalizedUser = extractUser(updatedUser);

    setUser(normalizedUser);

    return normalizedUser;
  }, []);

  const completeUserOnboarding = useCallback(async (workspaceChoice = null) => {
    const updatedUser = await completeOnboarding(workspaceChoice);
    const normalizedUser = extractUser(updatedUser);

    setUser(normalizedUser);

    return normalizedUser;
  }, []);

  const value = useMemo(
    () => ({
      user,
      isAuthenticated: Boolean(user),
      isAuthLoading,
      login,
      register,
      logout,
      finalizeAuthenticatedUser,
      refreshCurrentUser,
      saveOnboardingChoice,
      completeUserOnboarding,
    }),
    [
      completeUserOnboarding,
      isAuthLoading,
      login,
      logout,
      finalizeAuthenticatedUser,
      refreshCurrentUser,
      register,
      saveOnboardingChoice,
      user,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }

  return context;
}
