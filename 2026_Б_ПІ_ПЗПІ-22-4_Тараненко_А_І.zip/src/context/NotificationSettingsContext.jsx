/* eslint-disable react-refresh/only-export-components */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { getCurrentUserSettings, updateCurrentUserSettings } from '../api/userApi';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';

const NotificationSettingsContext = createContext(null);
const loginSoundSessionKey = 'dialogly-play-login-sound';

const defaultSettings = {
  isTourCompleted: false,
  notificationsEnabled: true,
  soundEnabled: false,
  quietHoursEnabled: false,
  quietHoursStart: '22:00',
  quietHoursEnd: '08:00',
};

function parseTimeToMinutes(value) {
  const [hours = '0', minutes = '0'] = String(value || '').split(':');
  return Number(hours) * 60 + Number(minutes);
}

function isWithinQuietHours(settings) {
  if (!settings.quietHoursEnabled) return false;

  const start = parseTimeToMinutes(settings.quietHoursStart);
  const end = parseTimeToMinutes(settings.quietHoursEnd);
  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();

  if (start === end) return true;
  if (start < end) return current >= start && current < end;
  return current >= start || current < end;
}

function playTone({ startFrequency, endFrequency, duration = 0.28, gain = 0.22 }) {
  if (typeof window === 'undefined') return;

  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return;

  const context = new AudioContextClass();
  const oscillator = context.createOscillator();
  const gainNode = context.createGain();

  oscillator.type = 'sine';
  oscillator.connect(gainNode);
  gainNode.connect(context.destination);

  const now = context.currentTime;
  oscillator.frequency.setValueAtTime(startFrequency, now);
  oscillator.frequency.exponentialRampToValueAtTime(endFrequency, now + duration * 0.65);
  gainNode.gain.setValueAtTime(gain, now);
  gainNode.gain.exponentialRampToValueAtTime(0.001, now + duration);

  oscillator.start(now);
  oscillator.stop(now + duration);

  window.setTimeout(() => {
    context.close().catch(() => {});
  }, Math.ceil(duration * 1000) + 80);
}

export function markLoginSoundPending() {
  if (typeof window === 'undefined') return;
  window.sessionStorage.setItem(loginSoundSessionKey, '1');
}

export function NotificationSettingsProvider({ children }) {
  const { isAuthenticated } = useAuth();
  const { showError } = useToast();
  const [settings, setSettings] = useState(defaultSettings);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const refreshSettings = useCallback(async () => {
    if (!isAuthenticated) {
      setSettings(defaultSettings);
      return defaultSettings;
    }

    setIsLoading(true);

    try {
      const response = await getCurrentUserSettings();
      const nextSettings = {
        ...defaultSettings,
        ...response,
      };
      setSettings(nextSettings);
      return nextSettings;
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (!isAuthenticated) {
      setSettings(defaultSettings);
      return;
    }

    void refreshSettings();
  }, [isAuthenticated, refreshSettings]);

  const saveSettings = useCallback(async (payload) => {
    setIsSaving(true);

    try {
      const response = await updateCurrentUserSettings(payload);
      const nextSettings = {
        ...defaultSettings,
        ...response,
      };
      setSettings(nextSettings);
      return nextSettings;
    } finally {
      setIsSaving(false);
    }
  }, []);

  const requestBrowserPermission = useCallback(async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      showError('Browser notifications are not supported in this browser');
      return false;
    }

    const result = await Notification.requestPermission();
    if (result !== 'granted') {
      showError('Please allow notifications in browser settings');
      return false;
    }

    return true;
  }, [showError]);

  const playNotificationSound = useCallback(() => {
    if (isWithinQuietHours(settings) || !settings.soundEnabled) return;
    playTone({ startFrequency: 800, endFrequency: 600, duration: 0.3, gain: 0.2 });
  }, [settings]);

  const playLoginSoundIfNeeded = useCallback(() => {
    if (typeof window === 'undefined') return;
    if (window.sessionStorage.getItem(loginSoundSessionKey) !== '1') return;
    if (isLoading) return;

    window.sessionStorage.removeItem(loginSoundSessionKey);

    if (isWithinQuietHours(settings) || !settings.soundEnabled) return;
    playTone({ startFrequency: 1046, endFrequency: 1318, duration: 0.34, gain: 0.18 });
  }, [isLoading, settings]);

  const notifyIncomingMessage = useCallback(async ({ senderName, messageText }) => {
    if (isWithinQuietHours(settings)) return;

    if (settings.notificationsEnabled && typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      new Notification(`New message from ${senderName}`, {
        body: messageText || 'New incoming message',
        icon: '/dialogly-icon.png',
      });
    }

    if (settings.soundEnabled) {
      playNotificationSound();
    }
  }, [playNotificationSound, settings]);

  const value = useMemo(() => ({
    settings,
    isLoading,
    isSaving,
    refreshSettings,
    saveSettings,
    requestBrowserPermission,
    notifyIncomingMessage,
    playLoginSoundIfNeeded,
  }), [
    isLoading,
    isSaving,
    notifyIncomingMessage,
    playLoginSoundIfNeeded,
    refreshSettings,
    requestBrowserPermission,
    saveSettings,
    settings,
  ]);

  return (
    <NotificationSettingsContext.Provider value={value}>
      {children}
    </NotificationSettingsContext.Provider>
  );
}

export function useNotificationSettings() {
  const context = useContext(NotificationSettingsContext);

  if (!context) {
    throw new Error('useNotificationSettings must be used within a NotificationSettingsProvider');
  }

  return context;
}
