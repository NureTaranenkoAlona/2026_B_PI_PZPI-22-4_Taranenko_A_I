import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle, X, XCircle } from 'lucide-react';
import { AUTH_UNAUTHORIZED_EVENT } from '../api/axiosClient';

const ToastContext = createContext(null);

function ToastViewport({ toasts, onDismiss }) {
  return (
    <div className="pointer-events-none fixed bottom-5 right-5 z-[120] flex w-[min(92vw,360px)] flex-col gap-3">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const Icon = isSuccess ? CheckCircle : XCircle;

        return (
          <div
            key={toast.id}
            className={`toast-slide-in pointer-events-auto rounded-2xl border px-4 py-3 shadow-xl ${
              isSuccess
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-400/20 dark:bg-emerald-500/15 dark:text-emerald-200'
                : 'border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-400/20 dark:bg-rose-500/15 dark:text-rose-200'
            }`}
          >
            <div className="flex items-start gap-3">
              <Icon className="mt-0.5 h-5 w-5 flex-shrink-0" />
              <p className="min-w-0 flex-1 text-sm leading-relaxed">{toast.message}</p>
              <button
                type="button"
                onClick={() => onDismiss(toast.id)}
                className="text-current/60 transition-colors hover:text-current"
                aria-label="Dismiss notification"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const timersRef = useRef(new Map());

  const dismissToast = useCallback((id) => {
    const timeoutId = timersRef.current.get(id);
    if (timeoutId) {
      window.clearTimeout(timeoutId);
      timersRef.current.delete(id);
    }

    setToasts((current) => current.filter((toast) => toast.id !== id));
  }, []);

  const showToast = useCallback((message, type = 'success') => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    setToasts((current) => [...current, { id, message, type }]);

    const timeoutId = window.setTimeout(() => {
      dismissToast(id);
    }, 3000);

    timersRef.current.set(id, timeoutId);
  }, [dismissToast]);

  useEffect(() => {
    const handleUnauthorized = () => {
      showToast('Session expired, please sign in again', 'error');
    };

    window.addEventListener(AUTH_UNAUTHORIZED_EVENT, handleUnauthorized);

    return () => {
      window.removeEventListener(AUTH_UNAUTHORIZED_EVENT, handleUnauthorized);
    };
  }, [showToast]);

  useEffect(() => () => {
    timersRef.current.forEach((timeoutId) => {
      window.clearTimeout(timeoutId);
    });
    timersRef.current.clear();
  }, []);

  const value = useMemo(() => ({
    showSuccess: (message) => showToast(message, 'success'),
    showError: (message) => showToast(message, 'error'),
  }), [showToast]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <ToastViewport toasts={toasts} onDismiss={dismissToast} />
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);

  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }

  return context;
}
