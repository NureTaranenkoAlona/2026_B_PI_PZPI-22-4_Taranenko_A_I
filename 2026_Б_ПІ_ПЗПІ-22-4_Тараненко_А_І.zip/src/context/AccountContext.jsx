/* eslint-disable react-refresh/only-export-components */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

import { getAccountContexts, updateActiveContext } from '../api/accountContextApi';
import { getMyWorkspaces } from '../api/workspaceApi';
import { workspaceIntegrations } from '../mocks/workspaceData';
import canManageIntegrations from '../utils/canManageIntegrations';
import { useAuth } from './AuthContext';

const AccountContext = createContext(null);

function cloneIntegration(integration, overrides = {}) {
  return {
    ...integration,
    ...overrides,
  };
}

function createPersonalIntegrations() {
  return workspaceIntegrations.map((integration) =>
    cloneIntegration(integration, {
      status: 'disconnected',
      ownerType: 'personal',
      workspaceId: null,
      externalAccountId: '',
      displayName: '',
      connectedBy: '',
      connectedAt: '',
      lastSyncAt: '',
      managedByWorkspace: false,
    })
  );
}

function createWorkspaceIntegrations(workspaceId) {
  return workspaceIntegrations.map((integration) =>
    cloneIntegration(integration, {
      workspaceId,
      ownerType: 'workspace',
      status: 'disconnected',
      externalAccountId: '',
      displayName: '',
      connectedBy: '',
      connectedAt: '',
      lastSyncAt: '',
      managedByWorkspace: true,
    })
  );
}

function getIntegrationStorageKey(userId, contextId) {
  return `dialogly-context-integrations:${userId}:${contextId}`;
}

function loadSavedIntegrations(userId, contextId) {
  const rawValue = localStorage.getItem(getIntegrationStorageKey(userId, contextId));
  if (!rawValue) return null;

  try {
    return JSON.parse(rawValue);
  } catch {
    return null;
  }
}

function saveIntegrations(userId, contextId, integrations) {
  localStorage.setItem(
    getIntegrationStorageKey(userId, contextId),
    JSON.stringify(integrations)
  );
}

function buildPersonalContext(userId, backendContext) {
  const savedIntegrations = loadSavedIntegrations(userId, 'personal');

  return {
    id: 'personal',
    type: 'personal',
    label: 'Personal account',
    role: null,
    workspaceId: null,
    workspace: null,
    ownershipLabel: 'Personal',
    isActive: Boolean(backendContext?.isActive),
    integrations: savedIntegrations || createPersonalIntegrations(),
  };
}

function buildWorkspaceContext(userId, backendContext, workspace) {
  const contextId = backendContext.id;
  const savedIntegrations = loadSavedIntegrations(userId, contextId);
  const contextName = workspace?.name || backendContext.name || 'Workspace';

  return {
    id: contextId,
    type: 'workspace',
    label: contextName,
    role: backendContext.role,
    workspaceId: contextId,
    workspace: {
      id: contextId,
      name: contextName,
      publicSenderName: workspace?.publicSenderName || `${contextName} Support`,
      industry: workspace?.industry || '',
      website: workspace?.website || '',
      description: workspace?.description || '',
    },
    ownershipLabel: 'Workspace',
    isActive: Boolean(backendContext?.isActive),
    integrations: savedIntegrations || createWorkspaceIntegrations(contextId),
  };
}

export function AccountProvider({ children }) {
  const { user, isAuthenticated, refreshCurrentUser } = useAuth();
  const [contexts, setContexts] = useState([]);
  const [activeContextId, setActiveContextId] = useState('personal');
  const [isLoadingContexts, setIsLoadingContexts] = useState(false);
  const [loadedUserId, setLoadedUserId] = useState(null);

  const resetAccountState = useCallback(() => {
    setContexts([buildPersonalContext('anonymous', { isActive: true })]);
    setActiveContextId('personal');
    setLoadedUserId(null);
    setIsLoadingContexts(false);
  }, []);

  const refreshContexts = useCallback(async () => {
    if (!isAuthenticated || !user?.id) {
      resetAccountState();
      return;
    }

    setIsLoadingContexts(true);

    try {
      const [backendContexts, workspaces] = await Promise.all([
        getAccountContexts(),
        getMyWorkspaces(),
      ]);

      const workspaceMap = new Map(workspaces.map((workspace) => [workspace.id, workspace]));
      const nextContexts = backendContexts.map((context) => {
        if (context.type === 'personal') {
          return buildPersonalContext(user.id, context);
        }

        return buildWorkspaceContext(user.id, context, workspaceMap.get(context.id));
      });

      const resolvedContexts =
        nextContexts.length > 0
          ? nextContexts
          : [buildPersonalContext(user.id, { isActive: true })];
      const nextActiveContext =
        resolvedContexts.find((context) => context.isActive)?.id || 'personal';

      setContexts(resolvedContexts);
      setActiveContextId(nextActiveContext);
      setLoadedUserId(user.id);
    } catch {
      setContexts([buildPersonalContext(user.id, { isActive: true })]);
      setActiveContextId('personal');
      setLoadedUserId(user.id);
    } finally {
      setIsLoadingContexts(false);
    }
  }, [isAuthenticated, resetAccountState, user?.id]);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) {
      resetAccountState();
      return;
    }

    if (loadedUserId && loadedUserId !== user.id) {
      resetAccountState();
    }
  }, [isAuthenticated, loadedUserId, resetAccountState, user?.id]);

  useEffect(() => {
    refreshContexts();
  }, [refreshContexts]);

  const activeContext = useMemo(
    () =>
      contexts.find((context) => context.id === activeContextId) ||
      contexts[0] ||
      buildPersonalContext(user?.id || 'anonymous', { isActive: true }),
    [activeContextId, contexts, user?.id]
  );

  const isAccountBootstrapLoading =
    isAuthenticated && (isLoadingContexts || loadedUserId !== user?.id);

  const switchContext = async (contextId) => {
    const targetContext = contexts.find((context) => context.id === contextId);
    if (!targetContext) return false;

    const payload =
      targetContext.type === 'workspace'
        ? { type: 'workspace', id: targetContext.workspaceId }
        : { type: 'personal', id: null };

    try {
      await updateActiveContext(payload);
      await refreshCurrentUser();
      await refreshContexts();
      return true;
    } catch {
      return false;
    }
  };

  const replaceContextIntegrations = (contextId, integrations) => {
    setContexts((current) =>
      current.map((context) => {
        if (context.id !== contextId) return context;

        if (user?.id) {
          saveIntegrations(user.id, contextId, integrations);
        }

        return {
          ...context,
          integrations,
        };
      })
    );
  };

  const completeOnboarding = async () => {
    await refreshContexts();
  };

  const value = {
    contexts,
    activeContext,
    activeContextId,
    hasCompletedOnboarding: Boolean(user?.isOnboardingCompleted),
    isLoadingContexts,
    isAccountBootstrapLoading,
    switchContext,
    refreshContexts,
    replaceContextIntegrations,
    completeOnboarding,
    canManageActiveIntegrations:
      activeContext?.type === 'personal' || canManageIntegrations(activeContext?.role),
  };

  return <AccountContext.Provider value={value}>{children}</AccountContext.Provider>;
}

export function useAccountContext() {
  const context = useContext(AccountContext);

  if (!context) {
    throw new Error('useAccountContext must be used within AccountProvider');
  }

  return context;
}
