import { AlertCircle } from 'lucide-react';
import { useAppLanguage } from '../../context/AppLanguageContext';

function SidebarErrorState({ onRetry }) {
  const { t } = useAppLanguage();
  return (
    <div className="flex h-full flex-col items-center justify-center p-6 text-center">
      <AlertCircle className="h-8 w-8 text-red-400" />
      <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">{t('miscUi.failedToLoadChats')}</p>
      <button
        type="button"
        onClick={onRetry}
        className="mt-2 text-sm text-[var(--dialogly-accent)] underline underline-offset-2"
      >
        {t('miscUi.tryAgain')}
      </button>
    </div>
  );
}

export default SidebarErrorState;
