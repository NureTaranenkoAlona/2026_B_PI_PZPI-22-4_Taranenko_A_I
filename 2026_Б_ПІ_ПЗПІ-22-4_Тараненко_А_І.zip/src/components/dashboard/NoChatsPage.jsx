import { ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppLanguage } from '../../context/AppLanguageContext';

function EmptyInboxIllustration() {
  return (
    <svg width="120" height="120" viewBox="0 0 120 120" fill="none" aria-hidden="true">
      <rect x="22" y="28" width="76" height="58" rx="18" fill="#EEF0FE" />
      <path d="M22 48L48 66H72L98 48" stroke="#6366F1" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
      <rect x="34" y="18" width="24" height="14" rx="7" fill="#6366F1" fillOpacity="0.18" />
      <circle cx="84" cy="24" r="10" fill="#6366F1" />
      <path d="M84 19V29M79 24H89" stroke="white" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

function NoChatsPage() {
  const navigate = useNavigate();
  const { t } = useAppLanguage();

  return (
    <div className="flex-1 flex items-center justify-center bg-[#F5F6FA] dark:bg-[#181A20] px-6 py-10">
      <div className="w-full max-w-xl rounded-[32px] border border-[#E5E7EB] dark:border-[#2F3440] bg-white/95 dark:bg-[#1C1F26] shadow-xl shadow-indigo-100/40 dark:shadow-none p-8 sm:p-10">
        <div className="flex flex-col items-center text-center">
          <EmptyInboxIllustration />

          <h2 className="text-[#1A1D23] dark:text-white text-2xl tracking-tight mb-3">
            {t('chatUiExtra.noConversationsYet')}
          </h2>
          <p className="text-sm leading-relaxed text-[#6B7280] dark:text-[#9CA3AF] max-w-md mb-7">
            {t('chatUiExtra.connectChannelToStart')}
          </p>

          <button
            type="button"
            onClick={() => navigate('/settings')}
            className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-[var(--dialogly-accent)] text-white hover:bg-[var(--dialogly-accent-hover)] transition-colors shadow-md shadow-indigo-200/50 dark:shadow-none"
          >
            {t('chatUiExtra.connectChannel')}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default NoChatsPage;
