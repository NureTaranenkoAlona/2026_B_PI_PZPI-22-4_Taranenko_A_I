import { useAppLanguage } from '../../context/AppLanguageContext';

function EmptyChatBubbleIllustration() {
  return (
    <svg width="96" height="96" viewBox="0 0 96 96" fill="none" aria-hidden="true">
      <rect x="16" y="18" width="64" height="46" rx="18" fill="url(#dialogly-chat-empty)" />
      <path d="M36 64L32 78L48 68H62" fill="#EEF0FE" />
      <rect x="28" y="34" width="28" height="4" rx="2" fill="white" fillOpacity="0.95" />
      <rect x="28" y="44" width="40" height="4" rx="2" fill="white" fillOpacity="0.75" />
      <defs>
        <linearGradient id="dialogly-chat-empty" x1="16" y1="18" x2="80" y2="64" gradientUnits="userSpaceOnUse">
          <stop stopColor="#6366F1" />
          <stop offset="1" stopColor="#8B5CF6" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function NoChatSelected() {
  const { t } = useAppLanguage();

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-[#F5F6FA] dark:bg-[#181A20] select-none transition-colors">
      <div className="flex flex-col items-center gap-5 max-w-xs text-center px-6">
        <EmptyChatBubbleIllustration />

        <div className="space-y-2">
          <h2 className="text-[#1A1D23] dark:text-white">{t('dashboard.noConversationSelected')}</h2>
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] leading-relaxed">
            {t('dashboard.chooseChat')}
          </p>
        </div>

        <div className="flex items-center gap-2 mt-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-[#23262F] border border-[#E5E7EB] dark:border-[#343842] rounded-full shadow-sm">
            <div className="w-2 h-2 rounded-full bg-[#2AABEE]" />
            <span className="text-xs text-[#6B7280] dark:text-[#9CA3AF]">{t('dashboard.telegram')}</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-[#23262F] border border-[#E5E7EB] dark:border-[#343842] rounded-full shadow-sm">
            <div className="w-2 h-2 rounded-full bg-[#0084FF]" />
            <span className="text-xs text-[#6B7280] dark:text-[#9CA3AF]">{t('dashboard.messenger')}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default NoChatSelected;
