import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Send, MessageCircle, Moon, Sun, Settings, MoreHorizontal, Pin, Archive, ArchiveRestore, ChevronDown, ChevronRight } from 'lucide-react';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { useAppPreferences } from '../../context/AppPreferencesContext';
import { getProfileInitials, getStoredProfile, profileUpdatedEvent } from '../../utils/profileStorage';
import AccountSwitcher from '../account/AccountSwitcher';
import SidebarErrorState from './SidebarErrorState';

function PlatformIcon({ platform, size = 10 }) {
  if (platform === 'telegram') {
    return (
      <div
        style={{ width: size, height: size }}
        className="rounded-full bg-[#2AABEE] flex items-center justify-center flex-shrink-0"
      >
        <Send
          style={{ width: size * 0.55, height: size * 0.55 }}
          className="text-white"
          strokeWidth={2.5}
        />
      </div>
    );
  }

  if (platform === 'messenger') {
    return (
      <div
        style={{ width: size, height: size }}
        className="rounded-full bg-[#0084FF] flex items-center justify-center flex-shrink-0"
      >
        <svg
          viewBox="0 0 24 24"
          width={size * 0.7}
          height={size * 0.7}
          aria-hidden="true"
          className="text-white"
          fill="currentColor"
        >
          <path d="M12 2C6.477 2 2 6.145 2 11.258c0 2.91 1.45 5.507 3.717 7.205V22l3.23-1.773c.96.266 1.976.41 3.053.41 5.523 0 10-4.145 10-9.258S17.523 2 12 2Zm1.054 12.444-2.546-2.717-4.966 2.717 5.462-5.793 2.599 2.717 4.914-2.717-5.463 5.793Z" />
        </svg>
      </div>
    );
  }

  return null;
}

function ChatAvatar({ chat }) {
  if (chat.platform === 'telegram') {
    return (
      <div className="w-11 h-11 rounded-full bg-[#2AABEE] flex items-center justify-center text-white flex-shrink-0">
        <Send
          className="text-white"
          width={22}
          height={22}
          strokeWidth={2.3}
        />
      </div>
    );
  }

  if (chat.platform === 'messenger') {
    return (
      <div className="w-11 h-11 rounded-full bg-[#0084FF] flex items-center justify-center text-white flex-shrink-0">
        <svg
          viewBox="0 0 24 24"
          width={22}
          height={22}
          aria-hidden="true"
          fill="currentColor"
        >
          <path d="M12 2C6.477 2 2 6.145 2 11.258c0 2.91 1.45 5.507 3.717 7.205V22l3.23-1.773c.96.266 1.976.41 3.053.41 5.523 0 10-4.145 10-9.258S17.523 2 12 2Zm1.054 12.444-2.546-2.717-4.966 2.717 5.462-5.793 2.599 2.717 4.914-2.717-5.463 5.793Z" />
        </svg>
      </div>
    );
  }

  return (
    <div
      className="w-11 h-11 rounded-full flex items-center justify-center text-white text-sm"
      style={{ backgroundColor: chat.avatarColor }}
    >
      {chat.initials}
    </div>
  );
}

function ThemeToggle({ darkMode, onToggle }) {
  const { t } = useAppLanguage();

  return (
    <button
      type="button"
      onClick={onToggle}
      title={t('dashboard.toggleTheme')}
      className="w-8 h-8 rounded-lg hover:bg-[#F3F4F6] dark:hover:bg-[#2A2F3A] flex items-center justify-center transition-colors text-[#6B7280] dark:text-[#9CA3AF] hover:text-[#1A1D23] dark:hover:text-white"
    >
      {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
    </button>
  );
}

function ChatItem({ chat, isSelected, onClick, action, secondaryAction, isArchived = false }) {
  const { formatChatTimestamp } = useAppPreferences();

  return (
    <div
      style={{
        paddingInline: 'var(--dialogly-density-sidebar-item-x)',
        paddingBlock: 'var(--dialogly-density-sidebar-item-y)',
      }}
      className={`w-full flex items-center gap-3 px-4 py-3 transition-colors text-left group relative ${
        isSelected
          ? 'bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)]'
          : 'hover:bg-[#F5F6FA] dark:hover:bg-[#20242E]'
      }`}
    >
      {isSelected && (
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-8 bg-[var(--dialogly-accent)] rounded-r-full" />
      )}

      <button type="button" onClick={onClick} className="flex flex-1 min-w-0 items-center gap-3 text-left">
        <div className="relative flex-shrink-0">
          <ChatAvatar chat={chat} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-1 mb-0.5">
            <div
              className={`flex items-center gap-1.5 min-w-0 text-sm ${
                isSelected ? 'text-[var(--dialogly-accent)]' : 'text-[#1A1D23] dark:text-white'
              } ${chat.unreadCount > 0 ? 'font-semibold' : ''}`}
            >
              {chat.isPinned && <Pin className="w-3 h-3 flex-shrink-0" />}
              <span className="truncate">{chat.name}</span>
            </div>
            <span className="w-10 text-right text-xs tabular-nums text-[#9CA3AF] flex-shrink-0">
              {chat.timestampAt ? formatChatTimestamp(chat.timestampAt) : ''}
            </span>
          </div>

          <div className="flex items-center justify-between gap-1">
            <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF] truncate">{chat.lastMessage}</p>
            <div className="flex items-center gap-1 flex-shrink-0">
              {secondaryAction}
              {chat.unreadCount > 0 && !isArchived && (
                <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-[var(--dialogly-accent)] text-white text-[10px] flex items-center justify-center">
                  {chat.unreadCount}
                </span>
              )}
            </div>
          </div>
        </div>
      </button>

      {action}
    </div>
  );
}

function ChatSkeleton() {
  return (
    <div className="flex items-center gap-3 px-4 py-3 animate-pulse">
      <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 shrink-0" />
      <div className="flex-1 space-y-2 min-w-0">
        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
      </div>
      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-8 shrink-0" />
    </div>
  );
}

function EmptySearchIllustration() {
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" aria-hidden="true">
      <circle cx="28" cy="28" r="14" stroke="#6366F1" strokeWidth="4" />
      <path d="M38 38L50 50" stroke="#6366F1" strokeWidth="4" strokeLinecap="round" />
      <circle cx="28" cy="28" r="6" fill="#EEF0FE" />
    </svg>
  );
}

function EmptyArchiveIllustration() {
  return (
    <svg width="72" height="72" viewBox="0 0 72 72" fill="none" aria-hidden="true">
      <rect x="16" y="24" width="40" height="28" rx="10" fill="#EEF0FE" />
      <path d="M24 18H48L52 24H20L24 18Z" fill="#6366F1" />
      <path d="M36 31V43M30 37H42" stroke="#6366F1" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  );
}

function SidebarEmptyState({ title, description, action, compact = false }) {
  return (
    <div className={`flex flex-col items-center justify-center text-center px-6 ${compact ? 'py-8' : 'h-full py-10'}`}>
      <EmptyArchiveIllustration />
      <h3 className="mt-4 text-sm text-[#374151] dark:text-[#E5E7EB]">{title}</h3>
      {description ? (
        <p className="mt-1 text-sm text-[#9CA3AF] max-w-[220px] leading-relaxed">{description}</p>
      ) : null}
      {action}
    </div>
  );
}

function Sidebar({
  chats,
  archivedChats,
  selectedId,
  onSelect,
  onTogglePin,
  onArchive,
  darkMode,
  onToggleTheme,
  isLoading = false,
  errorMessage = '',
  onRetry,
  tourSidebarRef,
  tourFiltersRef,
  tourSettingsButtonRef,
}) {
  const { t, isRTL } = useAppLanguage();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [profile, setProfile] = useState(() => getStoredProfile());
  const [openMenuChatId, setOpenMenuChatId] = useState(null);
  const [showArchived, setShowArchived] = useState(false);

  useEffect(() => {
    if (chats.length === 0 && archivedChats.length > 0) {
      setShowArchived(true);
    }
  }, [archivedChats.length, chats.length]);

  useEffect(() => {
    const handleProfileUpdate = (event) => {
      setProfile(event.detail || getStoredProfile());
    };

    window.addEventListener(profileUpdatedEvent, handleProfileUpdate);

    return () => {
      window.removeEventListener(profileUpdatedEvent, handleProfileUpdate);
    };
  }, []);

  const filterChats = (chatList) =>
    chatList.filter((chat) => {
      const matchesPlatform = activeTab === 'all' || chat.platform === activeTab;
      const matchesSearch =
        chat.name.toLowerCase().includes(search.toLowerCase()) ||
        chat.lastMessage.toLowerCase().includes(search.toLowerCase());

      return matchesPlatform && matchesSearch;
    });

  const filtered = useMemo(() => filterChats(chats), [activeTab, chats, search]);
  const filteredArchived = useMemo(() => filterChats(archivedChats), [activeTab, archivedChats, search]);

  const tabs = [
    { id: 'all', label: t('dashboard.all') },
    { id: 'telegram', label: t('dashboard.telegram') },
    { id: 'messenger', label: t('dashboard.messenger') },
  ];

  return (
    <div
      ref={tourSidebarRef}
      className={`w-80 max-w-full flex-shrink-0 h-full flex flex-col bg-white dark:bg-[#1C1F26] ${isRTL ? 'border-l' : 'border-r'} border-[#E5E7EB] dark:border-[#2F3440]`}
    >
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#F3F4F6] dark:border-[#2F3440]">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center flex-shrink-0">
            <MessageCircle className="w-5 h-5 text-white" fill="white" strokeWidth={1.5} />
          </div>
          <div className="min-w-0">
            <span className="text-[#1A1D23] dark:text-white text-base block">Dialogly</span>
            <div className="mt-1">
              <AccountSwitcher compact align={isRTL ? 'right' : 'left'} />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <ThemeToggle darkMode={darkMode} onToggle={onToggleTheme} />
        </div>
      </div>

      <div
        className="px-4 border-b border-[#F3F4F6] dark:border-[#2F3440]"
        style={{ paddingBlock: 'var(--dialogly-density-sidebar-section-y)' }}
      >
        <div className="relative">
          <Search className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF] ${isRTL ? 'right-3' : 'left-3'}`} />
          <input
            type="text"
            placeholder={t('dashboard.searchConversations')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full py-2 bg-[#F5F6FA] dark:bg-[#232833] border border-transparent dark:border-[#2F3440] rounded-lg text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF] focus:outline-none focus:border-[var(--dialogly-accent)] focus:bg-white dark:focus:bg-[#1F2430] transition-colors ${isRTL ? 'pr-9 pl-3 text-right' : 'pl-9 pr-3'}`}
          />
        </div>
      </div>

      <div
        ref={tourFiltersRef}
        className="flex items-center gap-1 px-4 border-b border-[#F3F4F6] dark:border-[#2F3440] overflow-x-auto"
        style={{ paddingBlock: 'calc(var(--dialogly-density-sidebar-section-y) - 2px)' }}
      >
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] text-[var(--dialogly-accent)]'
                : 'text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F5F6FA] dark:hover:bg-[#232833] hover:text-[#1A1D23] dark:hover:text-white'
            }`}
          >
            {tab.id === 'telegram' && <div className="w-2 h-2 rounded-full bg-[#2AABEE]" />}
            {tab.id === 'messenger' && <div className="w-2 h-2 rounded-full bg-[#0084FF]" />}
            {tab.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto">
        {errorMessage && !isLoading ? (
          <SidebarErrorState onRetry={onRetry} />
        ) : isLoading ? (
          <div className="py-2">
            {Array.from({ length: 5 }).map((_, index) => (
              <ChatSkeleton key={index} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          search.trim() ? (
            <div className="flex flex-col items-center justify-center py-8 text-center px-6">
              <EmptySearchIllustration />
              <p className="mt-2 text-sm text-[#9CA3AF]">
                No results found for "{search}"
              </p>
            </div>
          ) : archivedChats.length > 0 ? (
            <div className="px-4 py-6">
              <SidebarEmptyState title={t('chatUiExtra.noActiveChats')} compact />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-6 text-center">
              <svg width="88" height="88" viewBox="0 0 88 88" fill="none" aria-hidden="true">
                <rect x="18" y="24" width="52" height="38" rx="14" fill="#EEF0FE" />
                <path d="M18 38L36 50H52L70 38" stroke="#6366F1" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="62" cy="24" r="10" fill="#6366F1" />
                <path d="M62 19V29M57 24H67" stroke="white" strokeWidth="3" strokeLinecap="round" />
              </svg>
              <h3 className="mt-4 font-semibold text-[#374151] dark:text-[#E5E7EB]">{t('chatUiExtra.noConversationsYet')}</h3>
              <p className="mt-1 text-sm text-[#9CA3AF]">{t('chatUiExtra.connectChannelToStart')}</p>
              <button
                type="button"
                onClick={() => navigate('/settings')}
                className="mt-4 px-4 py-2 bg-[var(--dialogly-accent)] text-white rounded-lg text-sm hover:bg-[var(--dialogly-accent-hover)] transition-colors"
              >
                {t('chatUiExtra.connectChannel')}
              </button>
            </div>
          )
        ) : (
          filtered.map((chat) => (
            <ChatItem
              key={chat.id}
              chat={chat}
              isSelected={selectedId === chat.id}
              onClick={() => onSelect(chat.id)}
              action={
                <div className="relative">
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      setOpenMenuChatId((current) => (current === chat.id ? null : chat.id));
                    }}
                    className="opacity-0 group-hover:opacity-100 w-7 h-7 rounded-lg hover:bg-[#ECEFF5] dark:hover:bg-[#2A2F3A] flex items-center justify-center transition-all"
                  >
                    <MoreHorizontal className="w-4 h-4 text-[#9CA3AF]" />
                  </button>

                  {openMenuChatId === chat.id && (
                    <div className="absolute right-0 top-9 z-20 w-36 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] shadow-lg p-1.5">
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          setOpenMenuChatId(null);
                          onTogglePin(chat.id);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-[#1A1D23] dark:text-white hover:bg-[#F5F6FA] dark:hover:bg-[#2A2F3A]"
                      >
                        <Pin className="w-4 h-4" />
                        {chat.isPinned ? 'Unpin' : 'Pin'}
                      </button>
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          setOpenMenuChatId(null);
                          onArchive(chat.id, true);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-[#1A1D23] dark:text-white hover:bg-[#F5F6FA] dark:hover:bg-[#2A2F3A]"
                      >
                        <Archive className="w-4 h-4" />
                        Archive
                      </button>
                    </div>
                  )}
                </div>
              }
            />
          ))
        )}

        <div className="mt-2 border-t border-[#F3F4F6] dark:border-[#2F3440]">
          <button
            type="button"
            onClick={() => setShowArchived((previous) => !previous)}
            className="w-full flex items-center justify-between px-4 py-3 text-sm text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F5F6FA] dark:hover:bg-[#20242E] transition-colors"
          >
            <span>Archived chats ({archivedChats.length})</span>
            {showArchived ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>

          {showArchived && (
            filteredArchived.length === 0 ? (
              <div className="px-4 pb-4">
                <SidebarEmptyState title={t('chatUiExtra.noArchivedChats')} compact />
              </div>
            ) : (
              filteredArchived.map((chat) => (
                <ChatItem
                  key={chat.id}
                  chat={chat}
                  isSelected={selectedId === chat.id}
                  onClick={() => onSelect(chat.id)}
                  isArchived
                  secondaryAction={
                    <button
                      type="button"
                      onClick={(event) => {
                        event.stopPropagation();
                        onArchive(chat.id, false);
                      }}
                      className="opacity-0 group-hover:opacity-100 px-2 py-1 rounded-lg text-[11px] text-[#5B6CF8] hover:bg-[#EEF0FE] dark:hover:bg-[#2A2F3A] transition-all"
                    >
                      Unarchive
                    </button>
                  }
                />
              ))
            )
          )}
        </div>
      </div>

      <div className="border-t border-[#F3F4F6] dark:border-[#2F3440] px-4 py-3 flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-[var(--dialogly-accent)] flex items-center justify-center text-white text-xs flex-shrink-0 overflow-hidden">
          {profile.avatar ? (
            <img src={profile.avatar} alt="User avatar" className="w-full h-full object-cover" />
          ) : (
            getProfileInitials(profile)
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-[#1A1D23] dark:text-white truncate">
            {`${profile.firstName} ${profile.lastName}`.trim() || t('common.yourAccount')}
          </p>
          <p className="text-xs text-[#9CA3AF] truncate">{profile.email}</p>
        </div>
        <div className="w-2 h-2 rounded-full bg-[#22C55E] flex-shrink-0" />
        <Link
          ref={tourSettingsButtonRef}
          to="/settings"
          title={t('common.openSettings')}
          className="w-8 h-8 rounded-lg hover:bg-[#F3F4F6] dark:hover:bg-[#2A2F3A] flex items-center justify-center transition-colors text-[#9CA3AF] hover:text-[#1A1D23] dark:hover:text-white flex-shrink-0"
        >
          <Settings className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}

export default Sidebar;
