import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import EmojiPicker from 'emoji-picker-react';
import {
  Send,
  Paperclip,
  Smile,
  ImagePlay,
  Search,
  FileText,
  X,
  Image as ImageIcon,
  Film,
  ChevronDown,
  ChevronUp,
  Info,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { useAppPreferences } from '../../context/AppPreferencesContext';
import { downloadAttachment } from '../../api/chatApi';
import { useToast } from '../../context/ToastContext';

const quickReactions = ['\u{1F44D}', '\u{2764}\u{FE0F}', '\u{1F601}', '\u{1F62F}', '\u{1F622}'];
const giphyApiKey = import.meta.env.VITE_GIPHY_API_KEY || '';
const giphyBaseUrl = 'https://api.giphy.com/v1/gifs';
const emojiLocaleLoaders = {
  en: () => import('emoji-picker-react/dist/data/emojis-en.js'),
  uk: () => import('emoji-picker-react/dist/data/emojis-uk.js'),
  de: () => import('emoji-picker-react/dist/data/emojis-de.js'),
  fr: () => import('emoji-picker-react/dist/data/emojis-fr.js'),
  es: () => import('emoji-picker-react/dist/data/emojis-es.js'),
  pl: () => import('emoji-picker-react/dist/data/emojis-pl.js'),
  pt: () => import('emoji-picker-react/dist/data/emojis-pt.js'),
  it: () => import('emoji-picker-react/dist/data/emojis-it.js'),
  nl: () => import('emoji-picker-react/dist/data/emojis-nl.js'),
  hi: () => import('emoji-picker-react/dist/data/emojis-hi.js'),
  hu: () => import('emoji-picker-react/dist/data/emojis-hu.js'),
  ja: () => import('emoji-picker-react/dist/data/emojis-ja.js'),
  ko: () => import('emoji-picker-react/dist/data/emojis-ko.js'),
  zh: () => import('emoji-picker-react/dist/data/emojis-zh.js'),
};

function decodeHtmlEntities(value) {
  if (typeof value !== 'string') return value;

  return value
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function normalizeEmojiLocaleData(localeData) {
  if (!localeData?.categories) return localeData;

  return {
    ...localeData,
    categories: Object.fromEntries(
      Object.entries(localeData.categories).map(([key, category]) => [
        key,
        category
          ? {
              ...category,
              name: decodeHtmlEntities(category.name),
            }
          : category,
      ])
    ),
  };
}

function getEmojiCategories(t) {
  return [
    { category: 'suggested', name: t('dashboard.emojiCategorySuggested') },
    { category: 'smileys_people', name: t('dashboard.emojiCategorySmileysPeople') },
    { category: 'animals_nature', name: t('dashboard.emojiCategoryAnimalsNature') },
    { category: 'food_drink', name: t('dashboard.emojiCategoryFoodDrink') },
    { category: 'travel_places', name: t('dashboard.emojiCategoryTravelPlaces') },
    { category: 'activities', name: t('dashboard.emojiCategoryActivities') },
    { category: 'objects', name: t('dashboard.emojiCategoryObjects') },
    { category: 'symbols', name: t('dashboard.emojiCategorySymbols') },
    { category: 'flags', name: t('dashboard.emojiCategoryFlags') },
  ];
}

function normalizeSearchText(value) {
  return (value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function levenshteinDistance(a, b) {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;

  const matrix = Array.from({ length: b.length + 1 }, (_, rowIndex) =>
    Array.from({ length: a.length + 1 }, (_, columnIndex) => {
      if (rowIndex === 0) return columnIndex;
      if (columnIndex === 0) return rowIndex;
      return 0;
    })
  );

  for (let row = 1; row <= b.length; row += 1) {
    for (let column = 1; column <= a.length; column += 1) {
      const substitutionCost = a[column - 1] === b[row - 1] ? 0 : 1;
      matrix[row][column] = Math.min(
        matrix[row - 1][column] + 1,
        matrix[row][column - 1] + 1,
        matrix[row - 1][column - 1] + substitutionCost
      );
    }
  }

  return matrix[b.length][a.length];
}

function isSimilarTokenMatch(queryToken, messageToken) {
  if (queryToken === messageToken) return true;
  if (messageToken.includes(queryToken) || queryToken.includes(messageToken)) {
    return Math.min(queryToken.length, messageToken.length) >= 3;
  }

  const maxDistance = queryToken.length >= 7 ? 2 : queryToken.length >= 4 ? 1 : 0;
  return levenshteinDistance(queryToken, messageToken) <= maxDistance;
}

function isFuzzyMessageMatch(message, query) {
  const normalizedQuery = normalizeSearchText(query);
  if (!normalizedQuery) return false;

  const normalizedText = normalizeSearchText(
    [message.text, ...(message.attachments?.map((attachment) => attachment.name) ?? [])].filter(Boolean).join(' ')
  );

  if (!normalizedText) return false;
  if (normalizedText.includes(normalizedQuery)) return true;

  const queryTokens = normalizedQuery.split(' ').filter(Boolean);
  const messageTokens = normalizedText.split(' ').filter(Boolean);

  if (queryTokens.length === 0 || messageTokens.length === 0) return false;

  return queryTokens.every((queryToken) =>
    messageTokens.some((messageToken) => isSimilarTokenMatch(queryToken, messageToken))
  );
}

function AttachmentPreview({ attachment, compact, onOpen, onMediaLoad }) {
  if (attachment.kind === 'image') {
    return (
      <button type="button" onClick={() => onOpen?.(attachment)} className="block">
        <img
          src={attachment.url}
          alt={attachment.name}
          onLoad={onMediaLoad}
          className={compact ? 'w-32 h-32 object-cover rounded-xl' : 'w-44 h-44 object-cover rounded-xl'}
        />
      </button>
    );
  }

  if (attachment.kind === 'video') {
    return (
      <button type="button" onClick={() => onOpen?.(attachment)} className="block">
        <video
          src={attachment.url}
          autoPlay
          loop
          muted
          playsInline
          className={compact ? 'block w-40 rounded-xl bg-transparent object-cover' : 'block w-52 rounded-xl bg-transparent object-cover'}
        />
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={() => onOpen?.(attachment)}
      className="flex items-center gap-3 rounded-xl border border-white/20 bg-white/10 dark:bg-black/10 px-3 py-3 min-w-[180px] text-left"
    >
      <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
        <FileText className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-sm truncate">{attachment.name}</p>
        <p className="text-xs opacity-75">{attachment.fileTypeLabel}</p>
      </div>
    </button>
  );
}

function GifPreview({ gifUrl, compact = false, onLoad }) {
  return (
    <img
      src={gifUrl}
      alt="GIF"
      onLoad={onLoad}
      className={compact ? 'w-32 max-w-[250px] h-auto rounded-xl' : 'w-full max-w-[250px] h-auto rounded-xl'}
      loading="lazy"
    />
  );
}

function formatFileSize(size) {
  if (!size && size !== 0) return '';
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  if (size < 1024 * 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  return `${(size / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

function triggerFileDownload(url, fileName) {
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName || 'attachment';
  document.body.appendChild(link);
  link.click();
  link.remove();
}

function openAttachmentPreviewTab(sourceUrl, fileName, contentType) {
  const params = new URLSearchParams({
    src: sourceUrl,
    name: fileName || 'attachment',
    type: contentType || 'application/octet-stream',
  });

  window.open(`/attachment-preview?${params.toString()}`, '_blank', 'noopener,noreferrer');
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isPdfAttachment(attachment) {
  const fileName = attachment?.name || '';
  const contentType = attachment?.type || attachment?.previewContentType || '';
  return contentType === 'application/pdf' || /\.pdf$/i.test(fileName);
}

function isPreviewableFileAttachment(attachment) {
  return attachment?.kind !== 'file' || isPdfAttachment(attachment);
}

function PlatformBadge({ platform }) {
  const { t } = useAppLanguage();

  if (platform === 'telegram') {
    return (
      <div className="flex items-center gap-1.5 px-3 py-1 bg-[#EEF7FE] dark:bg-[#1E3140] rounded-full">
        <div className="w-2 h-2 rounded-full bg-[#2AABEE]" />
        <span className="text-xs text-[#2AABEE]">{t('dashboard.telegram')}</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5 px-3 py-1 bg-[#EEF5FF] dark:bg-[#1C2F47] rounded-full">
        <div className="w-2 h-2 rounded-full bg-[#0084FF]" />
        <span className="text-xs text-[#0084FF]">{t('dashboard.messenger')}</span>
    </div>
  );
}

function ChatHeaderAvatar({ chat }) {
  if (chat.platform === 'telegram') {
    return (
      <div className="w-11 h-11 rounded-full bg-[#2AABEE] flex items-center justify-center text-white flex-shrink-0">
        <Send
          className="text-white"
          width={22}
          height={22}
          strokeWidth={2.3}
        />
      </div>
    );
  }

  if (chat.platform === 'messenger') {
    return (
      <div className="w-11 h-11 rounded-full bg-[#0084FF] flex items-center justify-center text-white flex-shrink-0">
        <svg
          viewBox="0 0 24 24"
          width={22}
          height={22}
          aria-hidden="true"
          fill="currentColor"
        >
          <path d="M12 2C6.477 2 2 6.145 2 11.258c0 2.91 1.45 5.507 3.717 7.205V22l3.23-1.773c.96.266 1.976.41 3.053.41 5.523 0 10-4.145 10-9.258S17.523 2 12 2Zm1.054 12.444-2.546-2.717-4.966 2.717 5.462-5.793 2.599 2.717 4.914-2.717-5.463 5.793Z" />
        </svg>
      </div>
    );
  }

  return (
    <div
      className="w-11 h-11 rounded-full flex items-center justify-center text-white text-sm flex-shrink-0"
      style={{ backgroundColor: chat.avatarColor }}
    >
      {chat.initials}
    </div>
  );
}

function MessageBubble({
  message,
  onToggleReaction,
  onOpenAttachment,
  registerMessageRef,
  isSearchMatch,
  isActiveSearchMatch,
  onMediaLoad,
  reactionMessageId,
  setReactionMessageId,
}) {
  const { formatTime } = useAppPreferences();
  const { t } = useAppLanguage();
  const isMine = message?.sender === 'me';
  const messageId = message?.id;
  const selectedReaction = message?.dialoglyReaction ?? message?.reaction ?? null;
  const showReactions = Boolean(messageId && reactionMessageId === messageId);
  const hasGif = Boolean(message?.gifUrl);
  const hasText = Boolean(message?.text);
  const attachments = message?.attachments ?? [];
  const isMediaOnlyMessage = !hasGif && !hasText && attachments.length > 0
    && attachments.every((attachment) => attachment.kind === 'image' || attachment.kind === 'video');
  const reactionBadges = useMemo(() => {
    const groupedReactions = new Map();

    (message?.reactions ?? []).forEach((reaction) => {
      const emoji = reaction?.emoji;
      if (!emoji) return;

      const source = reaction.source || 'unknown';
      const existing = groupedReactions.get(emoji) ?? {
        emoji,
        count: 0,
        sources: [],
      };

      groupedReactions.set(emoji, {
        ...existing,
        count: existing.count + 1,
        sources: [...existing.sources, source],
      });
    });

    if (groupedReactions.size === 0 && selectedReaction) {
      groupedReactions.set(selectedReaction, {
        emoji: selectedReaction,
        count: 1,
        sources: ['dialogly'],
      });
    }

    return [...groupedReactions.values()];
  }, [message?.reactions, selectedReaction]);

  const handleReactionClick = (event, emoji) => {
    event.stopPropagation();

    try {
      if (!messageId || !emoji || typeof onToggleReaction !== 'function') {
        return;
      }

      onToggleReaction(messageId, emoji);
    } catch (error) {
      console.error('Failed to toggle message reaction', error);
    } finally {
      setReactionMessageId?.(null);
    }
  };

  return (
    <div
      ref={(node) => {
        if (messageId) {
          registerMessageRef?.(messageId, node);
        }
      }}
      className={`flex flex-col ${isMine ? 'items-end' : 'items-start'} gap-1 overflow-visible px-1 focus:outline-none`}
      tabIndex={0}
    >
      <div className="relative w-fit max-w-[75%] overflow-visible">
        {showReactions && messageId && (
          <div
            className={`absolute bottom-full z-30 mb-2 flex w-max max-w-[calc(100vw-3rem)] items-center gap-1 rounded-full border border-gray-200 bg-white px-2 py-1 text-gray-900 shadow-lg dark:border-gray-700 dark:bg-gray-800 dark:text-white ${
              isMine ? 'right-0' : 'left-0'
            }`}
            onClick={(event) => event.stopPropagation()}
          >
            {quickReactions.map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={(event) => handleReactionClick(event, emoji)}
                className={`h-8 w-8 rounded-full text-base transition-colors ${
                  selectedReaction === emoji
                    ? 'bg-gray-100 dark:bg-gray-700'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

        <div
          onClick={(event) => {
            if (event.ctrlKey || event.metaKey) {
              event.preventDefault();
              event.stopPropagation();
              setReactionMessageId?.((current) => current === messageId ? null : messageId);
            }
          }}
          onContextMenu={(event) => {
            event.preventDefault();
            event.stopPropagation();
            setReactionMessageId?.((current) => current === messageId ? null : messageId);
          }}
          className={`text-sm leading-relaxed cursor-default ${
            isMediaOnlyMessage
              ? 'p-0 bg-transparent border-none shadow-none'
              : `px-4 py-3 rounded-2xl shadow-sm ${
                  isMine
                    ? 'bg-[var(--dialogly-accent)] text-white rounded-br-md'
                    : 'bg-white dark:bg-[#23262F] text-[#1A1D23] dark:text-white border border-[#E5E7EB] dark:border-[#343842] rounded-bl-md'
                }`
          } ${
            isActiveSearchMatch
              ? 'ring-2 ring-[var(--dialogly-accent)] ring-offset-2 ring-offset-[#F5F6FA] dark:ring-offset-[#181A20]'
              : isSearchMatch
                ? 'ring-2 ring-[var(--dialogly-accent-border)] dark:ring-[var(--dialogly-accent-border-dark)]'
                : ''
          }`}
        >
          <div className="space-y-3">
            {hasGif ? <GifPreview gifUrl={message.gifUrl} onLoad={onMediaLoad} /> : null}

            {attachments.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {attachments.map((attachment) => (
                  <AttachmentPreview
                    key={attachment.id}
                    attachment={attachment}
                    compact={attachments.length > 1}
                    onOpen={onOpenAttachment}
                    onMediaLoad={onMediaLoad}
                  />
                ))}
              </div>
            )}

            {hasText ? <p>{message.text}</p> : null}
          </div>
        </div>

        {reactionBadges.length > 0 && (
          <div className={`mt-1 flex ${isMine ? 'justify-end' : 'justify-start'}`}>
            <div className="flex flex-wrap gap-1">
              {reactionBadges.map((reactionBadge) => {
                const canRemoveFromDialogly = reactionBadge.sources.includes('dialogly')
                  && reactionBadge.emoji === selectedReaction;

                return (
                  <button
                    key={`${reactionBadge.emoji}-${reactionBadge.sources.join('-')}`}
                    type="button"
                    onClick={(event) => {
                      if (canRemoveFromDialogly) {
                        handleReactionClick(event, reactionBadge.emoji);
                      }
                    }}
                    className={`inline-flex items-center gap-1 rounded-full border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] shadow-sm px-2 py-0.5 text-sm transition-transform ${
                      canRemoveFromDialogly ? 'hover:scale-105' : 'cursor-default'
                    }`}
                    aria-label={canRemoveFromDialogly ? t('dashboard.removeReaction') : undefined}
                  >
                    <span>{reactionBadge.emoji}</span>
                    <span className="text-[11px] leading-none text-[#6B7280] dark:text-[#9CA3AF]">
                      {reactionBadge.count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
      <span className="text-xs text-[#9CA3AF] px-1">{formatTime(message?.createdAt)}</span>
    </div>
  );
}

function MessageSkeleton({ isOutgoing }) {
  return (
    <div className={`flex ${isOutgoing ? 'justify-end' : 'justify-start'} mb-3 animate-pulse`}>
      <div
        className={`h-10 bg-gray-200 dark:bg-gray-700 rounded-2xl ${isOutgoing ? 'w-48' : 'w-56'}`}
      />
    </div>
  );
}

function ContactDetailsSkeleton() {
  return (
    <div className="space-y-5 animate-pulse">
      <div>
        <div className="h-3 w-24 rounded bg-gray-200 dark:bg-gray-700 mb-3" />
        <div className="h-11 w-full rounded-xl bg-gray-200 dark:bg-gray-700" />
      </div>
      <div>
        <div className="h-3 w-16 rounded bg-gray-200 dark:bg-gray-700 mb-3" />
        <div className="h-36 w-full rounded-xl bg-gray-200 dark:bg-gray-700" />
      </div>
      <div className="h-10 w-full rounded-xl bg-gray-200 dark:bg-gray-700" />
    </div>
  );
}

function EmptyMessagesIllustration() {
  return (
    <svg width="88" height="88" viewBox="0 0 88 88" fill="none" aria-hidden="true">
      <rect x="18" y="22" width="52" height="34" rx="14" fill="#EEF0FE" />
      <path d="M30 56L28 68L40 60H54" fill="#EEF0FE" />
      <rect x="30" y="34" width="28" height="4" rx="2" fill="#6366F1" />
      <rect x="30" y="42" width="20" height="4" rx="2" fill="#A5B4FC" />
    </svg>
  );
}

function ChatArea({
  chat,
  messages,
  onSendMessage,
  onToggleReaction,
  onUpdateChatDetails,
  isLoadingMessages = false,
  isLoadingChatDetails = false,
  messageLoadError = '',
  onRetryMessages,
  tourChatWindowRef,
  tourComposerRef,
}) {
  const { t, language } = useAppLanguage();
  const { formatConversationDayLabel } = useAppPreferences();
  const { showError, showSuccess } = useToast();
  const [messageText, setMessageText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showMessageSearch, setShowMessageSearch] = useState(false);
  const [activeSearchIndex, setActiveSearchIndex] = useState(0);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showGifPicker, setShowGifPicker] = useState(false);
  const [gifQuery, setGifQuery] = useState('');
  const [debouncedGifQuery, setDebouncedGifQuery] = useState('');
  const [gifResults, setGifResults] = useState([]);
  const [isLoadingGifs, setIsLoadingGifs] = useState(false);
  const [gifError, setGifError] = useState('');
  const [emojiLocaleData, setEmojiLocaleData] = useState(null);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [pendingAttachments, setPendingAttachments] = useState([]);
  const [viewerAttachment, setViewerAttachment] = useState(null);
  const [attachmentError, setAttachmentError] = useState('');
  const [showScrollToBottom, setShowScrollToBottom] = useState(false);
  const [showDetailsPanel, setShowDetailsPanel] = useState(false);
  const [customNameInput, setCustomNameInput] = useState('');
  const [notesInput, setNotesInput] = useState('');
  const [isSavingDetails, setIsSavingDetails] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [showNameSaved, setShowNameSaved] = useState(false);
  const [showNotesSaved, setShowNotesSaved] = useState(false);
  const [reactionMessageId, setReactionMessageId] = useState(null);
  const scrollContainerRef = useRef(null);
  const messagesEndRef = useRef(null);
  const searchInputRef = useRef(null);
  const messageRefs = useRef(new Map());
  const inputRef = useRef(null);
  const emojiPickerRef = useRef(null);
  const gifPickerRef = useRef(null);
  const emojiCloseTimeoutRef = useRef(null);
  const attachMenuRef = useRef(null);
  const imageInputRef = useRef(null);
  const videoInputRef = useRef(null);
  const fileInputRef = useRef(null);
  const shouldAutoScrollRef = useRef(true);
  const nameSavedTimeoutRef = useRef(null);
  const notesSavedTimeoutRef = useRef(null);
  const previousMessageCountRef = useRef(0);
  const isSearchNavigationActive = showMessageSearch && Boolean(searchQuery.trim());

  useEffect(() => {
    setCustomNameInput(chat.customName || chat.originalName || chat.name || '');
    setNotesInput(chat.notes || '');
  }, [chat.customName, chat.notes, chat.originalName, chat.name]);

  useEffect(() => {
    setReactionMessageId(null);
  }, [chat?.id]);

  useEffect(() => {
    return () => {
      if (nameSavedTimeoutRef.current) {
        clearTimeout(nameSavedTimeoutRef.current);
      }

      if (notesSavedTimeoutRef.current) {
        clearTimeout(notesSavedTimeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    return () => {
      if (viewerAttachment?.previewUrl?.startsWith('blob:')) {
        URL.revokeObjectURL(viewerAttachment.previewUrl);
      }
    };
  }, [viewerAttachment]);

  const groupedLabel = useMemo(() => {
    const referenceDate = messages[messages.length - 1]?.createdAt ?? new Date();
    return formatConversationDayLabel(referenceDate);
  }, [formatConversationDayLabel, messages]);

  const matchedMessageIds = useMemo(() => {
    const trimmedQuery = searchQuery.trim();
    if (!trimmedQuery) return [];

    return messages
      .filter((message) => isFuzzyMessageMatch(message, trimmedQuery))
      .map((message) => message.id);
  }, [messages, searchQuery]);

  const activeMatchedMessageId =
    matchedMessageIds.length > 0 ? matchedMessageIds[activeSearchIndex] ?? matchedMessageIds[0] : null;

  const scrollToBottom = (behavior = 'auto') => {
    messagesEndRef.current?.scrollIntoView({ behavior, block: 'end' });
  };

  const handleMediaLoadScroll = () => {
    if (isSearchNavigationActive) return;
    scrollToBottom('auto');
    shouldAutoScrollRef.current = true;
  };

  useLayoutEffect(() => {
    scrollToBottom('auto');
    shouldAutoScrollRef.current = true;
    previousMessageCountRef.current = messages.length;
  }, [chat?.id]);

  useLayoutEffect(() => {
    if (isSearchNavigationActive) {
      previousMessageCountRef.current = messages.length;
      return;
    }

    if (messages.length === 0) {
      previousMessageCountRef.current = 0;
      return;
    }

    if (previousMessageCountRef.current === 0) {
      scrollToBottom('auto');
      shouldAutoScrollRef.current = true;
    } else if (messages.length !== previousMessageCountRef.current) {
      scrollToBottom('auto');
      shouldAutoScrollRef.current = true;
    }

    previousMessageCountRef.current = messages.length;
  }, [isSearchNavigationActive, messages]);

  useEffect(() => {
    if (isSearchNavigationActive) return undefined;

    const container = scrollContainerRef.current;
    if (!container) return undefined;

    const images = Array.from(container.querySelectorAll('img'));
    if (images.length === 0) return undefined;

    const pendingImages = images.filter((image) => !image.complete);
    if (pendingImages.length === 0) {
      scrollToBottom('auto');
      shouldAutoScrollRef.current = true;
      return undefined;
    }

    const handleImageLoad = () => {
      scrollToBottom('auto');
      shouldAutoScrollRef.current = true;
    };

    pendingImages.forEach((image) => {
      image.addEventListener('load', handleImageLoad);
    });

    return () => {
      pendingImages.forEach((image) => {
        image.removeEventListener('load', handleImageLoad);
      });
    };
  }, [chat?.id, isSearchNavigationActive, messages]);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const updateScrollButton = () => {
      const distanceToBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
      setShowScrollToBottom(distanceToBottom > 240);
      shouldAutoScrollRef.current = distanceToBottom <= 240;
    };

    updateScrollButton();
    container.addEventListener('scroll', updateScrollButton);

    return () => {
      container.removeEventListener('scroll', updateScrollButton);
    };
  }, [chat?.id, messages]);

  useEffect(() => {
    if (!showMessageSearch) return;

    requestAnimationFrame(() => {
      searchInputRef.current?.focus();
      searchInputRef.current?.select();
    });
  }, [showMessageSearch]);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setActiveSearchIndex(0);
      return;
    }

    setActiveSearchIndex((previousIndex) => {
      if (matchedMessageIds.length === 0) return 0;
      return Math.min(previousIndex, matchedMessageIds.length - 1);
    });
  }, [matchedMessageIds, searchQuery]);

  useEffect(() => {
    if (!activeMatchedMessageId) return;

    const targetNode = messageRefs.current.get(activeMatchedMessageId);
    targetNode?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, [activeMatchedMessageId]);

  useEffect(() => {
    let cancelled = false;
    const loadEmojiLocale = emojiLocaleLoaders[language];

    if (!loadEmojiLocale) {
      setEmojiLocaleData(null);
      return undefined;
    }

    loadEmojiLocale()
      .then((module) => {
        if (!cancelled) {
          setEmojiLocaleData(normalizeEmojiLocaleData(module.default));
        }
      })
      .catch(() => {
        if (!cancelled) {
          setEmojiLocaleData(null);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [language]);

  useEffect(() => {
    return () => {
      if (emojiCloseTimeoutRef.current) {
        clearTimeout(emojiCloseTimeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      setDebouncedGifQuery(gifQuery.trim());
    }, 500);

    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [gifQuery]);

  useEffect(() => {
    if (!showGifPicker) return undefined;

    if (!giphyApiKey) {
      setGifResults([]);
      setGifError('Add VITE_GIPHY_API_KEY to Frontend/.env.local to enable GIF search.');
      setIsLoadingGifs(false);
      return undefined;
    }

    const controller = new AbortController();

    const loadGifs = async () => {
      setIsLoadingGifs(true);
      setGifError('');

      const endpoint = debouncedGifQuery
        ? `${giphyBaseUrl}/search?api_key=${encodeURIComponent(giphyApiKey)}&q=${encodeURIComponent(debouncedGifQuery)}&limit=20&rating=g`
        : `${giphyBaseUrl}/trending?api_key=${encodeURIComponent(giphyApiKey)}&limit=20&rating=g`;

      try {
        const response = await fetch(endpoint, { signal: controller.signal });
        if (!response.ok) {
          throw new Error('GIPHY request failed');
        }

        const payload = await response.json();
        setGifResults(Array.isArray(payload.data) ? payload.data : []);
      } catch (error) {
        if (controller.signal.aborted) return;
        setGifResults([]);
        setGifError('Unable to load GIFs right now.');
      } finally {
        if (!controller.signal.aborted) {
          setIsLoadingGifs(false);
        }
      }
    };

    loadGifs();

    return () => {
      controller.abort();
    };
  }, [debouncedGifQuery, showGifPicker]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!attachMenuRef.current?.contains(event.target)) {
        setShowAttachMenu(false);
      }

      if (!gifPickerRef.current?.contains(event.target)) {
        setShowGifPicker(false);
      }

      if (reactionMessageId) {
        const activeMessageNode = messageRefs.current.get(reactionMessageId);
        if (!activeMessageNode || !activeMessageNode.contains(event.target)) {
          setReactionMessageId(null);
        }
      }
    };

    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        setShowGifPicker(false);
        setReactionMessageId(null);
      }
    };

    if (showAttachMenu || showGifPicker || reactionMessageId) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [showAttachMenu, showGifPicker, reactionMessageId]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const trimmed = messageText.trim();
    if (!trimmed && pendingAttachments.length === 0) return;

    const currentAttachments = pendingAttachments;
    setIsSending(true);

    try {
      await onSendMessage({
        text: trimmed,
        gifUrl: '',
        attachments: currentAttachments,
      });
      shouldAutoScrollRef.current = true;
      setMessageText('');
      setPendingAttachments([]);
      setAttachmentError('');

    } catch {
      showError('Failed to send message. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  const handleEmojiSelect = (emojiData) => {
    const emoji = emojiData.emoji;
    const input = inputRef.current;

    if (!input) {
      setMessageText((prev) => `${prev}${emoji}`);
      return;
    }

    const start = input.selectionStart ?? messageText.length;
    const end = input.selectionEnd ?? messageText.length;
    const nextValue = `${messageText.slice(0, start)}${emoji}${messageText.slice(end)}`;

    setMessageText(nextValue);

    requestAnimationFrame(() => {
      input.focus();
      const cursorPosition = start + emoji.length;
      input.setSelectionRange(cursorPosition, cursorPosition);
    });
  };

  const openEmojiPicker = () => {
    if (emojiCloseTimeoutRef.current) {
      clearTimeout(emojiCloseTimeoutRef.current);
      emojiCloseTimeoutRef.current = null;
    }

    setShowEmojiPicker(true);
  };

  const scheduleEmojiPickerClose = () => {
    if (emojiCloseTimeoutRef.current) {
      clearTimeout(emojiCloseTimeoutRef.current);
    }

    emojiCloseTimeoutRef.current = setTimeout(() => {
      setShowEmojiPicker(false);
      emojiCloseTimeoutRef.current = null;
    }, 120);
  };

  const validateFiles = (files, expectedKind) => {
    const validators = {
      image: (file) => file.type.startsWith('image/'),
      video: (file) => file.type.startsWith('video/'),
      file: (file) => !file.type.startsWith('image/') && !file.type.startsWith('video/'),
    };

    const invalid = files.find((file) => !validators[expectedKind](file));

    if (invalid) {
      setAttachmentError(
        expectedKind === 'image'
          ? t('dashboard.attachImageOnly')
          : expectedKind === 'video'
            ? t('dashboard.attachVideoOnly')
            : t('dashboard.attachFileOnly')
      );
      return false;
    }

    setAttachmentError('');
    return true;
  };

  const handlePickAttachments = (event, expectedKind) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;
    if (!validateFiles(files, expectedKind)) {
      event.target.value = '';
      return;
    }

    const nextAttachments = files.map((file) => {
      let kind = 'file';
      if (file.type.startsWith('image/')) kind = 'image';
      if (file.type.startsWith('video/')) kind = 'video';

      return {
        id: `${file.name}-${file.size}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: file.name,
        size: file.size,
        type: file.type,
        file,
        kind,
        url: URL.createObjectURL(file),
        fileTypeLabel: file.type || 'File',
        local: true,
      };
    });

    setPendingAttachments((prev) => [...prev, ...nextAttachments]);
    setShowAttachMenu(false);
    event.target.value = '';
  };

  const handleRemoveAttachment = (attachmentId) => {
    setPendingAttachments((prev) => {
      const target = prev.find((attachment) => attachment.id === attachmentId);
      if (target?.url) {
        URL.revokeObjectURL(target.url);
      }

      return prev.filter((attachment) => attachment.id !== attachmentId);
    });
  };

  const openAttachmentViewer = (attachment) => {
    if (!attachment) return;

    if (attachment.kind !== 'file') {
      setViewerAttachment(attachment);
      return;
    }

    if (!isPreviewableFileAttachment(attachment)) {
      handleAttachmentFileAction(attachment, 'download');
      return;
    }

    handleAttachmentFileAction(attachment, 'open');
  };

  const handleAttachmentFileAction = async (attachment, action) => {
    setAttachmentError('');

    if (attachment.local || !attachment.id) {
      if (action === 'download') {
        triggerFileDownload(attachment.url, attachment.name);
        return;
      }

      openAttachmentPreviewTab(attachment.url, attachment.name, attachment.type);
      return;
    }

    try {
      const { file, contentType, fileName } = await downloadAttachment(attachment.id, {
        download: action === 'download',
      });
      const resolvedFileName = fileName || attachment.name || 'attachment';
      const previewFile = file instanceof File
        ? file
        : new File([file], resolvedFileName, {
            type: contentType || 'application/octet-stream',
          });
      const objectUrl = URL.createObjectURL(previewFile);

      if (action === 'download') {
        triggerFileDownload(objectUrl, resolvedFileName);
        window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
        return;
      }

      openAttachmentPreviewTab(objectUrl, resolvedFileName, contentType);
    } catch {
      setAttachmentError('Unable to open or download this attachment right now.');
    }
  };

  const registerMessageRef = (messageId, node) => {
    if (!node) {
      messageRefs.current.delete(messageId);
      return;
    }

    messageRefs.current.set(messageId, node);
  };

  const handleToggleMessageSearch = () => {
    setShowMessageSearch((previous) => {
      const nextValue = !previous;
      if (!nextValue) {
        setSearchQuery('');
        setActiveSearchIndex(0);
      }
      return nextValue;
    });
  };

  const handleGoToSearchResult = (direction) => {
    if (matchedMessageIds.length === 0) return;

    setActiveSearchIndex((previousIndex) => {
      if (direction === 'next') {
        return (previousIndex + 1) % matchedMessageIds.length;
      }

      return (previousIndex - 1 + matchedMessageIds.length) % matchedMessageIds.length;
    });
  };

  const handleSelectGif = async (gif) => {
    const gifUrl =
      gif?.images?.original?.url ||
      gif?.images?.fixed_height?.url ||
      gif?.images?.downsized?.url ||
      '';

    if (!gifUrl) {
      return;
    }

    shouldAutoScrollRef.current = true;
    setShowGifPicker(false);
    setGifQuery('');
    setDebouncedGifQuery('');
    setGifError('');
    setIsSending(true);

    try {
      await onSendMessage({
        text: '',
        gifUrl,
        attachments: [],
      });
    } catch {
      showError('Failed to send message. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  const persistChatDetails = async (nextCustomNameInput, nextNotesInput, target = 'both') => {
    if (!onUpdateChatDetails || isSavingDetails) return;

    const normalizedOriginalName = (chat.originalName || chat.name || '').trim();
    const normalizedCustomName = nextCustomNameInput.trim();
    const normalizedNotes = nextNotesInput.trim();
    const customNamePayload =
      normalizedCustomName.length === 0
        ? ''
        : normalizedCustomName !== normalizedOriginalName
          ? normalizedCustomName
          : null;
    const notesPayload = nextNotesInput.trim().length === 0 ? '' : normalizedNotes;
    const existingCustomName = chat.customName || null;
    const existingNotes = (chat.notes || '').trim() || null;
    const comparableCustomNamePayload = customNamePayload || null;
    const comparableNotesPayload = notesPayload || null;

    if (existingCustomName === comparableCustomNamePayload && existingNotes === comparableNotesPayload) {
      return;
    }

    setIsSavingDetails(true);

    try {
      await onUpdateChatDetails(chat.id, {
        customName: customNamePayload,
        notes: notesPayload,
      });

      if (target === 'name' || target === 'both') {
        setShowNameSaved(true);
        if (nameSavedTimeoutRef.current) {
          clearTimeout(nameSavedTimeoutRef.current);
        }
        nameSavedTimeoutRef.current = setTimeout(() => setShowNameSaved(false), 1800);
        showSuccess('Contact renamed');
      }

      if (target === 'notes' || target === 'both') {
        setShowNotesSaved(true);
        if (notesSavedTimeoutRef.current) {
          clearTimeout(notesSavedTimeoutRef.current);
        }
        notesSavedTimeoutRef.current = setTimeout(() => setShowNotesSaved(false), 1800);
        showSuccess('Notes saved');
      }
    } catch {
      showError('Unable to save contact info right now.');
    } finally {
      setIsSavingDetails(false);
    }
  };

  const handleCustomNameSave = async () => {
    await persistChatDetails(customNameInput, notesInput, 'name');
  };

  const handleCustomNameKeyDown = (event) => {
    if (event.key !== 'Enter') return;

    event.preventDefault();
    handleCustomNameSave();
  };

  const normalizedOriginalName = (chat.originalName || chat.name || '').trim();
  const normalizedCustomName = customNameInput.trim();
  const hasPendingCustomNameChange =
    (chat.customName || null) !==
    (normalizedCustomName && normalizedCustomName !== normalizedOriginalName ? normalizedCustomName : null);
  const hasPendingNotesChange =
    ((chat.notes || '').trim() || null) !== (notesInput.trim() || null);
  const hasPendingDetailsChange = hasPendingCustomNameChange || hasPendingNotesChange;

  return (
    <div className="flex-1 flex overflow-hidden bg-[#F5F6FA] dark:bg-[#181A20]">
      <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
      <div
        className="min-h-[73px] flex items-center justify-between bg-white dark:bg-[#1C1F26] border-b border-[#E5E7EB] dark:border-[#2F3440]"
        style={{
          paddingInline: 'var(--dialogly-density-chat-header-x)',
          paddingBlock: 'var(--dialogly-density-chat-header-y)',
        }}
      >
        <div className="flex items-center gap-3 min-w-0">
          <ChatHeaderAvatar chat={chat} />

          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-[#1A1D23] dark:text-white truncate">{chat.name}</h3>
              <PlatformBadge platform={chat.platform} />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[#6B7280] dark:text-[#9CA3AF]">
          <button
            type="button"
            onClick={handleToggleMessageSearch}
            className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${
              showMessageSearch
                ? 'bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] text-[var(--dialogly-accent)]'
                : 'hover:bg-[#F3F4F6] dark:hover:bg-[#2A2F3A]'
            }`}
            aria-label={t('dashboard.searchInChat')}
          >
            <Search className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setShowDetailsPanel((previous) => !previous)}
            className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${
              showDetailsPanel
                ? 'bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] text-[var(--dialogly-accent)]'
                : 'hover:bg-[#F3F4F6] dark:hover:bg-[#2A2F3A]'
            }`}
            aria-label={t('chatUiExtra.contactInfo')}
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showMessageSearch && (
        <div className="px-5 py-3 bg-white dark:bg-[#1C1F26] border-b border-[#E5E7EB] dark:border-[#2F3440]">
          <div className="flex items-center gap-3 rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] px-3 py-2 shadow-sm">
            <Search className="w-4 h-4 text-[#9CA3AF]" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder={t('dashboard.searchInMessages')}
              className="flex-1 bg-transparent border-none outline-none text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF]"
            />

            <div className="flex items-center gap-2 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
              <span>
                {matchedMessageIds.length > 0 ? activeSearchIndex + 1 : 0}/{matchedMessageIds.length}
              </span>
              <button
                type="button"
                onClick={() => handleGoToSearchResult('prev')}
                disabled={matchedMessageIds.length === 0}
                className="w-8 h-8 rounded-lg hover:bg-white dark:hover:bg-[#2A2F3A] disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
                aria-label={t('dashboard.previousMatch')}
              >
                <ChevronUp className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => handleGoToSearchResult('next')}
                disabled={matchedMessageIds.length === 0}
                className="w-8 h-8 rounded-lg hover:bg-white dark:hover:bg-[#2A2F3A] disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
                aria-label={t('dashboard.nextMatch')}
              >
                <ChevronDown className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleToggleMessageSearch}
                className="w-8 h-8 rounded-lg hover:bg-white dark:hover:bg-[#2A2F3A] flex items-center justify-center transition-colors"
                aria-label={t('dashboard.closeSearch')}
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {searchQuery.trim() && matchedMessageIds.length === 0 && (
            <p className="mt-2 text-sm text-[#9CA3AF]">{t('dashboard.noMessageMatches')}</p>
          )}
        </div>
      )}

      <div ref={tourChatWindowRef} className="relative flex-1 min-h-0">
        <div
          ref={scrollContainerRef}
          className="h-full overflow-y-auto overflow-x-hidden"
          style={{
            paddingInline: 'var(--dialogly-density-chat-body-x)',
            paddingBlock: 'var(--dialogly-density-chat-body-y)',
          }}
        >
          <div className="flex justify-center mb-6">
            <div className="px-4 py-1.5 rounded-full bg-white dark:bg-[#23262F] border border-[#E5E7EB] dark:border-[#343842] text-xs text-[#9CA3AF] shadow-sm">
              {groupedLabel}
            </div>
          </div>

          <div className="flex flex-col gap-2 pt-10">
            {isLoadingMessages
              ? Array.from({ length: 8 }).map((_, index) => (
                  <MessageSkeleton key={index} isOutgoing={index % 2 === 1} />
                ))
              : messageLoadError ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center px-6">
                    <AlertCircle className="h-8 w-8 text-red-400" />
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">{t('chatUiExtra.failedToLoadMessages')}</p>
                    <button
                      type="button"
                      onClick={onRetryMessages}
                      className="mt-2 text-sm text-[var(--dialogly-accent)] underline underline-offset-2"
                    >
                      {t('miscUi.tryAgain')}
                    </button>
                  </div>
                )
              : messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center px-6">
                    <EmptyMessagesIllustration />
                    <h3 className="mt-4 font-semibold text-[#374151] dark:text-[#E5E7EB]">{t('chatUiExtra.noMessagesYet')}</h3>
                    <p className="mt-1 text-sm text-[#9CA3AF]">{t('chatUiExtra.sendFirstMessage')}</p>
                  </div>
                )
              : messages.map((message) => (
                  <MessageBubble
                    key={message.id}
                    message={message}
                    onToggleReaction={onToggleReaction}
                    onOpenAttachment={openAttachmentViewer}
                    registerMessageRef={registerMessageRef}
                    isSearchMatch={matchedMessageIds.includes(message.id)}
                    isActiveSearchMatch={activeMatchedMessageId === message.id}
                    onMediaLoad={handleMediaLoadScroll}
                    reactionMessageId={reactionMessageId}
                    setReactionMessageId={setReactionMessageId}
                  />
                ))}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {showScrollToBottom && (
          <button
            type="button"
            onClick={() => scrollToBottom('smooth')}
            className="absolute bottom-5 right-5 z-20 w-11 h-11 rounded-full bg-white dark:bg-[#20242E] border border-[#E5E7EB] dark:border-[#343842] shadow-lg flex items-center justify-center text-[#6B7280] dark:text-[#D1D5DB] hover:text-[var(--dialogly-accent)] hover:border-[var(--dialogly-accent-border)] dark:hover:border-[var(--dialogly-accent-border-dark)] transition-colors"
            aria-label={t('dashboard.scrollToLatest')}
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        )}
      </div>

      <div
        ref={tourComposerRef}
        className="bg-white dark:bg-[#1C1F26] border-t border-[#E5E7EB] dark:border-[#2F3440]"
        style={{ padding: 'var(--dialogly-density-composer-padding)' }}
      >
        <form
          onSubmit={handleSubmit}
          style={{
            paddingInline: 'var(--dialogly-density-composer-inner-x)',
            paddingBlock: 'var(--dialogly-density-composer-inner-y)',
          }}
          className="flex items-center gap-3 rounded-2xl border border-[var(--dialogly-accent-border)] dark:border-[var(--dialogly-accent-border-dark)] bg-white dark:bg-[#20242E] px-4 py-3 shadow-sm"
        >
          <input
            ref={imageInputRef}
            type="file"
            multiple
            accept="image/*,.jpg,.jpeg,.png,.webp,.gif"
            className="hidden"
            onChange={(event) => handlePickAttachments(event, 'image')}
          />
          <input
            ref={videoInputRef}
            type="file"
            multiple
            accept="video/*"
            className="hidden"
            onChange={(event) => handlePickAttachments(event, 'video')}
          />
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar,.csv"
            className="hidden"
            onChange={(event) => handlePickAttachments(event, 'file')}
          />
          <div className="relative" ref={attachMenuRef}>
            <button
              type="button"
              onClick={() => setShowAttachMenu((prev) => !prev)}
              className="flex h-9 w-9 items-center justify-center rounded-lg text-[#9CA3AF] transition-colors hover:bg-[#F3F4F6] hover:text-[var(--dialogly-accent)] dark:hover:bg-[#2A2F3A]"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            {showAttachMenu && (
              <div className="absolute bottom-12 left-0 w-48 rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] shadow-xl p-2 z-20">
                <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#1A1D23] dark:text-white hover:bg-[#F5F6FA] dark:hover:bg-[#2A2F3A]"
                >
                  <ImageIcon className="w-4 h-4" />
                  {t('dashboard.addPhoto')}
                </button>
                <button
                  type="button"
                  onClick={() => videoInputRef.current?.click()}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#1A1D23] dark:text-white hover:bg-[#F5F6FA] dark:hover:bg-[#2A2F3A]"
                >
                  <Film className="w-4 h-4" />
                  {t('dashboard.addVideo')}
                </button>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#1A1D23] dark:text-white hover:bg-[#F5F6FA] dark:hover:bg-[#2A2F3A]"
                >
                  <FileText className="w-4 h-4" />
                  {t('dashboard.addFile')}
                </button>
              </div>
            )}
          </div>

          <input
            ref={inputRef}
            type="text"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            placeholder={`${t('dashboard.message')} ${chat.name}`}
            disabled={isSending}
            className="flex-1 bg-transparent border-none outline-none text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF]"
          />

          <div
            className="relative"
            ref={emojiPickerRef}
            onMouseEnter={openEmojiPicker}
            onMouseLeave={scheduleEmojiPickerClose}
          >
            <button
              type="button"
              onFocus={openEmojiPicker}
              className="flex h-9 w-9 items-center justify-center rounded-lg text-[#9CA3AF] transition-colors hover:bg-[#F3F4F6] hover:text-[var(--dialogly-accent)] dark:hover:bg-[#2A2F3A]"
            >
              <Smile className="w-5 h-5" />
            </button>

            {showEmojiPicker && (
              <div className="absolute bottom-12 right-0 rounded-2xl overflow-hidden border border-[#E5E7EB] dark:border-[#343842] shadow-xl z-20">
                <EmojiPicker
                  onEmojiClick={handleEmojiSelect}
                  width={360}
                  height={420}
                  emojiData={emojiLocaleData ?? undefined}
                  categories={getEmojiCategories(t)}
                  previewConfig={{ showPreview: false }}
                  searchDisabled={false}
                  searchPlaceholder={t('dashboard.searchEmoji')}
                  searchClearButtonLabel={t('dashboard.clearEmojiSearch')}
                  skinTonesDisabled={false}
                  lazyLoadEmojis
                  theme="auto"
                />
              </div>
            )}
          </div>

          <div className="relative" ref={gifPickerRef}>
            <button
              type="button"
              onClick={() => setShowGifPicker((previous) => !previous)}
              className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${
                showGifPicker
                  ? 'bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] text-[var(--dialogly-accent)]'
                  : 'text-[#9CA3AF] hover:text-[var(--dialogly-accent)] hover:bg-[#F3F4F6] dark:hover:bg-[#2A2F3A]'
              }`}
              aria-label={t('dashboard.openGifPicker')}
            >
              <span className="text-[11px] font-medium tracking-[0.08em]">GIF</span>
            </button>

            {showGifPicker && (
              <div className="absolute bottom-12 right-0 w-[320px] max-w-[80vw] rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] shadow-xl p-3 z-20">
                <div className="flex items-center gap-2 rounded-xl border border-[#E5E7EB] dark:border-[#343842] px-3 py-2 bg-[#F9FAFB] dark:bg-[#1C1F26]">
                  <ImagePlay className="w-4 h-4 text-[#9CA3AF]" />
                  <input
                    type="text"
                    value={gifQuery}
                    onChange={(event) => setGifQuery(event.target.value)}
                    placeholder={t('dashboard.searchEmoji')}
                    className="flex-1 bg-transparent border-none outline-none text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF]"
                  />
                </div>

                {!giphyApiKey && (
                  <p className="mt-3 text-xs text-[#F59E0B]">
                    Add <code>VITE_GIPHY_API_KEY=your_key_here</code> to <code>Frontend/.env.local</code>.
                  </p>
                )}

                {gifError && <p className="mt-3 text-xs text-[#EF4444]">{gifError}</p>}

                <div className="mt-3 max-h-72 overflow-y-auto">
                  {isLoadingGifs ? (
                    <div className="py-8 text-center text-sm text-[#9CA3AF]">{t('chatUiExtra.loadingGifs')}</div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      {gifResults.map((gif) => {
                        const previewUrl = gif?.images?.fixed_height?.url || gif?.images?.original?.url;
                        const title = gif?.title || 'GIF';

                        if (!previewUrl) return null;

                        return (
                          <button
                            key={gif.id}
                            type="button"
                            onClick={() => handleSelectGif(gif)}
                            className="overflow-hidden rounded-xl border border-[#E5E7EB] dark:border-[#343842] hover:border-[var(--dialogly-accent-border)] transition-colors bg-[#F9FAFB] dark:bg-[#1C1F26]"
                          >
                            <img
                              src={previewUrl}
                              alt={title}
                              loading="lazy"
                              className="w-full h-28 object-cover"
                            />
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={isSending}
            className="w-10 h-10 rounded-full bg-[var(--dialogly-accent-soft)] hover:bg-[var(--dialogly-accent-soft-hover)] dark:bg-[var(--dialogly-accent-soft-dark)] dark:hover:bg-[var(--dialogly-accent-soft-dark-hover)] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
          >
            {isSending ? (
              <Loader2 className="w-4 h-4 animate-spin text-[var(--dialogly-accent)]" />
            ) : (
              <Send className="w-4 h-4 text-[var(--dialogly-accent)]" />
            )}
          </button>
        </form>

        {isSending && pendingAttachments.length > 0 && (
          <div className="mt-3 flex items-center gap-2 px-3 py-1 text-sm text-gray-500 dark:text-gray-400">
            <Loader2 className="h-3 w-3 animate-spin" />
            <span>{t('chatUiExtra.uploadingFile')}</span>
          </div>
        )}

        {pendingAttachments.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-3">
            {pendingAttachments.map((attachment) => (
              <div
                key={attachment.id}
                className="relative rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] p-2"
              >
                <button
                  type="button"
                  onClick={() => handleRemoveAttachment(attachment.id)}
                  className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white dark:bg-[#20242E] border border-[#E5E7EB] dark:border-[#343842] shadow-sm flex items-center justify-center text-[#6B7280] dark:text-[#9CA3AF]"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
                <AttachmentPreview attachment={attachment} compact onOpen={openAttachmentViewer} />
              </div>
            ))}
          </div>
        )}

        {attachmentError && (
          <p className="mt-3 text-sm text-[#EF4444]">{attachmentError}</p>
        )}
      </div>
      </div>

      {showDetailsPanel && (
        <aside className="w-[280px] flex-shrink-0 bg-white dark:bg-[#1C1F26] border-l border-[#E5E7EB] dark:border-[#2F3440] flex flex-col">
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E7EB] dark:border-[#2F3440]">
            <h4 className="text-sm text-[#1A1D23] dark:text-white">{t('chatUiExtra.contactInfo')}</h4>
            <button
              type="button"
              onClick={() => setShowDetailsPanel(false)}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F3F4F6] dark:hover:bg-[#2A2F3A] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-5 py-5 space-y-5">
            {isLoadingChatDetails ? (
              <ContactDetailsSkeleton />
            ) : (
              <>
                <div>
                  <div className="flex items-center justify-between gap-3 mb-2">
                    <label className="block text-xs uppercase tracking-[0.08em] text-[#9CA3AF]">{t('chatUiExtra.contactName')}</label>
                    <div className="flex items-center gap-2">
                      {showNameSaved && (
                        <span className="text-xs text-[#10B981] transition-opacity">{t('chatUiExtra.saved')}</span>
                      )}
                    </div>
                  </div>
                  <input
                    type="text"
                    value={customNameInput}
                    onChange={(event) => setCustomNameInput(event.target.value)}
                    onKeyDown={handleCustomNameKeyDown}
                    className="w-full rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] px-3 py-2.5 text-sm text-[#1A1D23] dark:text-white outline-none focus:border-[var(--dialogly-accent)]"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between gap-3 mb-2">
                    <label className="block text-xs uppercase tracking-[0.08em] text-[#9CA3AF]">{t('chatUiExtra.notes')}</label>
                    {showNotesSaved && (
                      <span className="text-xs text-[#10B981] transition-opacity">{t('chatUiExtra.saved')}</span>
                    )}
                  </div>
                  <textarea
                    value={notesInput}
                    onChange={(event) => setNotesInput(event.target.value)}
                    placeholder={t('chatUiExtra.notes')}
                    rows={8}
                    className="w-full rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] px-3 py-2.5 text-sm text-[#1A1D23] dark:text-white outline-none focus:border-[var(--dialogly-accent)] resize-none"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleCustomNameSave}
                  disabled={!hasPendingDetailsChange || isSavingDetails}
                  className={`w-full min-w-[120px] rounded-xl px-4 py-2.5 text-sm transition-colors ${
                    !hasPendingDetailsChange || isSavingDetails
                      ? 'bg-[#E5E7EB] dark:bg-[#343842] text-[#9CA3AF] cursor-not-allowed'
                      : 'bg-[var(--dialogly-accent)] text-white hover:bg-[var(--dialogly-accent-hover)]'
                  }`}
                >
                  {isSavingDetails ? (
                    <span className="inline-flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>{t('common.saving')}</span>
                    </span>
                  ) : t('common.saveChanges')}
                </button>
              </>
            )}
          </div>
        </aside>
      )}

      {viewerAttachment && (
        <div
          className="fixed inset-0 z-40 bg-black/70 flex items-center justify-center p-6"
          onClick={() => setViewerAttachment(null)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh]"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setViewerAttachment(null)}
              className="absolute -top-3 -right-3 w-10 h-10 rounded-full bg-white dark:bg-[#20242E] text-[#1A1D23] dark:text-white shadow-lg flex items-center justify-center"
            >
              <X className="w-5 h-5" />
            </button>

            {viewerAttachment.kind === 'image' ? (
              <img
                src={viewerAttachment.url}
                alt={viewerAttachment.name}
                className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl"
              />
            ) : viewerAttachment.kind === 'video' ? (
              <video
                src={viewerAttachment.url}
                controls
                autoPlay
                className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl bg-black"
              />
            ) : (
              <div className="w-[min(96vw,72rem)] rounded-2xl bg-white dark:bg-[#20242E] border border-[#E5E7EB] dark:border-[#343842] shadow-2xl overflow-hidden">
                <div className="flex items-center justify-between gap-4 border-b border-[#E5E7EB] px-5 py-4 dark:border-[#343842]">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-[#1A1D23] dark:text-white">
                      {viewerAttachment.name}
                    </p>
                    <p className="mt-1 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                      {t('dashboard.fileType')}: {viewerAttachment.fileTypeLabel} · {t('dashboard.fileSize')}: {formatFileSize(viewerAttachment.size)}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    {viewerAttachment.previewUrl ? (
                      <a
                        href={viewerAttachment.previewUrl}
                        download={viewerAttachment.name}
                        className="inline-flex items-center justify-center rounded-xl bg-[var(--dialogly-accent)] px-4 py-2.5 text-sm text-white transition-colors hover:bg-[var(--dialogly-accent-hover)]"
                      >
                        {t('dashboard.downloadFile')}
                      </a>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleAttachmentFileAction(viewerAttachment, 'download')}
                        className="inline-flex items-center justify-center rounded-xl bg-[var(--dialogly-accent)] px-4 py-2.5 text-sm text-white transition-colors hover:bg-[var(--dialogly-accent-hover)]"
                      >
                        {t('dashboard.downloadFile')}
                      </button>
                    )}

                    {!isPdfAttachment(viewerAttachment) && (
                      <button
                        type="button"
                        onClick={() => handleAttachmentFileAction(viewerAttachment, 'open')}
                        className="inline-flex items-center justify-center rounded-xl border border-[#E5E7EB] px-4 py-2.5 text-sm text-[#374151] transition-colors hover:bg-[#F9FAFB] dark:border-[#343842] dark:text-[#D1D5DB] dark:hover:bg-[#2A2F3A]"
                      >
                        {t('dashboard.openFile')}
                      </button>
                    )}
                  </div>
                </div>

                {isPdfAttachment(viewerAttachment) ? (
                  <div className="h-[min(80vh,56rem)] bg-[#111827]">
                    {viewerAttachment.previewLoading ? (
                      <div className="flex h-full items-center justify-center text-sm text-white">
                        <span className="inline-flex items-center gap-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Loading preview...
                        </span>
                      </div>
                    ) : viewerAttachment.previewError ? (
                      <div className="flex h-full items-center justify-center px-6 text-center text-sm text-[#D1D5DB]">
                        {viewerAttachment.previewError}
                      </div>
                    ) : viewerAttachment.previewUrl ? (
                      <iframe
                        src={viewerAttachment.previewUrl}
                        title={viewerAttachment.name}
                        className="h-full w-full bg-white"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center px-6 text-center text-sm text-[#D1D5DB]">
                        Preview is not available for this file.
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 rounded-2xl bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] flex items-center justify-center text-[var(--dialogly-accent)] flex-shrink-0">
                        <FileText className="w-7 h-7" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-base text-[#1A1D23] dark:text-white break-words">
                          {viewerAttachment.name}
                        </p>
                        <p className="mt-2 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                          Preview is not available for this file type. Use Open or Download.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default ChatArea;
