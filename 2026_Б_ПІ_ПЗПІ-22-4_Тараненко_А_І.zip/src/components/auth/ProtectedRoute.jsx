import { Navigate, useLocation } from 'react-router-dom';

import { useAuth } from '../../context/AuthContext';
import { useAccountContext } from '../../context/AccountContext';
import { useAppLanguage } from '../../context/AppLanguageContext';

function ProtectedRoute({
  children,
  requireCompletedOnboarding = false,
  requireIncompleteOnboarding = false,
  allowDuringOnboarding = false,
}) {
  const { isAuthenticated, isAuthLoading, user } = useAuth();
  const { isAccountBootstrapLoading } = useAccountContext();
  const { t } = useAppLanguage();
  const location = useLocation();
  const isOnboardingCompleted = Boolean(user?.isOnboardingCompleted);

  if (isAuthLoading || isAccountBootstrapLoading) {
    return (
      <div className="min-h-screen bg-[#F5F6FA] dark:bg-[#181A20] flex items-center justify-center px-4">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="w-10 h-10 rounded-full border-4 border-[#EEF0FE] border-t-[#5B6CF8] animate-spin" />
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">{t('miscUi.loadingWorkspace')}</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (requireCompletedOnboarding && !isOnboardingCompleted) {
    return <Navigate to="/post-login" replace />;
  }

  if (requireIncompleteOnboarding && isOnboardingCompleted) {
    return <Navigate to="/chats" replace />;
  }

  if (!allowDuringOnboarding && !requireCompletedOnboarding && !requireIncompleteOnboarding && !isOnboardingCompleted) {
    return <Navigate to="/post-login" replace />;
  }

  return children;
}

export default ProtectedRoute;
