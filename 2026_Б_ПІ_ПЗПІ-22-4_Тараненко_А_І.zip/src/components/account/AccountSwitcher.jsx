import { useMemo, useState } from 'react';
import { Check, ChevronDown, User, Building2, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { useAccountContext } from '../../context/AccountContext';
import { useAppLanguage } from '../../context/AppLanguageContext';

function AccountSwitcher({ compact = false, align = 'right' }) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const { contexts, activeContext, switchContext } = useAccountContext();
  const { t } = useAppLanguage();

  const activeLabel = useMemo(() => {
    if (!activeContext) return t('accountSwitcher.selectAccount');
    return activeContext.type === 'personal'
      ? t('settingsUi.personalAccount')
      : activeContext.workspace?.name || activeContext.label;
  }, [activeContext, t]);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className={`inline-flex items-center gap-2 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors ${
          compact ? 'px-3 py-2 text-xs' : 'px-3.5 py-2.5 text-sm'
        }`}
      >
        {activeContext?.type === 'personal' ? (
          <User className="w-4 h-4 text-[var(--dialogly-accent)]" />
        ) : (
          <Building2 className="w-4 h-4 text-[var(--dialogly-accent)]" />
        )}
        <span className="truncate max-w-[180px]">{activeLabel}</span>
        <ChevronDown className={`w-4 h-4 text-[#9CA3AF] transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <>
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-10 cursor-default"
          />

          <div
            className={`absolute z-20 mt-2 w-72 rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#1C1F26] shadow-xl shadow-black/[0.08] overflow-hidden ${
              align === 'left' ? 'left-0' : 'right-0'
            }`}
          >
            <div className="px-4 py-3 border-b border-[#EEF2F7] dark:border-[#2F3440]">
              <p className="text-sm text-[#111827] dark:text-white">{t('accountSwitcher.accounts')}</p>
              <p className="text-xs text-[#9CA3AF] mt-0.5">
                {t('accountSwitcher.description')}
              </p>
            </div>

            <div className="p-2 space-y-1">
              {contexts.map((context) => {
                const isActive = context.id === activeContext?.id;
                const label =
                  context.type === 'personal'
                    ? t('settingsUi.personalAccount')
                    : context.workspace?.name || context.label;
                const Icon = context.type === 'personal' ? User : Building2;

                return (
                  <button
                    key={context.id}
                    type="button"
                    onClick={() => {
                      switchContext(context.id);
                      setOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ${
                      isActive
                        ? 'bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)]'
                        : 'hover:bg-[#F9FAFB] dark:hover:bg-[#232833]'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#EEF2FF] dark:bg-[#232842] text-[var(--dialogly-accent)] flex items-center justify-center flex-shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-[#111827] dark:text-white truncate">{label}</p>
                      <p className="text-xs text-[#9CA3AF] truncate">
                        {context.type === 'personal'
                          ? t('accountSwitcher.personalIntegrations')
                          : t('accountSwitcher.workspaceAccess', { role: context.role })}
                      </p>
                    </div>
                    {isActive && <Check className="w-4 h-4 text-[var(--dialogly-accent)] flex-shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="p-2 border-t border-[#EEF2F7] dark:border-[#2F3440]">
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  navigate('/add-account');
                }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors"
              >
                <div className="w-9 h-9 rounded-xl bg-[#F3F4F6] dark:bg-[#232833] text-[var(--dialogly-accent)] flex items-center justify-center flex-shrink-0">
                  <Plus className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm text-[#111827] dark:text-white">{t('accountSwitcher.addAnotherAccount')}</p>
                  <p className="text-xs text-[#9CA3AF]">
                    {t('accountSwitcher.addAnotherAccountDescription')}
                  </p>
                </div>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default AccountSwitcher;
