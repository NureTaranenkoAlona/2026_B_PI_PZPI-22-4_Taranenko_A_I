import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Loader2, MessageCircle, Send, X } from 'lucide-react';
import { useAppLanguage } from '../../context/AppLanguageContext';

function platformTitle(platformId) {
  if (platformId === 'telegram') return 'Telegram';
  if (platformId === 'messenger') return 'Messenger';
  return 'Platform';
}

function platformIcon(platformId) {
  return platformId === 'telegram' ? Send : MessageCircle;
}

function getInitialForm(platformId, initialValues) {
  if (platformId === 'telegram') {
    return {
      botToken: initialValues.botToken || '',
    };
  }

  if (platformId === 'messenger') {
    return {
      pageId: initialValues.pageId || '',
      pageName: initialValues.pageName || '',
      pageAccessToken: initialValues.pageAccessToken || '',
    };
  }

  return {
    accessToken: initialValues.accessToken || '',
    displayName: initialValues.displayName || '',
  };
}

function validate(platformId, form) {
  const nextErrors = {};

  if (platformId === 'telegram') {
    if (!form.botToken.trim()) nextErrors.botToken = 'validation.botTokenRequired';
  } else if (platformId === 'messenger') {
    if (!form.pageId.trim()) nextErrors.pageId = 'validation.pageIdRequired';
    if (!form.pageName.trim()) nextErrors.pageName = 'validation.pageNameRequired';
    if (!form.pageAccessToken.trim()) nextErrors.pageAccessToken = 'validation.pageAccessTokenRequired';
  } else {
    if (!form.displayName.trim()) nextErrors.displayName = 'validation.displayNameRequired';
  }

  return nextErrors;
}

function Field({ label, error, children }) {
  return (
    <div>
      <label className="block text-sm text-[#374151] dark:text-[#D1D5DB] mb-1.5">{label}</label>
      {children}
      {error && <p className="mt-1.5 text-xs text-[#EF4444]">{error}</p>}
    </div>
  );
}

function TextInput(props) {
  return (
    <input
      {...props}
      className="w-full px-4 py-3 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#232833] text-sm text-[#111827] dark:text-white placeholder:text-[#9CA3AF] focus:outline-none focus:border-[var(--dialogly-accent)] focus:ring-2 focus:ring-[var(--dialogly-accent-soft)] transition-all"
    />
  );
}

function ConnectPlatformModal({
  isOpen,
  mode = 'connect',
  integration,
  workspaceName,
  initialValues = {},
  isSubmitting = false,
  onClose,
  onSubmit,
}) {
  const { t } = useAppLanguage();
  const [form, setForm] = useState(() => getInitialForm(integration?.id, initialValues));
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (!isOpen) return;
    setForm(getInitialForm(integration?.id, initialValues));
    setErrors({});
  }, [integration?.id, initialValues, isOpen]);

  const title = useMemo(() => platformTitle(integration?.id), [integration?.id]);
  const Icon = useMemo(() => platformIcon(integration?.id), [integration?.id]);
  const resolveError = (error) => (error?.startsWith('validation.') ? t(error) : error);

  if (!isOpen || !integration) return null;

  const handleChange = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const validation = validate(integration.id, form);
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }

    onSubmit(form);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#0F1117]/45 backdrop-blur-sm" onClick={isSubmitting ? undefined : onClose} />

      <div className="relative z-10 w-full max-w-[520px] rounded-3xl border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] shadow-2xl shadow-black/10 overflow-hidden">
        <div className="px-6 py-5 border-b border-[#EEF2F7] dark:border-[#2F3440] flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#EEF2FF] dark:bg-[#232842] text-[#4F46E5] flex items-center justify-center">
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm text-[#111827] dark:text-white">
                {mode === 'reconnect'
                  ? t('integrationsUi.reconnectPlatform', { platform: title })
                  : t('integrationsUi.connectPlatform', { platform: title })}
              </p>
              <p className="text-xs text-[#9CA3AF] mt-0.5">
                {workspaceName
                  ? t('integrationsUi.connectionBelongsTo', { name: workspaceName })
                  : t('integrationsUi.connectionBelongsToWorkspace')}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="text-[#9CA3AF] hover:text-[#6B7280] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-6 space-y-4">
          {integration.id === 'telegram' && (
            <>
              <Field label={t('integrationsUi.botToken')} error={resolveError(errors.botToken)}>
                <TextInput
                  value={form.botToken}
                  onChange={(event) => handleChange('botToken', event.target.value)}
                  placeholder="123456:ABC-DEF..."
                  disabled={isSubmitting}
                />
              </Field>
              <p className="text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                {t('integrationsUi.telegramConnectHelpPrefix')} <span className="text-[#111827] dark:text-white">@BotFather</span>{' '}
                {t('integrationsUi.telegramConnectHelpSuffix')}
              </p>
            </>
          )}

          {integration.id === 'messenger' && (
            <>
              <Field label={t('integrationsUi.pageId')} error={resolveError(errors.pageId)}>
                <TextInput
                  value={form.pageId}
                  onChange={(event) => handleChange('pageId', event.target.value)}
                  placeholder="123456789012345"
                  disabled={isSubmitting}
                />
              </Field>
              <Field label={t('integrationsUi.pageName')} error={resolveError(errors.pageName)}>
                <TextInput
                  value={form.pageName}
                  onChange={(event) => handleChange('pageName', event.target.value)}
                  placeholder="Dialogly Support Page"
                  disabled={isSubmitting}
                />
              </Field>
              <Field label={t('integrationsUi.pageAccessToken')} error={resolveError(errors.pageAccessToken)}>
                <TextInput
                  value={form.pageAccessToken}
                  onChange={(event) => handleChange('pageAccessToken', event.target.value)}
                  placeholder="EAABsbCS1..."
                  disabled={isSubmitting}
                />
              </Field>
              <p className="text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                {t('integrationsUi.messengerConnectHelp')}
              </p>
            </>
          )}

          {integration.id !== 'telegram' && integration.id !== 'messenger' && (
            <>
              <Field label={t('integrationsUi.accessToken')} error={resolveError(errors.accessToken)}>
                <TextInput
                  value={form.accessToken}
                  onChange={(event) => handleChange('accessToken', event.target.value)}
                  placeholder={t('integrationsUi.accessTokenPlaceholder')}
                  disabled={isSubmitting}
                />
              </Field>
              <Field label={t('integrationsUi.displayName')} error={resolveError(errors.displayName)}>
                <TextInput
                  value={form.displayName}
                  onChange={(event) => handleChange('displayName', event.target.value)}
                  placeholder={t('integrationsUi.corporateAccountPlaceholder', { platform: title })}
                  disabled={isSubmitting}
                />
              </Field>
            </>
          )}

          <div className="rounded-2xl border border-[#D9E3FF] dark:border-[#2E3A59] bg-[#F8FAFF] dark:bg-[#1D2635] p-4">
            <p className="text-sm text-[#111827] dark:text-white">{t('integrationsUi.workspaceOwnedIntegration')}</p>
            <p className="mt-1 text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
              Connected accounts are shared across the company. Outgoing messages are sent on
              behalf of the corporate account rather than an individual user profile.
            </p>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-sm text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--dialogly-accent)] text-white text-sm hover:bg-[var(--dialogly-accent-hover)] transition-colors"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  Connect
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ConnectPlatformModal;
