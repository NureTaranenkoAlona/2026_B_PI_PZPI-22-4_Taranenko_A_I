import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Building2,
  Users,
  User,
  ArrowRight,
  ArrowLeft,
  X,
  Hash,
  CheckCircle2,
  Sparkles,
  Globe,
} from 'lucide-react';
import { createWorkspace, joinWorkspace } from '../../api/workspaceApi';
import { useAccountContext } from '../../context/AccountContext';
import { useAuth } from '../../context/AuthContext';
import { useAppLanguage } from '../../context/AppLanguageContext';
import AppLogo from '../common/AppLogo';
import getApiErrorMessage from '../../utils/getApiErrorMessage';

function BackgroundBlobs() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <div
        className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-[0.07]"
        style={{
          background: 'radial-gradient(circle, #5B6CF8, transparent 70%)',
        }}
      />
      <div
        className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full opacity-[0.05]"
        style={{
          background: 'radial-gradient(circle, #8B5CF6, transparent 70%)',
        }}
      />
    </div>
  );
}

function WorkspaceModal({
  allowSkip = true,
  closeTo = null,
}) {
  const { completeUserOnboarding, refreshCurrentUser, saveOnboardingChoice } = useAuth();
  const { refreshContexts } = useAccountContext();
  const { t } = useAppLanguage();
  const [step, setStep] = useState('choice');
  const [inviteCode, setInviteCode] = useState('');
  const [workspaceName, setWorkspaceName] = useState('');
  const [industry, setIndustry] = useState('Technology');
  const [codeError, setCodeError] = useState('');
  const [createError, setCreateError] = useState('');
  const [choiceError, setChoiceError] = useState('');
  const [skipError, setSkipError] = useState('');
  const [isSkipping, setIsSkipping] = useState(false);
  const [isSavingChoice, setIsSavingChoice] = useState(false);
  const navigate = useNavigate();

  const finishNavigation = () => {
    navigate(closeTo || '/chats', { replace: true });
  };

  const handleClose = () => {
    if (closeTo) {
      navigate(closeTo);
      return;
    }

    void handleSkip();
  };

  const handleSkip = async () => {
    if (!allowSkip || isSkipping) {
      return;
    }

    setIsSkipping(true);
    setSkipError('');
    setChoiceError('');

    try {
      await completeUserOnboarding('skipped');
      await refreshContexts();
      finishNavigation();
    } catch (error) {
      const message = getApiErrorMessage(
        error,
        'Unable to save your onboarding choice. Please try again.'
      );
      setSkipError(message);
      setChoiceError(message);
    } finally {
      setIsSkipping(false);
    }
  };

  const handleJoin = () => {
    if (inviteCode.trim().length < 4) {
      setCodeError('Please enter a valid invite code.');
      return;
    }

    const submitJoin = async () => {
      setCodeError('');
      setChoiceError('');
      setIsSavingChoice(true);
      setStep('joining');

      try {
        const joinedWorkspace = await joinWorkspace(inviteCode.trim());
        await refreshCurrentUser();
        await refreshContexts();
        setStep('done');

        window.setTimeout(() => {
          if (closeTo) {
            finishNavigation();
            return;
          }

          navigate('/onboarding', {
            replace: true,
            state: {
              workspaceChoice: 'joined',
              joinedRole: joinedWorkspace?.role || 'Member',
              workspaceName: joinedWorkspace?.name || 'Workspace',
              workspaceId: joinedWorkspace?.id || null,
            },
          });
        }, 800);
      } catch (error) {
        setStep('join');
        setChoiceError(
          getApiErrorMessage(error, 'Unable to join this workspace right now.')
        );
      } finally {
        setIsSavingChoice(false);
      }
    };

    submitJoin();
  };

  const handlePersonal = () => {
    const submitPersonal = async () => {
      setChoiceError('');
      setSkipError('');
      setIsSavingChoice(true);
      setStep('personal');

      try {
        await saveOnboardingChoice('personal');
        await refreshContexts();
        setStep('done');

        window.setTimeout(() => {
          navigate('/onboarding', {
            replace: true,
            state: {
              workspaceChoice: 'personal',
            },
          });
        }, 800);
      } catch (error) {
        setStep('choice');
        setChoiceError(
          getApiErrorMessage(error, 'Unable to set up your personal account right now.')
        );
      } finally {
        setIsSavingChoice(false);
      }
    };

    submitPersonal();
  };

  const handleCreate = () => {
    if (!workspaceName.trim()) return;

    const submitCreate = async () => {
      setCreateError('');
      setChoiceError('');
      setIsSavingChoice(true);
      setStep('creating');

      try {
        const createdWorkspace = await createWorkspace({
          name: workspaceName.trim(),
          industry,
          website: '',
          description: '',
        });

        await refreshCurrentUser();
        await refreshContexts();
        setStep('done');

        window.setTimeout(() => {
          if (closeTo) {
            finishNavigation();
            return;
          }

          navigate('/onboarding', {
            replace: true,
            state: {
              workspaceChoice: 'created',
              workspaceName: createdWorkspace?.name || workspaceName.trim(),
              workspaceId: createdWorkspace?.id || null,
            },
          });
        }, 800);
      } catch (error) {
        setStep('create');
        setCreateError(
          getApiErrorMessage(error, 'Unable to create your workspace right now.')
        );
      } finally {
        setIsSavingChoice(false);
      }
    };

    submitCreate();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-[#0F1117]/40 backdrop-blur-sm"
        onClick={allowSkip ? () => void handleSkip() : undefined}
      />

      <div className="relative z-10 w-full max-w-[520px] bg-white dark:bg-[#1C1F26] rounded-3xl shadow-2xl shadow-black/10 overflow-hidden">
        <BackgroundBlobs />

        {step === 'choice' && (
          <div className="relative p-8">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2">
                <AppLogo size={32} />
                <span className="text-sm text-[#1A1D23] dark:text-white">Dialogly</span>
              </div>

              {allowSkip ? (
                <button
                  onClick={() => void handleSkip()}
                  disabled={isSkipping}
                  className="text-xs text-[#9CA3AF] hover:text-[#6B7280] transition-colors flex items-center gap-1 group"
                >
                  <X className="w-3 h-3 group-hover:rotate-90 transition-transform" />
                  {isSkipping ? t('common.saving') : t('onboardingWorkspace.skipForNow')}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleClose}
                  className="text-[#9CA3AF] hover:text-[#6B7280] transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="mb-8 text-center">
              <div className="w-14 h-14 bg-gradient-to-br from-[#EEF0FE] to-[#E0E3FD] rounded-2xl flex items-center justify-center mx-auto mb-5">
                <Building2 className="w-7 h-7 text-[#5B6CF8]" />
              </div>
              <h2 className="text-[#1A1D23] dark:text-white mb-2">{t('onboardingWorkspace.setupWorkspaceTitle')}</h2>
              <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] max-w-sm mx-auto leading-relaxed">
                {t('onboardingWorkspace.setupWorkspaceDescription')}
              </p>
            </div>

            {choiceError && (
              <p className="text-center text-sm text-[#EF4444] mb-4">{choiceError}</p>
            )}

            <div className="space-y-3 mb-6">
              <button
                onClick={handlePersonal}
                disabled={isSavingChoice}
                className="w-full group flex items-center gap-4 p-5 bg-white dark:bg-[#1E2430] border-2 border-[#DDE3FF] dark:border-[#38405B] rounded-2xl hover:border-[#5B6CF8] hover:bg-[#F5F7FF] dark:hover:bg-[#232842] transition-all text-left shadow-sm disabled:opacity-60 disabled:cursor-not-allowed"
              >
                <div className="w-11 h-11 bg-[#EEF0FE] dark:bg-[#2A3250] border border-[#DDE3FF] dark:border-[#454F74] rounded-xl flex items-center justify-center flex-shrink-0 transition-colors shadow-sm">
                  <User className="w-5 h-5 text-[#5B6CF8]" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-sm text-[#1A1D23] dark:text-white">
                    {t('onboarding.personalAccountTitle')}
                  </p>
                  <p className="text-xs text-[#9CA3AF] mt-0.5">
                    {t('onboarding.personalAccountSubtitle')}
                  </p>
                </div>

                <ArrowRight className="w-4 h-4 text-[#D1D5DB] group-hover:text-[#5B6CF8] group-hover:translate-x-0.5 transition-all flex-shrink-0" />
              </button>

              <button
                onClick={() => setStep('join')}
                disabled={isSavingChoice}
                className="w-full group flex items-center gap-4 p-5 bg-[#F9FAFB] dark:bg-[#232833] border-2 border-[#E5E7EB] dark:border-[#343842] rounded-2xl hover:border-[#5B6CF8] hover:bg-[#EEF0FE] dark:hover:bg-[#232842] transition-all text-left"
              >
                <div className="w-11 h-11 bg-white dark:bg-[#1C1F26] border border-[#E5E7EB] dark:border-[#343842] rounded-xl flex items-center justify-center flex-shrink-0 group-hover:border-[#C7CDF9] transition-colors shadow-sm">
                  <Users className="w-5 h-5 text-[#6B7280] group-hover:text-[#5B6CF8] transition-colors" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-sm text-[#1A1D23] dark:text-white group-hover:text-[#5B6CF8] transition-colors">
                    {t('onboardingWorkspace.joinExistingWorkspace')}
                  </p>
                  <p className="text-xs text-[#9CA3AF] mt-0.5">
                    {t('onboardingWorkspace.joinExistingWorkspaceDescription')}
                  </p>
                </div>

                <ArrowRight className="w-4 h-4 text-[#D1D5DB] group-hover:text-[#5B6CF8] group-hover:translate-x-0.5 transition-all flex-shrink-0" />
              </button>

              <button
                onClick={() => setStep('create')}
                disabled={isSavingChoice}
                className="w-full group flex items-center gap-4 p-5 bg-[#5B6CF8] border-2 border-[#5B6CF8] rounded-2xl hover:bg-[#4A58E0] hover:border-[#4A58E0] transition-all text-left shadow-lg shadow-[#5B6CF8]/20"
              >
                <div className="w-11 h-11 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white">{t('onboardingWorkspace.createWorkspace')}</p>
                  <p className="text-xs text-white/70 mt-0.5">
                    {t('onboardingWorkspace.createWorkspaceDescription')}
                  </p>
                </div>

                <ArrowRight className="w-4 h-4 text-white/70 group-hover:translate-x-0.5 transition-transform flex-shrink-0" />
              </button>
            </div>

            {allowSkip && (
              <div className="text-center">
                <button
                  onClick={() => void handleSkip()}
                  disabled={isSkipping}
                  className="text-xs text-[#9CA3AF] hover:text-[#6B7280] transition-colors underline underline-offset-2"
                >
                  {isSkipping ? t('common.saving') : t('onboardingWorkspace.saveLater')}
                </button>
              </div>
            )}

            {skipError && (
              <p className="mt-4 text-center text-xs text-[#EF4444]">{skipError}</p>
            )}
          </div>
        )}

        {step === 'join' && (
          <div className="relative p-8">
            <button
              onClick={() => {
                setStep('choice');
                setCodeError('');
                setInviteCode('');
              }}
              className="flex items-center gap-1.5 text-xs text-[#9CA3AF] hover:text-[#6B7280] transition-colors mb-7 group"
            >
              <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
              {t('onboardingWorkspace.back')}
            </button>

            <div className="mb-7 text-center">
              <div className="w-14 h-14 bg-[#EEF0FE] rounded-2xl flex items-center justify-center mx-auto mb-5">
                <Hash className="w-7 h-7 text-[#5B6CF8]" />
              </div>
              <h2 className="text-[#1A1D23] dark:text-white mb-2">{t('onboardingWorkspace.enterInviteCodeTitle')}</h2>
              <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] max-w-xs mx-auto leading-relaxed">
                {t('onboardingWorkspace.enterInviteCodeDescription')}
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-[#374151] dark:text-[#D1D5DB] mb-1.5">
                  {t('onboardingWorkspace.inviteCodeOrLink')}
                </label>
                <input
                  autoFocus
                  type="text"
                  value={inviteCode}
                  onChange={(e) => {
                    setInviteCode(e.target.value);
                    setCodeError('');
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && handleJoin()}
                  placeholder={t('onboardingWorkspace.inviteCodeOrLink')}
                  className={`w-full px-4 py-3 rounded-xl border text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF] focus:outline-none transition-all ${
                    codeError
                      ? 'border-[#EF4444] bg-[#FFF5F5] focus:ring-2 focus:ring-[#EF4444]/10'
                      : 'border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#232833] focus:border-[#5B6CF8] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[#5B6CF8]/10'
                  }`}
                />
                {codeError && (
                  <p className="text-xs text-[#EF4444] mt-1.5">{codeError}</p>
                )}
              </div>

              <button
                onClick={handleJoin}
                disabled={isSavingChoice}
                className="w-full py-3 bg-[#5B6CF8] text-white rounded-xl text-sm hover:bg-[#4A58E0] transition-colors shadow-md shadow-[#5B6CF8]/20 flex items-center justify-center gap-2"
              >
                {isSavingChoice ? t('onboardingWorkspace.joining') : t('onboardingWorkspace.joinExistingWorkspace')}
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {choiceError && (
              <p className="text-center text-xs text-[#EF4444] mt-4">{choiceError}</p>
            )}

            <p className="text-center text-xs text-[#9CA3AF] mt-5">
              {t('onboardingWorkspace.noCodePrompt')}{' '}
              <button
                onClick={() => setStep('create')}
                className="text-[#5B6CF8] hover:underline"
              >
                {t('onboardingWorkspace.createNewWorkspaceLink')}
              </button>
            </p>
          </div>
        )}

        {step === 'create' && (
          <div className="relative p-8">
            <button
              onClick={() => {
                setStep('choice');
                setWorkspaceName('');
                setCreateError('');
              }}
              className="flex items-center gap-1.5 text-xs text-[#9CA3AF] hover:text-[#6B7280] transition-colors mb-7 group"
            >
              <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
              {t('onboardingWorkspace.back')}
            </button>

            <div className="mb-7 text-center">
              <div className="w-14 h-14 bg-[#EEF0FE] rounded-2xl flex items-center justify-center mx-auto mb-5">
                <Globe className="w-7 h-7 text-[#5B6CF8]" />
              </div>
              <h2 className="text-[#1A1D23] dark:text-white mb-2">{t('onboardingWorkspace.createWorkspaceTitle')}</h2>
              <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] max-w-xs mx-auto leading-relaxed">
                {t('onboardingWorkspace.createWorkspaceDescription2')}
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-[#374151] dark:text-[#D1D5DB] mb-1.5">
                  {t('onboardingWorkspace.companyWorkspaceName')}
                </label>
                <input
                  autoFocus
                  type="text"
                  value={workspaceName}
                  onChange={(e) => setWorkspaceName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                  placeholder={t('onboardingWorkspace.companyWorkspaceName')}
                  className="w-full px-4 py-3 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#232833] text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#5B6CF8] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[#5B6CF8]/10 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm text-[#374151] dark:text-[#D1D5DB] mb-1.5">
                  {t('onboardingWorkspace.industry')}
                </label>
                <select
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#232833] text-sm text-[#1A1D23] dark:text-white focus:outline-none focus:border-[#5B6CF8] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[#5B6CF8]/10 transition-all appearance-none cursor-pointer"
                >
                  {['Technology', 'E-commerce', 'Finance', 'Healthcare', 'Education', 'Retail', 'Marketing', 'Other'].map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleCreate}
                disabled={!workspaceName.trim() || isSavingChoice}
                className="w-full py-3 bg-[#5B6CF8] text-white rounded-xl text-sm hover:bg-[#4A58E0] transition-colors shadow-md shadow-[#5B6CF8]/20 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSavingChoice ? 'Creating...' : t('onboardingWorkspace.createWorkspace')}
                <ArrowRight className="w-4 h-4" />
              </button>
              {createError && <p className="text-xs text-[#EF4444]">{createError}</p>}
            </div>

            {choiceError && (
              <p className="text-center text-xs text-[#EF4444] mt-4">{choiceError}</p>
            )}
          </div>
        )}

        {step === 'joining' && (
          <div className="relative p-8 min-h-[300px] flex flex-col items-center justify-center gap-5">
            <div className="w-14 h-14 rounded-full border-4 border-[#EEF0FE] border-t-[#5B6CF8] animate-spin" />
            <div className="text-center">
              <p className="text-sm text-[#1A1D23] dark:text-white">{t('onboardingWorkspace.joiningTitle')}</p>
              <p className="text-xs text-[#9CA3AF] mt-1">{t('onboardingWorkspace.joiningDescription')}</p>
            </div>
          </div>
        )}

        {step === 'creating' && (
          <div className="relative p-8 min-h-[300px] flex flex-col items-center justify-center gap-5">
            <div className="w-14 h-14 rounded-full border-4 border-[#EEF0FE] border-t-[#5B6CF8] animate-spin" />
            <div className="text-center">
              <p className="text-sm text-[#1A1D23] dark:text-white">{t('onboardingWorkspace.creatingTitle')}</p>
              <p className="text-xs text-[#9CA3AF] mt-1">{t('onboardingWorkspace.creatingDescription')}</p>
            </div>
          </div>
        )}

        {step === 'personal' && (
          <div className="relative p-8 min-h-[300px] flex flex-col items-center justify-center gap-5">
            <div className="w-14 h-14 rounded-full border-4 border-[#EEF0FE] border-t-[#5B6CF8] animate-spin" />
            <div className="text-center">
              <p className="text-sm text-[#1A1D23] dark:text-white">{t('onboardingWorkspace.personalTitle')}</p>
              <p className="text-xs text-[#9CA3AF] mt-1">{t('onboardingWorkspace.personalDescription')}</p>
            </div>
          </div>
        )}

        {step === 'done' && (
          <div className="relative p-8 min-h-[300px] flex flex-col items-center justify-center gap-5">
            <div className="w-14 h-14 bg-[#ECFDF5] rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-[#10B981]" />
            </div>
            <div className="text-center">
              <p className="text-sm text-[#1A1D23] dark:text-white">{t('onboardingWorkspace.doneTitle')}</p>
              <p className="text-xs text-[#9CA3AF] mt-1">{t('onboardingWorkspace.doneDescription')}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default WorkspaceModal;
