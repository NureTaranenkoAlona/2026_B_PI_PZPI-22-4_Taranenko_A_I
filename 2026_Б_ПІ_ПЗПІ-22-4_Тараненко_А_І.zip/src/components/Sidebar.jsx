const chats = [
  {
    id: 1,
    title: 'Telegram Chat',
    platform: 'Telegram',
  },
  {
    id: 2,
    title: 'Messenger Chat',
    platform: 'Messenger',
  },
];

function Sidebar() {
  return (
    <div>
      {chats.map((chat) => (
        <div key={chat.id} style={{ padding: '10px', borderBottom: '1px solid #eee' }}>
          <div>{chat.title}</div>
          <small>{chat.platform}</small>
        </div>
      ))}
    </div>
  );
}

export default Sidebar;