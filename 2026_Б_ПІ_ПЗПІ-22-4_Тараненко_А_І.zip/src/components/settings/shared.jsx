import { useAppLanguage } from '../../context/AppLanguageContext';
import { Loader2 } from 'lucide-react';

export function Section({ title, description, children }) {
  return (
    <div className="bg-white dark:bg-[#1C1F26] border border-[#E5E7EB] dark:border-[#2F3440] rounded-2xl overflow-hidden">
      <div
        className="border-b border-[#F3F4F6] dark:border-[#2F3440]"
        style={{
          paddingInline: 'var(--dialogly-density-section-x)',
          paddingBlock: 'var(--dialogly-density-section-header-y)',
        }}
      >
        <h3 className="text-sm text-[#1A1D23] dark:text-white">{title}</h3>
        {description && (
          <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF] mt-0.5 leading-relaxed">
            {description}
          </p>
        )}
      </div>
      <div
        className="space-y-5"
        style={{
          paddingInline: 'var(--dialogly-density-section-x)',
          paddingBlock: 'var(--dialogly-density-section-body-y)',
        }}
      >
        {children}
      </div>
    </div>
  );
}

export function Field({ label, hint, children, horizontal }) {
  if (horizontal) {
    return (
      <div className="flex items-center justify-between gap-6 py-1">
        <div className="flex-1 min-w-0">
          <p className="text-sm text-[#1A1D23] dark:text-white">{label}</p>
          {hint && <p className="text-xs text-[#9CA3AF] mt-0.5">{hint}</p>}
        </div>
        <div className="flex-shrink-0">{children}</div>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      <label className="block text-sm text-[#374151] dark:text-[#D1D5DB]">{label}</label>
      {hint && <p className="text-xs text-[#9CA3AF] -mt-0.5">{hint}</p>}
      {children}
    </div>
  );
}

export function Input({ suffix, className = '', ...props }) {
  if (suffix) {
    return (
      <div className="flex rounded-xl overflow-hidden border border-[#E5E7EB] dark:border-[#343842] focus-within:border-[var(--dialogly-accent)] focus-within:ring-2 focus-within:ring-[var(--dialogly-accent-soft)] transition-all">
        <input
          {...props}
          className={`flex-1 px-3.5 py-2.5 bg-[#F9FAFB] dark:bg-[#232833] text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF] focus:outline-none transition-colors ${className}`}
        />
        <span className="px-3.5 py-2.5 bg-[#F3F4F6] dark:bg-[#2A2F3A] border-l border-[#E5E7EB] dark:border-[#343842] text-sm text-[#6B7280] dark:text-[#9CA3AF] flex-shrink-0 flex items-center">
          {suffix}
        </span>
      </div>
    );
  }

  return (
    <input
      {...props}
      className={`w-full px-3.5 py-2.5 bg-[#F9FAFB] dark:bg-[#232833] border border-[#E5E7EB] dark:border-[#343842] rounded-xl text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF] focus:outline-none focus:border-[var(--dialogly-accent)] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[var(--dialogly-accent-soft)] transition-all ${className}`}
    />
  );
}

export function Textarea(props) {
  return (
    <textarea
      rows={3}
      {...props}
      className="w-full px-3.5 py-2.5 bg-[#F9FAFB] dark:bg-[#232833] border border-[#E5E7EB] dark:border-[#343842] rounded-xl text-sm text-[#1A1D23] dark:text-white placeholder:text-[#9CA3AF] focus:outline-none focus:border-[var(--dialogly-accent)] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[var(--dialogly-accent-soft)] transition-all resize-none"
    />
  );
}

export function Select(props) {
  return (
    <select
      {...props}
      className="w-full px-3.5 py-2.5 bg-[#F9FAFB] dark:bg-[#232833] border border-[#E5E7EB] dark:border-[#343842] rounded-xl text-sm text-[#1A1D23] dark:text-white focus:outline-none focus:border-[var(--dialogly-accent)] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[var(--dialogly-accent-soft)] transition-all appearance-none cursor-pointer"
    />
  );
}

export function Toggle({ checked, onChange, disabled }) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex w-10 h-[22px] rounded-full transition-colors flex-shrink-0 ${
        checked ? 'bg-[var(--dialogly-accent)]' : 'bg-[#D1D5DB]'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
    >
      <span
        className={`absolute top-[3px] left-[3px] w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${
          checked ? 'translate-x-[18px]' : 'translate-x-0'
        }`}
      />
    </button>
  );
}

export function Btn({
  variant = 'primary',
  size = 'md',
  loading,
  children,
  className = '',
  ...props
}) {
  const base =
    'inline-flex items-center justify-center gap-2 rounded-xl transition-all font-medium disabled:opacity-60 disabled:cursor-not-allowed';
  const sizes = { sm: 'px-3 py-1.5 text-xs', md: 'px-4 py-2.5 text-sm' };
  const variants = {
    primary: 'bg-[var(--dialogly-accent)] text-white hover:bg-[var(--dialogly-accent-hover)]',
    outline:
      'bg-white dark:bg-[#1C1F26] border border-[#E5E7EB] dark:border-[#343842] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833]',
    danger: 'bg-[#EF4444] text-white hover:bg-[#DC2626]',
  };

  return (
    <button className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} {...props}>
      {loading ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          <span>{children}</span>
        </>
      ) : children}
    </button>
  );
}

export function Divider() {
  return <div className="border-t border-[#F3F4F6] dark:border-[#2F3440]" />;
}

export function SaveBar({ loading, onSave, onDiscard }) {
  const { t } = useAppLanguage();

  return (
    <div className="flex items-center justify-end gap-3">
      <Btn variant="outline" onClick={onDiscard}>
        {t('common.discard')}
      </Btn>
      <Btn onClick={onSave} loading={loading}>
        {loading ? t('common.saving') : t('common.saveChanges')}
      </Btn>
    </div>
  );
}

const settingsShared = {
  Section,
  Field,
  Input,
  Textarea,
  Select,
  Toggle,
  Btn,
  Divider,
  SaveBar,
};

export default settingsShared;
