import { useEffect, useMemo, useState } from 'react';
import { Field, Input, SaveBar, Section, Select, Textarea } from './shared';
import { useAccountContext } from '../../context/AccountContext';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { getWorkspace, updateWorkspace } from '../../api/workspaceApi';
import getApiErrorMessage from '../../utils/getApiErrorMessage';
import { useToast } from '../../context/ToastContext';

const languageOptions = [
  'English',
  'Ukrainian',
  'German',
  'French',
  'Spanish',
  'Polish',
  'Portuguese',
  'Italian',
  'Dutch',
  'Turkish',
  'Czech',
  'Slovak',
  'Romanian',
  'Hungarian',
  'Bulgarian',
  'Arabic',
  'Chinese',
  'Japanese',
  'Korean',
  'Hindi',
];

const emptyForm = {
  companyName: '',
  website: '',
  description: '',
  language: 'English',
};

function WorkspaceSettings() {
  const { t } = useAppLanguage();
  const { showSuccess, showError } = useToast();
  const { activeContext, refreshContexts } = useAccountContext();
  const workspaceId = activeContext?.type === 'workspace' ? activeContext.workspaceId : null;
  const canEdit = activeContext?.role === 'Owner' || activeContext?.role === 'Admin';

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [pageError, setPageError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [initialForm, setInitialForm] = useState(emptyForm);
  const [form, setForm] = useState(emptyForm);

  const isDirty = useMemo(
    () => JSON.stringify(form) !== JSON.stringify(initialForm),
    [form, initialForm]
  );

  useEffect(() => {
    const loadWorkspace = async () => {
      if (!workspaceId) {
        setInitialForm(emptyForm);
        setForm(emptyForm);
        return;
      }

      setIsLoading(true);
      setPageError('');
      try {
        const workspace = await getWorkspace(workspaceId);
        const nextForm = {
          companyName: workspace.name || '',
          website: workspace.website || '',
          description: workspace.description || '',
          language: workspace.defaultLanguage || 'English',
        };

        setInitialForm(nextForm);
        setForm(nextForm);
      } catch (error) {
        setPageError(getApiErrorMessage(error, 'Unable to load workspace settings.'));
      } finally {
        setIsLoading(false);
      }
    };

    loadWorkspace();
  }, [workspaceId]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setSuccessMessage('');
  };

  const handleSave = async () => {
    if (!workspaceId || !canEdit || !isDirty) return;

    setIsSaving(true);
    setPageError('');
    setSuccessMessage('');

    try {
      const updatedWorkspace = await updateWorkspace(workspaceId, {
        name: form.companyName,
        website: form.website,
        description: form.description,
        defaultLanguage: form.language,
      });

      const nextForm = {
        companyName: updatedWorkspace.name || '',
        website: updatedWorkspace.website || '',
        description: updatedWorkspace.description || '',
        language: updatedWorkspace.defaultLanguage || 'English',
      };

      setInitialForm(nextForm);
      setForm(nextForm);
      setSuccessMessage('Workspace settings saved.');
      showSuccess('Workspace settings saved');
      await refreshContexts();
    } catch (error) {
      const nextError = getApiErrorMessage(error, 'Unable to save workspace settings.');
      setPageError(nextError);
      showError(nextError);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDiscard = () => {
    setForm(initialForm);
    setSuccessMessage('');
  };

  if (!workspaceId) {
    return (
      <Section
        title={t('workspaceUi.workspaceIdentity')}
        description={t('workspaceUi.workspaceIdentityEmptyDescription')}
      >
        <div className="rounded-2xl border border-dashed border-[#D1D5DB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] px-4 py-8 text-center text-sm text-[#6B7280] dark:text-[#9CA3AF]">
          {t('workspaceUi.workspaceIdentityEmptyState')}
        </div>
      </Section>
    );
  }

  return (
    <div className="space-y-6">
      <Section
        title={t('workspaceUi.workspaceIdentity')}
        description={t('workspaceUi.workspaceIdentityDescription')}
      >
        {pageError && (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
            {pageError}
          </div>
        )}

        {successMessage && (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-400/20 dark:bg-emerald-500/10 dark:text-emerald-300">
            {successMessage}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label={t('workspaceUi.companyName')}>
              <Input name="companyName" value={form.companyName} onChange={handleChange} disabled={!canEdit || isLoading} />
            </Field>
            <Field label={t('workspaceUi.website')}>
              <Input name="website" value={form.website} onChange={handleChange} disabled={!canEdit || isLoading} />
            </Field>
            <div className="md:col-span-2">
              <Field label={t('workspaceUi.description')}>
                <Textarea name="description" value={form.description} onChange={handleChange} rows={4} disabled={!canEdit || isLoading} />
              </Field>
            </div>
            <div className="md:col-span-2">
              <Field label={t('workspaceUi.defaultLanguage')}>
                <Select name="language" value={form.language} onChange={handleChange} disabled={!canEdit || isLoading}>
                  {languageOptions.map((language) => (
                    <option key={language}>{language}</option>
                  ))}
                </Select>
              </Field>
            </div>
        </div>

        <div className="rounded-2xl bg-[#EEF6FF] dark:bg-[#202B3B] border border-[#D6E7FF] dark:border-[#31435F] px-4 py-3">
          <p className="text-sm text-[#24446B] dark:text-[#C4D6F6]">
            Messages are sent on behalf of your workspace or company brand, not from your personal
            Dialogly account.
          </p>
        </div>

        {canEdit ? (
          <SaveBar loading={isSaving} onSave={handleSave} onDiscard={handleDiscard} />
        ) : (
          <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] px-4 py-3 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
            Workspace settings are read-only for members without admin access.
          </div>
        )}
      </Section>
    </div>
  );
}

export default WorkspaceSettings;
