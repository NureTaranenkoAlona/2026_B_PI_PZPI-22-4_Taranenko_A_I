import { useEffect, useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { useAppPreferences } from '../../context/AppPreferencesContext';
import { Field, Input, SaveBar, Section, Select } from './shared';

function LanguageSettings() {
  const { language, setLanguage, t, languageOptions } = useAppLanguage();
  const { regionalSettings, setRegionalSettings } = useAppPreferences();
  const [isSaving, setIsSaving] = useState(false);
  const initialState = useMemo(
    () => ({
      currentLanguage: language,
      search: '',
      dateFormat: regionalSettings.dateFormat,
      timeFormat: regionalSettings.timeFormat,
      firstDayOfWeek: regionalSettings.firstDayOfWeek,
    }),
    [language, regionalSettings.dateFormat, regionalSettings.firstDayOfWeek, regionalSettings.timeFormat]
  );
  const [settings, setSettings] = useState(initialState);

  useEffect(() => {
    setSettings((prev) => ({
      ...prev,
      currentLanguage: language,
      dateFormat: regionalSettings.dateFormat,
      timeFormat: regionalSettings.timeFormat,
      firstDayOfWeek: regionalSettings.firstDayOfWeek,
    }));
  }, [language, regionalSettings.dateFormat, regionalSettings.firstDayOfWeek, regionalSettings.timeFormat]);

  const filteredLanguages = languageOptions.filter((option) => {
    return (
      option.name.toLocaleLowerCase().includes(settings.search.toLocaleLowerCase()) ||
      option.code.toLocaleLowerCase().includes(settings.search.toLocaleLowerCase())
    );
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setSettings((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setLanguage(settings.currentLanguage);
      setRegionalSettings({
        dateFormat: settings.dateFormat,
        timeFormat: settings.timeFormat,
        firstDayOfWeek: settings.firstDayOfWeek,
      });
      setIsSaving(false);
    }, 900);
  };

  const handleDiscard = () => {
    setSettings((prev) => ({ ...initialState, search: prev.search }));
  };

  return (
    <div className="space-y-6">
      <Section title={t('language.title')} description={t('language.description')}>
        <div className="grid grid-cols-1 gap-4">
          <div className="rounded-2xl bg-[#FCFCFD] dark:bg-[#20242E] border border-[#E5E7EB] dark:border-[#343842] p-4">
            <p className="text-xs uppercase tracking-wide text-[#9CA3AF]">
              {t('language.currentInterfaceLanguage')}
            </p>
            <p className="text-base text-[#1A1D23] dark:text-white mt-2">
              {languageOptions.find((option) => option.code === language)?.name ?? 'English'}
            </p>
          </div>
        </div>

        <Field label={t('language.searchLanguages')}>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <Input
              name="search"
              value={settings.search}
              onChange={handleChange}
              placeholder={t('language.searchLanguagePlaceholder')}
              className="pl-10"
            />
          </div>
        </Field>

        <div className="grid grid-cols-1 lg:grid-cols-[1.4fr,0.8fr] gap-6">
          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {filteredLanguages.map((option) => {
              const isActive = settings.currentLanguage === option.code;

              return (
                <button
                  key={option.code}
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, currentLanguage: option.code }))}
                  className={`w-full text-left px-4 py-3 rounded-2xl border transition-colors ${
                    isActive
                      ? 'border-[var(--dialogly-accent)] bg-[var(--dialogly-accent-soft)] text-[var(--dialogly-accent)] dark:bg-[var(--dialogly-accent-soft-dark)]'
                      : 'border-[#E5E7EB] dark:border-[#343842] bg-[#FCFCFD] dark:bg-[#20242E] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833]'
                  }`}
                >
                  <span className="text-sm">{option.name}</span>
                </button>
              );
            })}
          </div>

          <div className="space-y-4">
            <Field label={t('language.dateFormat')}>
              <Select name="dateFormat" value={settings.dateFormat} onChange={handleChange}>
                <option>DD.MM.YYYY</option>
                <option>MM/DD/YYYY</option>
                <option>YYYY-MM-DD</option>
              </Select>
            </Field>
            <Field label={t('language.timeFormat')}>
              <Select name="timeFormat" value={settings.timeFormat} onChange={handleChange}>
                <option value="24-hour">{t('language.twentyFourHour')}</option>
                <option value="12-hour">{t('language.twelveHour')}</option>
              </Select>
            </Field>
            <Field label={t('language.firstDayOfWeek')}>
              <Select name="firstDayOfWeek" value={settings.firstDayOfWeek} onChange={handleChange}>
                <option value="monday">{t('language.monday')}</option>
                <option value="sunday">{t('language.sunday')}</option>
                <option value="saturday">{t('language.saturday')}</option>
              </Select>
            </Field>
          </div>
        </div>

        <SaveBar loading={isSaving} onSave={handleSave} onDiscard={handleDiscard} />
      </Section>
    </div>
  );
}

export default LanguageSettings;
