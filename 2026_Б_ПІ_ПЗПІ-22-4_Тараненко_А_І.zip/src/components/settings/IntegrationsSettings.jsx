import { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  BadgeCheck,
  Camera,
  CheckCircle2,
  LoaderCircle,
  MessageCircle,
  RefreshCw,
  Send,
  Shield,
  Smartphone,
  Unplug,
} from 'lucide-react';

import { Btn, Divider, Section } from './shared';
import ConnectPlatformModal from '../onboarding/ConnectPlatformModal';
import { useAccountContext } from '../../context/AccountContext';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { useToast } from '../../context/ToastContext';
import {
  connectIntegration,
  connectMessengerPage,
  connectTelegramBot,
  disconnectIntegration,
  getIntegrations,
  getPlatforms,
} from '../../api/integrationApi';
import getApiErrorMessage from '../../utils/getApiErrorMessage';
import {
  buildMockConnectPayload,
  getIntegrationConflictMessage,
  getModalInitialValues,
  mapIntegrationData,
} from '../../utils/integrationUi';

const PLATFORM_META = {
  telegram: {
    icon: Send,
    accent: 'from-sky-400 to-cyan-500',
    soft: 'bg-sky-50 text-sky-700 dark:bg-sky-500/15 dark:text-sky-200',
  },
  messenger: {
    icon: MessageCircle,
    accent: 'from-blue-500 to-indigo-500',
    soft: 'bg-blue-50 text-blue-700 dark:bg-blue-500/15 dark:text-blue-200',
  },
  instagram: {
    icon: Camera,
    accent: 'from-rose-500 to-orange-400',
    soft: 'bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-200',
  },
  whatsapp: {
    icon: Smartphone,
    accent: 'from-emerald-500 to-green-500',
    soft: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-200',
  },
  viber: {
    icon: MessageCircle,
    accent: 'from-violet-500 to-purple-500',
    soft: 'bg-violet-50 text-violet-700 dark:bg-violet-500/15 dark:text-violet-200',
  },
};

const STATUS_META = {
  connected: {
    labelKey: 'integrationsUi.statusConnected',
    dot: 'bg-emerald-500',
    badge:
      'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-200',
  },
  disconnected: {
    labelKey: 'integrationsUi.statusDisconnected',
    dot: 'bg-slate-400',
    badge: 'bg-slate-100 text-slate-600 dark:bg-[#2A2F3A] dark:text-[#9CA3AF]',
  },
  connecting: {
    labelKey: 'integrationsUi.statusConnecting',
    dot: 'bg-amber-500',
    badge: 'bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-200',
  },
  reconnecting: {
    labelKey: 'integrationsUi.statusReconnecting',
    dot: 'bg-indigo-500',
    badge:
      'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-200',
  },
  unavailable: {
    labelKey: 'integrationsUi.statusUnavailable',
    dot: 'bg-slate-300',
    badge: 'bg-[#F3F4F6] text-[#9CA3AF] dark:bg-[#232833] dark:text-[#6B7280]',
  },
};

function formatDateTime(value) {
  if (!value) return null;

  const normalized = value.includes('T') ? value : value.replace(' ', 'T');
  const date = new Date(normalized);

  if (Number.isNaN(date.getTime())) return value;

  return new Intl.DateTimeFormat('en', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

function IntegrationCard({
  integration,
  activeContext,
  canManageIntegrations,
  busyAction,
  onConnect,
  onReconnect,
  onDisconnect,
}) {
  const { t } = useAppLanguage();
  const meta = PLATFORM_META[integration.id] || PLATFORM_META.messenger;
  const statusMeta = STATUS_META[integration.status] || STATUS_META.disconnected;
  const Icon = meta.icon;
  const isBusy = Boolean(busyAction);
  const isPersonal = activeContext.type === 'personal';
  const descriptionKey = `integrationsUi.platformDescription${integration.id.charAt(0).toUpperCase()}${integration.id.slice(1)}`;
  const description = t(descriptionKey);
  const syncLabel = formatDateTime(integration.lastSyncAt) || t('integrationsUi.neverSynced');

  return (
    <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white/70 dark:bg-[#20242E]/80 p-5 shadow-sm shadow-black/[0.03]">
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px] lg:items-start">
        <div className="flex gap-4 min-w-0">
          <div
            className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${meta.accent} flex items-center justify-center text-white shadow-sm flex-shrink-0`}
          >
            <Icon className="w-5 h-5" />
          </div>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h4 className="text-sm text-[#111827] dark:text-white">{integration.name}</h4>
                <span
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] ${statusMeta.badge}`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${statusMeta.dot}`} />
                {t(statusMeta.labelKey)}
              </span>
              {integration.managedByWorkspace && activeContext.type === 'workspace' && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] bg-[#EEF2FF] text-[#4F46E5] dark:bg-[#312E81]/40 dark:text-[#C7D2FE]">
                  <Shield className="w-3 h-3" />
                  {t('integrationsUi.managedByWorkspace')}
                </span>
              )}
              {isPersonal && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] bg-[#EFF6FF] text-[#2563EB] dark:bg-[#1E3A5F] dark:text-[#BFDBFE]">
                  {t('integrationsUi.personalBadge')}
                </span>
              )}
            </div>

            <p className="mt-1 text-sm leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
              {description}
            </p>

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-[#EEF2F7] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#1C1F26] p-3">
                <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">
                  {t('integrationsUi.connectedAccount')}
                </p>
                <p className="mt-1 text-sm text-[#111827] dark:text-white">
                  {integration.displayName || t('integrationsUi.noAccountConnected')}
                </p>
                <p className="mt-1 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                  {integration.status === 'connected'
                    ? isPersonal
                      ? t('integrationsUi.connectedForPersonal')
                      : t('integrationsUi.connectedForWorkspace', { name: activeContext.workspace?.name || '' })
                    : isPersonal
                      ? t('integrationsUi.notConnectedForPersonal')
                      : t('integrationsUi.notConnectedForWorkspace')}
                </p>
              </div>

              <div className="rounded-xl border border-[#EEF2F7] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#1C1F26] p-3">
                <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">
                  {t('integrationsUi.ownership')}
                </p>
                <p className="mt-1 text-sm text-[#111827] dark:text-white">
                  {isPersonal ? t('integrationsUi.personalIntegration') : t('integrationsUi.companyConnectedAccount')}
                </p>
                <p className="mt-1 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                  {isPersonal
                    ? t('integrationsUi.personalOwnershipHint')
                    : t('integrationsUi.workspaceOwnershipHint', { name: activeContext.workspace?.publicSenderName || '' })}
                </p>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-xs text-[#6B7280] dark:text-[#9CA3AF]">
              <span>
                <span className="text-[#9CA3AF]">{t('integrationsUi.lastSync')}</span>{' '}
                {integration.status === 'connected' || integration.status === 'reconnecting'
                  ? syncLabel
                  : t('integrationsUi.notAvailable')}
              </span>
              <span>
                <span className="text-[#9CA3AF]">{t('integrationsUi.connectedBy')}</span>{' '}
                {integration.connectedBy || t('integrationsUi.notConnectedYet')}
              </span>
            </div>
          </div>
        </div>

        <div className="w-full lg:min-w-0 lg:self-stretch">
          {canManageIntegrations ? (
            <div className="flex flex-wrap gap-2 lg:justify-end lg:pt-1">
              {integration.status === 'disconnected' ? (
                <Btn onClick={onConnect} loading={busyAction === 'connect'} disabled={isBusy}>
                  {busyAction === 'connect' ? (
                    <LoaderCircle className="w-4 h-4 animate-spin" />
                  ) : (
                    <BadgeCheck className="w-4 h-4" />
                  )}
                    {t('integrationsUi.connect')}
                  </Btn>
              ) : integration.status === 'connected' ? (
                <>
                  <Btn
                    variant="outline"
                    onClick={onReconnect}
                    disabled={isBusy}
                    loading={busyAction === 'reconnect'}
                  >
                    {busyAction === 'reconnect' ? (
                      <LoaderCircle className="w-4 h-4 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4" />
                    )}
                    {t('integrationsUi.reconnect')}
                  </Btn>
                  <Btn
                    variant="outline"
                    onClick={onDisconnect}
                    disabled={isBusy}
                    className="text-[#DC2626] border-[#FECACA] hover:bg-[#FEF2F2] dark:border-[#7F1D1D] dark:text-[#FCA5A5] dark:hover:bg-[#311313]"
                  >
                    {busyAction === 'disconnect' ? (
                      <LoaderCircle className="w-4 h-4 animate-spin" />
                    ) : (
                      <Unplug className="w-4 h-4" />
                    )}
                    {t('integrationsUi.disconnect')}
                  </Btn>
                </>
              ) : (
                <Btn variant="outline" disabled>
                  {t('integrationsUi.unavailable')}
                </Btn>
              )}
            </div>
          ) : (
            <div className="h-full rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#1C1F26] p-4">
              <div className="flex items-start gap-3">
                <div className={`mt-0.5 w-9 h-9 rounded-xl flex items-center justify-center ${meta.soft}`}>
                  <AlertCircle className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm text-[#111827] dark:text-white">
                    {t('integrationsUi.workspaceOwnerOnlyTitle')}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                    {t('integrationsUi.workspaceOwnerOnlyDescription')}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function IntegrationsSettings() {
  const { t } = useAppLanguage();
  const { showError } = useToast();
  const {
    activeContext,
    canManageActiveIntegrations,
  } = useAccountContext();
  const [integrations, setIntegrations] = useState([]);
  const [busyMap, setBusyMap] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [pageError, setPageError] = useState('');
  const [isModalSubmitting, setIsModalSubmitting] = useState(false);
  const [modalState, setModalState] = useState({
    open: false,
    mode: 'connect',
    integration: null,
  });

  useEffect(() => {
    const load = async () => {
      if (!activeContext?.id) return;

      setIsLoading(true);
      setBusyMap({});
      setPageError('');

      try {
        const [platforms, integrationAccounts] = await Promise.all([
          getPlatforms(),
          getIntegrations(),
        ]);

        setIntegrations(mapIntegrationData(platforms, integrationAccounts, activeContext));
      } catch (error) {
        setPageError(
          getApiErrorMessage(
            error,
            'Unable to load integrations right now. Please try again.'
          )
        );
      } finally {
        setIsLoading(false);
      }
    };

    load();
  }, [activeContext]);

  const connectedCount = useMemo(
    () => integrations.filter((integration) => integration.status === 'connected').length,
    [integrations]
  );

  const updateIntegration = (id, updates) => {
    setIntegrations((current) =>
      current.map((integration) =>
        integration.id === id ? { ...integration, ...updates } : integration
      )
    );
  };

  const applyBackendIntegration = (platformId, backendIntegration, fallbackDescription) => {
    setIntegrations((current) =>
      current.map((integration) =>
        integration.id === platformId
          ? mapIntegrationData(
              [
                {
                  id: backendIntegration.id,
                  code: backendIntegration.platformCode,
                  name: backendIntegration.platformName,
                  shortDescription: fallbackDescription,
                },
              ],
              [backendIntegration],
              activeContext
            )[0]
          : integration
      )
    );
  };

  const runAction = async (integration, action, pendingStatus, request) => {
    setBusyMap((current) => ({ ...current, [integration.id]: action }));
    updateIntegration(integration.id, { status: pendingStatus });

    try {
      const result = await request();
      applyBackendIntegration(integration.id, result, integration.description);
      setPageError('');
      return true;
    } catch (error) {
      updateIntegration(integration.id, {
        status: action === 'disconnect'
          ? 'connected'
          : integration.backendId
            ? 'connected'
            : 'disconnected',
      });
      const conflictMessage = getIntegrationConflictMessage(error, integration.id);
      setPageError(
        conflictMessage ||
          getApiErrorMessage(
            error,
            action === 'disconnect'
              ? 'Unable to disconnect this integration right now.'
              : 'Unable to connect this integration right now.'
          )
      );
      if (action !== 'disconnect') {
        showError(conflictMessage || 'Failed to connect integration');
      }
      return false;
    } finally {
      setBusyMap((current) => ({ ...current, [integration.id]: '' }));
    }
  };

  const handleConnect = (integration) => {
    setModalState({
      open: true,
      mode: 'connect',
      integration,
    });
  };

  const handleReconnect = (integration) => {
    setModalState({
      open: true,
      mode: 'reconnect',
      integration,
    });
  };

  const handleDisconnect = (integration) => {
    if (!integration.backendId) return;

    runAction(
      integration,
      'disconnect',
      'reconnecting',
      () => disconnectIntegration(integration.backendId)
    );
  };

  const handleModalSubmit = async (values) => {
    const integration = modalState.integration;
    if (!integration) return;

    const action = modalState.mode === 'reconnect' ? 'reconnect' : 'connect';
    setIsModalSubmitting(true);

    try {
      const succeeded = await runAction(
        integration,
        action,
        action === 'reconnect' ? 'reconnecting' : 'connecting',
        () =>
          integration.id === 'telegram'
            ? connectTelegramBot({
                botToken: values.botToken.trim(),
              })
            : integration.id === 'messenger'
              ? connectMessengerPage({
                  pageId: values.pageId.trim(),
                  pageAccessToken: values.pageAccessToken.trim(),
                  pageName: values.pageName.trim(),
                })
              : connectIntegration(
                  buildMockConnectPayload(integration.id, {
                    ...values,
                    pageName: values.pageName || integration.username || integration.externalAccountId,
                    displayName: values.displayName || integration.displayName,
                  })
                )
      );

      if (succeeded) {
        setModalState({ open: false, mode: 'connect', integration: null });
      }
    } finally {
      setIsModalSubmitting(false);
    }
  };

  return (
    <div className="space-y-5">
      <Section
        title={t('integrationsUi.accountOwnedChannels')}
        description={t('integrationsUi.accountOwnedChannelsDescription')}
      >
        <div className="rounded-2xl border border-[#D9E3FF] dark:border-[#2E3A59] bg-gradient-to-br from-[#EEF4FF] to-[#F8FAFF] dark:from-[#1D2635] dark:to-[#18202D] p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white dark:bg-[#111827] flex items-center justify-center text-[#4F46E5] shadow-sm">
              <Shield className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-[#111827] dark:text-white">
                {activeContext.type === 'personal'
                  ? t('integrationsUi.personalIntegrations')
                  : t('integrationsUi.workspaceLevelIntegrations')}
              </p>
              <p className="mt-1 text-sm leading-relaxed text-[#52607A] dark:text-[#A8B3C7]">
                {activeContext.type === 'personal'
                  ? t('integrationsUi.personalIntegrationsDescription')
                  : t('integrationsUi.workspaceIntegrationsDescription')}
              </p>
            </div>
          </div>

          <Divider />

          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-white/70 dark:bg-[#111827]/60 p-3 border border-white/70 dark:border-[#253047]">
              <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">
                {t('integrationsUi.activeAccount')}
              </p>
              <p className="mt-1 text-sm text-[#111827] dark:text-white">
                {activeContext.type === 'personal'
                  ? t('settingsUi.personalAccount')
                  : activeContext.workspace?.name}
              </p>
            </div>
            <div className="rounded-xl bg-white/70 dark:bg-[#111827]/60 p-3 border border-white/70 dark:border-[#253047]">
              <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">
                {t('integrationsUi.yourRole')}
              </p>
              <p className="mt-1 text-sm text-[#111827] dark:text-white">
                {activeContext.type === 'personal' ? t('integrationsUi.personalOwner') : activeContext.role}
              </p>
            </div>
            <div className="rounded-xl bg-white/70 dark:bg-[#111827]/60 p-3 border border-white/70 dark:border-[#253047]">
              <p className="text-[11px] uppercase tracking-[0.18em] text-[#9CA3AF]">
                {t('integrationsUi.connectedChannels')}
              </p>
              <p className="mt-1 text-sm text-[#111827] dark:text-white">{t('integrationsUi.activeCount', { count: connectedCount })}</p>
            </div>
          </div>
        </div>
      </Section>

      <Section
        title={t('integrationsUi.platformConnections')}
        description={t('integrationsUi.platformConnectionsDescription')}
      >
        <div className="space-y-4">
          {pageError && (
            <div className="rounded-2xl border border-[#FECACA] dark:border-[#7F1D1D] bg-[#FEF2F2] dark:bg-[#311313] p-4 flex gap-3">
              <AlertCircle className="w-5 h-5 text-[#DC2626] flex-shrink-0 mt-0.5" />
              <p className="text-sm text-[#991B1B] dark:text-[#FCA5A5]">{pageError}</p>
            </div>
          )}

          {isLoading ? (
            <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white/70 dark:bg-[#20242E]/80 p-6 flex items-center justify-center gap-3 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
              <LoaderCircle className="w-4 h-4 animate-spin" />
              {t('integrationsUi.loadingIntegrations')}
            </div>
          ) : (
            integrations.map((integration) => (
              <IntegrationCard
                key={integration.id}
                integration={integration}
                activeContext={activeContext}
                canManageIntegrations={canManageActiveIntegrations}
                busyAction={busyMap[integration.id]}
                onConnect={() => handleConnect(integration)}
                onReconnect={() => handleReconnect(integration)}
                onDisconnect={() => handleDisconnect(integration)}
              />
            ))
          )}
        </div>

        {!canManageActiveIntegrations && activeContext.type === 'workspace' && (
          <div className="rounded-2xl border border-[#FDE68A] dark:border-[#5B4B1F] bg-[#FFFBEB] dark:bg-[#2B2413] p-4 flex gap-3">
            <AlertCircle className="w-5 h-5 text-[#D97706] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-[#111827] dark:text-white">{t('integrationsUi.viewOnlyAccess')}</p>
              <p className="mt-1 text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                {t('integrationsUi.viewOnlyAccessDescription')}
              </p>
            </div>
          </div>
        )}

        {canManageActiveIntegrations && (
          <div className="rounded-2xl border border-[#DCFCE7] dark:border-[#1F5133] bg-[#F0FDF4] dark:bg-[#13251B] p-4 flex gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#16A34A] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-[#111827] dark:text-white">
                {activeContext.type === 'personal'
                  ? t('integrationsUi.personalControlEnabled')
                  : t('integrationsUi.ownerControlEnabled')}
              </p>
              <p className="mt-1 text-xs leading-relaxed text-[#6B7280] dark:text-[#9CA3AF]">
                {activeContext.type === 'personal'
                  ? t('integrationsUi.personalControlDescription')
                  : t('integrationsUi.ownerControlDescription', { role: activeContext.role })}
              </p>
            </div>
          </div>
        )}
      </Section>

      <ConnectPlatformModal
        isOpen={modalState.open}
        mode={modalState.mode}
        integration={modalState.integration}
        workspaceName={
          activeContext.type === 'personal'
            ? t('settingsUi.personalAccount')
            : activeContext.workspace?.name
        }
        initialValues={getModalInitialValues(modalState.integration)}
        isSubmitting={isModalSubmitting}
        onClose={() => setModalState({ open: false, mode: 'connect', integration: null })}
        onSubmit={handleModalSubmit}
      />
    </div>
  );
}

export default IntegrationsSettings;
