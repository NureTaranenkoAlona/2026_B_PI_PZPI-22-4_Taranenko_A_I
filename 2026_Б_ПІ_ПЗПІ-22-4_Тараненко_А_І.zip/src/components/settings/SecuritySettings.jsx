import { useEffect, useMemo, useState } from 'react';
import {
  Eye,
  EyeOff,
  Loader2,
  ShieldCheck,
  TriangleAlert,
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import {
  changePassword,
  confirmTwoFactorSetup,
  disableTwoFactor,
  enableTwoFactor,
  getTwoFactorSetup,
  getTwoFactorStatus,
} from '../../api/authApi';
import { getSecuritySettings, updateSecuritySettings } from '../../api/userApi';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { useToast } from '../../context/ToastContext';
import getApiErrorMessage from '../../utils/getApiErrorMessage';
import { Btn, Field, Input, Section, Toggle } from './shared';

function getPasswordStrength(password, t) {
  if (!password) return { label: t('settingsUi.noPassword'), width: '0%', color: '#D1D5DB' };

  const checks = [
    password.length >= 8,
    /[A-Z]/.test(password),
    /[a-z]/.test(password),
    /\d/.test(password),
    /[^A-Za-z0-9]/.test(password),
  ];

  const score = checks.filter(Boolean).length;
  if (score <= 1) return { label: t('settingsUi.weak'), width: '30%', color: '#EF4444' };
  if (score <= 3) return { label: t('settingsUi.medium'), width: '60%', color: '#F59E0B' };
  return { label: t('settingsUi.strong'), width: '100%', color: '#10B981' };
}

function SecuritySettings() {
  const { t } = useAppLanguage();
  const { showSuccess, showError } = useToast();
  const [isPageLoading, setIsPageLoading] = useState(true);
  const [pageError, setPageError] = useState('');
  const [isPasswordSaving, setIsPasswordSaving] = useState(false);
  const [isLoginAlertsSaving, setIsLoginAlertsSaving] = useState(false);
  const [isTwoFactorLoading, setIsTwoFactorLoading] = useState(false);
  const [showPasswords, setShowPasswords] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [twoFactorError, setTwoFactorError] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [twoFactorFlowMode, setTwoFactorFlowMode] = useState('');
  const [securitySettings, setSecuritySettings] = useState({
    loginAlertsEnabled: true,
  });
  const [twoFactorStatus, setTwoFactorStatus] = useState({
    twoFactorEnabled: false,
    hasSecret: false,
  });
  const [twoFactorSetup, setTwoFactorSetup] = useState(null);
  const [form, setForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const passwordStrength = getPasswordStrength(form.newPassword, t);
  const passwordsMatch = form.confirmPassword.length > 0 && form.newPassword === form.confirmPassword;
  const effectiveTwoFactorEnabled = twoFactorStatus.twoFactorEnabled && twoFactorStatus.hasSecret;

  useEffect(() => {
    const loadSecurityPage = async () => {
      setIsPageLoading(true);
      setPageError('');

      try {
        const [settingsResponse, twoFactorStatusResponse] = await Promise.all([
          getSecuritySettings(),
          getTwoFactorStatus(),
        ]);

        setSecuritySettings({
          loginAlertsEnabled: Boolean(settingsResponse?.loginAlertsEnabled),
        });
        setTwoFactorStatus({
          twoFactorEnabled: Boolean(twoFactorStatusResponse?.twoFactorEnabled),
          hasSecret: Boolean(twoFactorStatusResponse?.hasSecret),
        });
      } catch (error) {
        setPageError(getApiErrorMessage(error, 'Unable to load security settings.'));
      } finally {
        setIsPageLoading(false);
      }
    };

    void loadSecurityPage();
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setPasswordError('');
  };

  const handleSavePassword = async () => {
    setPasswordError('');
    setIsPasswordSaving(true);

    try {
      await changePassword(form);
      setForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
      showSuccess('Password changed successfully');
    } catch (error) {
      const message = getApiErrorMessage(error, 'Unable to change password.');
      setPasswordError(message);
      showError(message);
    } finally {
      setIsPasswordSaving(false);
    }
  };

  const handleDiscardPassword = () => {
    setForm({
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    });
    setPasswordError('');
  };

  const handleToggleLoginAlerts = async (value) => {
    setIsLoginAlertsSaving(true);

    try {
      const response = await updateSecuritySettings({ loginAlertsEnabled: value });
      setSecuritySettings({
        loginAlertsEnabled: Boolean(response?.loginAlertsEnabled),
      });
      showSuccess('Security settings saved');
    } catch (error) {
      showError(getApiErrorMessage(error, 'Unable to update login alerts.'));
    } finally {
      setIsLoginAlertsSaving(false);
    }
  };

  const resetTwoFactorUi = () => {
    setTwoFactorFlowMode('');
    setTwoFactorSetup(null);
    setTwoFactorCode('');
    setTwoFactorError('');
  };

  const handleStartTwoFactorSetup = async () => {
    setIsTwoFactorLoading(true);
    setTwoFactorError('');

    try {
      const response = await getTwoFactorSetup();
      setTwoFactorSetup(response);
      setTwoFactorFlowMode('setup');
      setTwoFactorCode('');
    } catch (error) {
      const message = getApiErrorMessage(error, 'Unable to start two-factor setup.');
      setTwoFactorError(message);
      showError(message);
    } finally {
      setIsTwoFactorLoading(false);
    }
  };

  const handleConfirmTwoFactorSetup = async () => {
    if (!twoFactorSetup?.secret) {
      return;
    }

    setIsTwoFactorLoading(true);
    setTwoFactorError('');

    try {
      await confirmTwoFactorSetup({
        secret: twoFactorSetup.secret,
        code: twoFactorCode.trim(),
      });

      setTwoFactorStatus({
        twoFactorEnabled: true,
        hasSecret: true,
      });
      resetTwoFactorUi();
      showSuccess('2FA enabled successfully');
    } catch (error) {
      const message = getApiErrorMessage(error, 'Invalid code, try again');
      setTwoFactorError(message);
      showError(message);
    } finally {
      setIsTwoFactorLoading(false);
    }
  };

  const handleEnableTwoFactor = async () => {
    setIsTwoFactorLoading(true);
    setTwoFactorError('');

    try {
      await enableTwoFactor({ code: twoFactorCode.trim() });
      setTwoFactorStatus({
        twoFactorEnabled: true,
        hasSecret: true,
      });
      resetTwoFactorUi();
      showSuccess('2FA enabled successfully');
    } catch (error) {
      const message = getApiErrorMessage(error, 'Invalid code, try again');
      setTwoFactorError(message);
      showError(message);
    } finally {
      setIsTwoFactorLoading(false);
    }
  };

  const handleDisableTwoFactor = async () => {
    setIsTwoFactorLoading(true);
    setTwoFactorError('');

    try {
      await disableTwoFactor({ code: twoFactorCode.trim() });
      setTwoFactorStatus({
        twoFactorEnabled: false,
        hasSecret: true,
      });
      resetTwoFactorUi();
      showSuccess('2FA disabled');
    } catch (error) {
      const message = getApiErrorMessage(error, 'Invalid code');
      setTwoFactorError(message);
      showError(message);
    } finally {
      setIsTwoFactorLoading(false);
    }
  };

  const handleTwoFactorToggle = (nextValue) => {
    if (isTwoFactorLoading) {
      return;
    }

    setTwoFactorError('');
    setTwoFactorCode('');

    if (nextValue) {
      if (twoFactorStatus.hasSecret) {
        setTwoFactorFlowMode('reenable');
        setTwoFactorSetup(null);
      } else {
        void handleStartTwoFactorSetup();
      }

      return;
    }

    setTwoFactorFlowMode('disable');
    setTwoFactorSetup(null);
  };

  return (
    <div className="space-y-6">
      <Section
        title={t('settingsUi.securityOverviewTitle')}
        description={t('settingsUi.securityOverviewDescription')}
      >
        {pageError && (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
            {pageError}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#FCFCFD] dark:bg-[#20242E] p-4">
            <div className="w-10 h-10 rounded-xl bg-[#EAF8F0] dark:bg-[#1A3428] text-[#10B981] flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <p className="text-sm text-[#1A1D23] dark:text-white mt-4">
              {effectiveTwoFactorEnabled ? t('settingsUi.twoFactorEnabled') : t('settingsUi.twoFactorDisabled')}
            </p>
            <p className="text-xs text-[#9CA3AF] mt-1">
              {effectiveTwoFactorEnabled
                ? t('settingsUi.twoFactorEnabledHint')
                : t('settingsUi.twoFactorDisabledHint')}
            </p>
          </div>

          <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#FFF7ED] dark:bg-[#372718] p-4">
            <div className="w-10 h-10 rounded-xl bg-[#FFE7D1] dark:bg-[#4A3320] text-[#F97316] flex items-center justify-center">
              <TriangleAlert className="w-5 h-5" />
            </div>
            <p className="text-sm text-[#1A1D23] dark:text-white mt-4">
              {securitySettings.loginAlertsEnabled ? t('settingsUi.loginAlertsActive') : t('settingsUi.loginAlertsDisabled')}
            </p>
            <p className="text-xs text-[#9CA3AF] mt-1">{t('settingsUi.loginAlertsHint')}</p>
          </div>
        </div>
      </Section>

      <Section
        title={t('settingsUi.changePasswordTitle')}
        description={t('settingsUi.changePasswordDescription')}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label={t('settingsUi.currentPassword')}>
            <Input
              name="currentPassword"
              type={showPasswords ? 'text' : 'password'}
              value={form.currentPassword}
              onChange={handleChange}
              placeholder={t('settingsUi.currentPasswordPlaceholder')}
            />
          </Field>

          <div className="md:row-span-2 rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#FCFCFD] dark:bg-[#20242E] p-4">
            <p className="text-sm text-[#1A1D23] dark:text-white">{t('settingsUi.passwordStrength')}</p>
            <div className="mt-3 h-2 rounded-full bg-[#E5E7EB] dark:bg-[#343842] overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: passwordStrength.width, backgroundColor: passwordStrength.color }}
              />
            </div>
            <p className="text-xs text-[#9CA3AF] mt-2">{passwordStrength.label}</p>
            <p className="text-xs text-[#9CA3AF] mt-3 leading-relaxed">
              {t('settingsUi.passwordStrengthHint')}
            </p>
          </div>

          <Field label={t('settingsUi.newPassword')}>
            <Input
              name="newPassword"
              type={showPasswords ? 'text' : 'password'}
              value={form.newPassword}
              onChange={handleChange}
              placeholder={t('settingsUi.newPasswordPlaceholder')}
            />
          </Field>

          <Field label={t('settingsUi.confirmNewPassword')}>
            <Input
              name="confirmPassword"
              type={showPasswords ? 'text' : 'password'}
              value={form.confirmPassword}
              onChange={handleChange}
              placeholder={t('settingsUi.confirmPasswordPlaceholder')}
            />
            {form.confirmPassword && (
              <p className={`text-xs mt-2 ${passwordsMatch ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                {passwordsMatch ? t('settingsUi.passwordsMatch') : t('settingsUi.passwordsDoNotMatch')}
              </p>
            )}
          </Field>
        </div>

        {passwordError && (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
            {passwordError}
          </div>
        )}

        <div className="flex items-center justify-between flex-wrap gap-3">
          <Btn variant="outline" onClick={() => setShowPasswords((prev) => !prev)}>
            {showPasswords ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showPasswords ? t('settingsUi.hidePasswords') : t('settingsUi.showPasswords')}
          </Btn>

          <div className="flex items-center justify-end gap-3">
            <Btn variant="outline" onClick={handleDiscardPassword}>
              Discard
            </Btn>
            <Btn onClick={handleSavePassword} loading={isPasswordSaving} disabled={isPasswordSaving}>
              {isPasswordSaving ? 'Saving' : 'Save changes'}
            </Btn>
          </div>
        </div>
      </Section>

      <Section
        title={t('settingsUi.enableTwoFactorTitle')}
        description={t('settingsUi.enableTwoFactorDescription')}
      >
        <Field
          horizontal
          label={t('settingsUi.enableTwoFactorLabel')}
          hint={t('settingsUi.enableTwoFactorHint')}
        >
          <div className="flex items-center gap-2">
            <Toggle checked={effectiveTwoFactorEnabled} onChange={handleTwoFactorToggle} />
            {isTwoFactorLoading && <Loader2 className="w-4 h-4 animate-spin text-[var(--dialogly-accent)]" />}
          </div>
        </Field>

        {twoFactorFlowMode === 'setup' && twoFactorSetup && (
          <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#FCFCFD] dark:bg-[#20242E] p-4 space-y-4">
            <div>
              <p className="text-sm text-[#1A1D23] dark:text-white">{t('settingsUi.scanQr')}</p>
              <p className="text-xs text-[#9CA3AF] mt-1">{t('settingsUi.manualSecretHint')}</p>
            </div>

            <div className="inline-flex rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white p-4">
              <QRCodeSVG value={twoFactorSetup.qrCodeUrl} size={176} />
            </div>

            <div className="rounded-xl bg-[#F9FAFB] dark:bg-[#232833] border border-[#E5E7EB] dark:border-[#343842] px-3.5 py-3">
              <p className="text-xs text-[#9CA3AF]">{t('settingsUi.manualSecretKey')}</p>
              <p className="mt-1 text-sm tracking-[0.2em] text-[#1A1D23] dark:text-white break-all">
                {twoFactorSetup.secret}
              </p>
            </div>

            <Field label={t('settingsUi.enterAppCode')}>
              <Input
                value={twoFactorCode}
                onChange={(event) => setTwoFactorCode(event.target.value)}
                placeholder="123456"
              />
            </Field>

            {twoFactorError && (
              <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
                {twoFactorError}
              </div>
            )}

            <div className="flex items-center gap-3">
              <Btn onClick={handleConfirmTwoFactorSetup} loading={isTwoFactorLoading}>
                {t('settingsUi.confirmSetup')}
              </Btn>
              <Btn variant="outline" onClick={resetTwoFactorUi}>
                {t('settingsUi.cancel')}
              </Btn>
            </div>
          </div>
        )}

        {twoFactorFlowMode === 'disable' && effectiveTwoFactorEnabled && (
          <div className="space-y-4">
            <Field label={t('settingsUi.disableTwoFactorPrompt')}>
              <Input
                value={twoFactorCode}
                onChange={(event) => setTwoFactorCode(event.target.value)}
                placeholder="123456"
              />
            </Field>

            {twoFactorError && (
              <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
                {twoFactorError}
              </div>
            )}

            <div className="flex items-center gap-3">
              <Btn variant="outline" onClick={handleDisableTwoFactor} loading={isTwoFactorLoading}>
                {t('settingsUi.disableTwoFactor')}
              </Btn>
              <Btn variant="outline" onClick={resetTwoFactorUi}>
                {t('settingsUi.cancel')}
              </Btn>
            </div>
          </div>
        )}

        {twoFactorFlowMode === 'reenable' && !effectiveTwoFactorEnabled && twoFactorStatus.hasSecret && (
          <div className="space-y-4">
            <Field label={t('settingsUi.reenableTwoFactorPrompt')}>
              <Input
                value={twoFactorCode}
                onChange={(event) => setTwoFactorCode(event.target.value)}
                placeholder="123456"
              />
            </Field>

            {twoFactorError && (
              <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
                {twoFactorError}
              </div>
            )}

            <div className="flex items-center gap-3">
              <Btn onClick={handleEnableTwoFactor} loading={isTwoFactorLoading}>
                {t('settingsUi.enableTwoFactor')}
              </Btn>
              <Btn variant="outline" onClick={resetTwoFactorUi}>
                {t('settingsUi.cancel')}
              </Btn>
            </div>
          </div>
        )}
      </Section>

      <Section
        title={t('settingsUi.loginAlertsTitle')}
        description={t('settingsUi.loginAlertsDescription')}
      >
        <Field
          horizontal
          label={t('settingsUi.emailMeAboutLogins')}
          hint={t('settingsUi.emailMeAboutLoginsHint')}
        >
          {isLoginAlertsSaving ? (
            <Loader2 className="w-4 h-4 animate-spin text-[var(--dialogly-accent)]" />
          ) : (
            <Toggle
              checked={securitySettings.loginAlertsEnabled}
              onChange={(value) => void handleToggleLoginAlerts(value)}
            />
          )}
        </Field>
      </Section>

    </div>
  );
}

export default SecuritySettings;
