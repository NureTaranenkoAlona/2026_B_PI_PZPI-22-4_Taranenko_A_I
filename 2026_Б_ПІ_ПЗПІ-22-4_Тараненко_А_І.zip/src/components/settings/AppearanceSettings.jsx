import { useMemo, useState } from 'react';
import { Check } from 'lucide-react';
import { useAppPreferences } from '../../context/AppPreferencesContext';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { Field, SaveBar, Section, Toggle } from './shared';

const themeOptions = ['Light', 'Dark', 'System'];
const densityOptions = ['Compact', 'Comfortable', 'Spacious'];
function OptionGrid({ options, value, onChange, getLabel }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {options.map((option) => {
        const active = option === value;
        return (
          <button
            key={option}
            type="button"
            onClick={() => onChange(option)}
            className={`px-4 py-3 rounded-2xl border text-left transition-colors ${
              active
                ? 'border-[var(--dialogly-accent)] bg-[var(--dialogly-accent-soft)] text-[var(--dialogly-accent)] dark:bg-[var(--dialogly-accent-soft-dark)]'
                : 'border-[#E5E7EB] dark:border-[#343842] bg-[#FCFCFD] dark:bg-[#20242E] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833]'
            }`}
          >
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm">{getLabel ? getLabel(option) : option}</span>
              {active && <Check className="w-4 h-4" />}
            </div>
          </button>
        );
      })}
    </div>
  );
}

function AppearanceSettings() {
  const { appearanceSettings, setAppearanceSettings, accentOptions, densityOptions, typographyOptions } = useAppPreferences();
  const { t } = useAppLanguage();
  const initialState = useMemo(
    () => ({
      theme: 'System',
      accent: appearanceSettings.accent,
      density: appearanceSettings.density,
      typography: appearanceSettings.typography,
      collapseSidebar: false,
      animations: true,
    }),
    [appearanceSettings.accent, appearanceSettings.density, appearanceSettings.typography]
  );
  const [settings, setSettings] = useState(initialState);
  const [isSaving, setIsSaving] = useState(false);

  const updateSetting = (key, value) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    setIsSaving(true);

    if (settings.theme === 'Dark') {
      document.documentElement.classList.add('dark');
    } else if (settings.theme === 'Light') {
      document.documentElement.classList.remove('dark');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', prefersDark);
    }

    setTimeout(() => {
      setAppearanceSettings({
        accent: settings.accent,
        density: settings.density,
        typography: settings.typography,
      });
      setIsSaving(false);
    }, 900);
  };

  const handleDiscard = () => {
    setSettings(initialState);
  };

  const getAccentLabel = (accentName) => {
    const key = `settingsUi.accent${accentName}`;
    return t(key);
  };

  const getTypographyLabel = (option) => {
    const key = `settingsUi.typography${option}`;
    return t(key);
  };

  return (
    <div className="space-y-6">
      <Section title={t('settingsUi.appearanceThemeTitle')} description={t('settingsUi.appearanceThemeDescription')}>
        <OptionGrid
          options={themeOptions}
          value={settings.theme}
          onChange={(value) => updateSetting('theme', value)}
          getLabel={(option) => t(`settingsUi.${option.toLowerCase()}`)}
        />
      </Section>

      <Section title={t('settingsUi.appearanceAccentTitle')} description={t('settingsUi.appearanceAccentDescription')}>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {accentOptions.map((accent) => {
            const active = settings.accent === accent.name;

            return (
              <button
                key={accent.name}
                type="button"
                onClick={() => updateSetting('accent', accent.name)}
                className={`px-4 py-3 rounded-2xl border text-left transition-colors ${
                  active
                    ? 'border-[var(--dialogly-accent)] bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)]'
                    : 'border-[#E5E7EB] dark:border-[#343842] bg-[#FCFCFD] dark:bg-[#20242E]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className="w-4 h-4 rounded-full border border-white/60"
                    style={{ backgroundColor: accent.color }}
                  />
                  <span className="text-sm text-[#374151] dark:text-[#D1D5DB]">{getAccentLabel(accent.name)}</span>
                </div>
              </button>
            );
          })}
        </div>
      </Section>

      <Section title={t('settingsUi.appearanceDensityTitle')} description={t('settingsUi.appearanceDensityDescription')}>
        <OptionGrid
          options={densityOptions}
          value={settings.density}
          onChange={(value) => updateSetting('density', value)}
          getLabel={(option) => t(`settingsUi.${option.toLowerCase()}`)}
        />
      </Section>

      <Section title={t('settingsUi.appearanceTypographyTitle')} description={t('settingsUi.appearanceTypographyDescription')}>
        <OptionGrid
          options={typographyOptions}
          value={settings.typography}
          onChange={(value) => updateSetting('typography', value)}
          getLabel={getTypographyLabel}
        />
      </Section>

      <Section
        title={t('settingsUi.appearanceAdditionalTitle')}
        description={t('settingsUi.appearanceAdditionalDescription')}
      >
        <div className="space-y-4">
          <Field
            horizontal
            label={t('settingsUi.collapseSidebar')}
            hint={t('settingsUi.collapseSidebarHint')}
          >
            <Toggle
              checked={settings.collapseSidebar}
              onChange={(value) => updateSetting('collapseSidebar', value)}
            />
          </Field>
          <Field
            horizontal
            label={t('settingsUi.enableAnimations')}
            hint={t('settingsUi.enableAnimationsHint')}
          >
            <Toggle checked={settings.animations} onChange={(value) => updateSetting('animations', value)} />
          </Field>
        </div>

        <SaveBar loading={isSaving} onSave={handleSave} onDiscard={handleDiscard} />
      </Section>
    </div>
  );
}

export default AppearanceSettings;
