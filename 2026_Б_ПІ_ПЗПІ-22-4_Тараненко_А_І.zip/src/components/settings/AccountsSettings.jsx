import { Building2, Check, User } from 'lucide-react';

import { Section } from './shared';
import { useAccountContext } from '../../context/AccountContext';
import { useAppLanguage } from '../../context/AppLanguageContext';

function AccountsSettings() {
  const { contexts, activeContext, switchContext } = useAccountContext();
  const { t } = useAppLanguage();

  return (
    <div className="space-y-5">
      <Section
        title={t('settingsUi.accountsTitle')}
        description={t('settingsUi.accountsDescription')}
      >
        <div className="rounded-2xl border border-[#D9E3FF] dark:border-[#2E3A59] bg-gradient-to-br from-[#EEF4FF] to-[#F8FAFF] dark:from-[#1D2635] dark:to-[#18202D] p-4">
          <p className="text-sm text-[#111827] dark:text-white">{t('settingsUi.currentActiveAccount')}</p>
          <p className="mt-1 text-sm text-[#52607A] dark:text-[#A8B3C7]">
            {activeContext?.type === 'personal'
              ? t('settingsUi.personalAccount')
              : activeContext?.workspace?.name || activeContext?.label}
          </p>
        </div>

        <div className="space-y-3">
          {contexts.map((context) => {
            const isActive = context.id === activeContext?.id;
            const Icon = context.type === 'personal' ? User : Building2;

            return (
              <div
                key={context.id}
                className="flex items-center gap-4 rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4"
              >
                <div className="w-11 h-11 rounded-2xl bg-[#EEF2FF] dark:bg-[#232842] text-[var(--dialogly-accent)] flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-sm text-[#111827] dark:text-white truncate">
                    {context.type === 'personal'
                      ? t('settingsUi.personalAccount')
                      : context.workspace?.name || context.label}
                  </p>
                  <p className="text-xs text-[#9CA3AF] mt-0.5 truncate">
                    {context.type === 'personal'
                      ? t('settingsUi.personalChannelsDescription')
                      : t('settingsUi.workspaceAccessDescription', { role: context.role })}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => switchContext(context.id)}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm transition-colors ${
                    isActive
                      ? 'bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] text-[var(--dialogly-accent)]'
                      : 'border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#1C1F26] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833]'
                  }`}
                >
                  {isActive && <Check className="w-4 h-4" />}
                  {isActive ? t('settingsUi.activeBadge') : t('settingsUi.switch')}
                </button>
              </div>
            );
          })}
        </div>
      </Section>
    </div>
  );
}

export default AccountsSettings;
