﻿import { useEffect, useMemo, useState } from 'react';
import { Camera, Mail, ShieldAlert, Trash2, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Btn, Divider, Field, Input, SaveBar, Section } from './shared';
import { getProfileInitials, getStoredProfile, saveStoredProfile } from '../../utils/profileStorage';
import { getCurrentUser, updateCurrentUserProfile } from '../../api/userApi';
import {
  confirmAccountDeletion,
  requestAccountDeletionCode,
  resendAccountDeletionCode,
} from '../../api/authApi';
import getApiErrorMessage from '../../utils/getApiErrorMessage';
import { useToast } from '../../context/ToastContext';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { useAuth } from '../../context/AuthContext';

const emptyForm = {
  firstName: '',
  lastName: '',
  email: '',
};

const DELETE_RESEND_COOLDOWN_SECONDS = 60;

function ProfileSettings() {
  const { t } = useAppLanguage();
  const { showSuccess, showError } = useToast();
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [pageError, setPageError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [avatarPreview, setAvatarPreview] = useState('');
  const [initialAvatarPreview, setInitialAvatarPreview] = useState('');
  const [initialForm, setInitialForm] = useState(emptyForm);
  const [form, setForm] = useState(emptyForm);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteStep, setDeleteStep] = useState('warning');
  const [deletionCode, setDeletionCode] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [deleteInfo, setDeleteInfo] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [isRequestingDeletionCode, setIsRequestingDeletionCode] = useState(false);
  const [isConfirmingDeletion, setIsConfirmingDeletion] = useState(false);
  const [isResendingDeletionCode, setIsResendingDeletionCode] = useState(false);

  const isDeleteBusy = isRequestingDeletionCode || isConfirmingDeletion || isResendingDeletionCode;

  const isDirty = useMemo(
    () => form.firstName !== initialForm.firstName
      || form.lastName !== initialForm.lastName
      || avatarPreview !== initialAvatarPreview,
    [avatarPreview, form, initialAvatarPreview, initialForm]
  );

  useEffect(() => {
    const loadProfile = async () => {
      setIsLoading(true);
      setPageError('');

      try {
        const currentUser = await getCurrentUser();
        const nextForm = {
          firstName: currentUser.firstName || '',
          lastName: currentUser.lastName || '',
          email: currentUser.email || '',
        };

        setInitialForm(nextForm);
        setForm(nextForm);
        const storedProfile = getStoredProfile();
        const nextAvatar = storedProfile.avatar || '';

        setAvatarPreview(nextAvatar);
        setInitialAvatarPreview(nextAvatar);
        saveStoredProfile({
          ...storedProfile,
          firstName: nextForm.firstName,
          lastName: nextForm.lastName,
          email: nextForm.email,
        });
      } catch (error) {
        setPageError(getApiErrorMessage(error, 'Unable to load your profile.'));
      } finally {
        setIsLoading(false);
      }
    };

    loadProfile();
  }, []);

  useEffect(() => {
    if (!isDeleteModalOpen || resendCooldown <= 0) {
      return undefined;
    }

    const timerId = window.setTimeout(() => {
      setResendCooldown((prev) => Math.max(prev - 1, 0));
    }, 1000);

    return () => window.clearTimeout(timerId);
  }, [isDeleteModalOpen, resendCooldown]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setSuccessMessage('');
  };

  const handleAvatarChange = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        setAvatarPreview(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!isDirty) return;

    setIsSaving(true);
    setPageError('');
    setSuccessMessage('');

    try {
      const hasProfileFieldChanges =
        form.firstName !== initialForm.firstName || form.lastName !== initialForm.lastName;

      let nextForm = initialForm;

      if (hasProfileFieldChanges) {
        const updatedUser = await updateCurrentUserProfile({
          firstName: form.firstName,
          lastName: form.lastName,
        });

        nextForm = {
          firstName: updatedUser.firstName || '',
          lastName: updatedUser.lastName || '',
          email: updatedUser.email || '',
        };
      }

      setInitialForm(nextForm);
      setForm(nextForm);
      setInitialAvatarPreview(avatarPreview);
      saveStoredProfile({
        ...getStoredProfile(),
        firstName: nextForm.firstName,
        lastName: nextForm.lastName,
        email: nextForm.email,
        avatar: avatarPreview,
      });
      setSuccessMessage('Profile updated.');
      showSuccess('Profile updated');
    } catch (error) {
      const nextError = getApiErrorMessage(error, 'Unable to save your profile.');
      setPageError(nextError);
      showError(nextError);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDiscard = () => {
    setForm(initialForm);
    setAvatarPreview(initialAvatarPreview);
    setSuccessMessage('');
  };

  const resetDeleteFlow = () => {
    setDeleteStep('warning');
    setDeletionCode('');
    setDeleteError('');
    setDeleteInfo('');
    setResendCooldown(0);
  };

  const openDeleteModal = () => {
    resetDeleteFlow();
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    if (isDeleteBusy) return;
    setIsDeleteModalOpen(false);
    resetDeleteFlow();
  };

  const handleRequestDeletionCode = async () => {
    setIsRequestingDeletionCode(true);
    setDeleteError('');
    setDeleteInfo('');

    try {
      const response = await requestAccountDeletionCode();
      setDeleteStep('code');
      setDeleteInfo(response?.message || 'We sent a confirmation code to your email.');
      setResendCooldown(DELETE_RESEND_COOLDOWN_SECONDS);
    } catch (error) {
      const nextError = getApiErrorMessage(error, 'Something went wrong. Please try again.');
      setDeleteError(nextError);
      showError(nextError);
    } finally {
      setIsRequestingDeletionCode(false);
    }
  };

  const handleResendDeletionCode = async () => {
    if (resendCooldown > 0) return;

    setIsResendingDeletionCode(true);
    setDeleteError('');
    setDeleteInfo('');

    try {
      const response = await resendAccountDeletionCode();
      setDeletionCode('');
      setDeleteInfo(response?.message || 'We sent a new confirmation code to your email.');
      setResendCooldown(DELETE_RESEND_COOLDOWN_SECONDS);
    } catch (error) {
      const nextError = getApiErrorMessage(error, 'Something went wrong. Please try again.');
      setDeleteError(nextError);
      showError(nextError);
    } finally {
      setIsResendingDeletionCode(false);
    }
  };

  const handleDeletionCodeChange = (event) => {
    const nextValue = event.target.value.replace(/\D/g, '').slice(0, 6);
    setDeletionCode(nextValue);
    setDeleteError('');
  };

  const handleConfirmDeletion = async () => {
    if (deletionCode.length !== 6) {
      setDeleteError('Enter the 6-digit confirmation code.');
      return;
    }

    setIsConfirmingDeletion(true);
    setDeleteError('');

    try {
      const response = await confirmAccountDeletion(deletionCode);
      const message = response?.message || 'Your account has been deleted.';
      logout();
      navigate('/login', {
        replace: true,
        state: { successMessage: message },
      });
      showSuccess(message);
    } catch (error) {
      const nextError = getApiErrorMessage(error, 'Something went wrong. Please try again.');
      setDeleteError(nextError);
      showError(nextError);
    } finally {
      setIsConfirmingDeletion(false);
    }
  };

  return (
    <>
      <div className="space-y-6">
        <Section
          title={t('profileUi.profilePhotoTitle')}
          description={t('profileUi.profilePhotoDescription')}
        >
          {pageError && (
            <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
              {pageError}
            </div>
          )}

          {successMessage && (
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-400/20 dark:bg-emerald-500/10 dark:text-emerald-300">
              {successMessage}
            </div>
          )}

          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="w-20 h-20 rounded-2xl bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] flex items-center justify-center overflow-hidden border border-[#E5E7EB] dark:border-[#343842]">
              {avatarPreview ? (
                <img src={avatarPreview} alt="Avatar preview" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xl text-[var(--dialogly-accent)]">{getProfileInitials(form)}</span>
              )}
            </div>

            <div className="space-y-2">
              <label className="inline-flex">
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
                <span className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white dark:bg-[#232833] border border-[#E5E7EB] dark:border-[#343842] text-sm text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#1F2430] cursor-pointer transition-colors">
                  <Camera className="w-4 h-4" />
                  {t('profileUi.uploadNewPhoto')}
                </span>
              </label>
              <p className="text-xs text-[#9CA3AF]">
                {t('profileUi.avatarHint')}
              </p>
            </div>
          </div>
        </Section>

        <Section
          title={t('profileUi.personalInfoTitle')}
          description={t('profileUi.personalInfoDescription')}
        >
          {isLoading ? (
            <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] px-4 py-8 text-center text-sm text-[#6B7280] dark:text-[#9CA3AF]">
              {t('profileUi.loadingProfile')}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label={t('auth.firstName')}>
                  <Input name="firstName" value={form.firstName} onChange={handleChange} />
                </Field>
                <Field label={t('auth.lastName')}>
                  <Input name="lastName" value={form.lastName} onChange={handleChange} />
                </Field>
                <Field label={t('profileUi.emailAddress')}>
                  <Input name="email" type="email" value={form.email} readOnly disabled />
                </Field>
              </div>

              <Divider />
              <SaveBar loading={isSaving} onSave={handleSave} onDiscard={handleDiscard} />
            </>
          )}
        </Section>

        <Section
          title={t('profileUi.dangerZoneTitle')}
          description={t('profileUi.dangerZoneDescription')}
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#FEF2F2] dark:bg-[#3A2225] flex items-center justify-center text-[#EF4444] flex-shrink-0">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm text-[#1A1D23] dark:text-white">{t('profileUi.deleteAccount')}</p>
                <p className="text-xs text-[#9CA3AF] mt-1 max-w-xl">
                  {t('profileUi.deleteAccountDescription')}
                </p>
              </div>
            </div>

            <Btn variant="danger" onClick={openDeleteModal}>
              <Trash2 className="w-4 h-4" />
              {t('profileUi.deleteAccount')}
            </Btn>
          </div>
        </Section>
      </div>

      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-[#111827]/60 px-4">
          <div className="w-full max-w-md rounded-3xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#1C1F26] shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-[#F3F4F6] dark:border-[#2F3440] px-6 py-5">
              <div>
                <h3 className="text-base text-[#1A1D23] dark:text-white">{t('profileUi.deleteAccountModalTitle')}</h3>
                <p className="mt-1 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                  {deleteStep === 'warning'
                    ? t('profileUi.deleteAccountModalDescription')
                    : t('profileUi.deleteAccountModalCodeDescription')}
                </p>
              </div>
              <button
                type="button"
                onClick={closeDeleteModal}
                disabled={isDeleteBusy}
                className="rounded-xl p-2 text-[#9CA3AF] hover:bg-[#F3F4F6] disabled:cursor-not-allowed disabled:opacity-60 dark:hover:bg-[#232833] transition-colors"
                aria-label={t('profileUi.closeDeleteModal')}
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-4 px-6 py-5">
              {deleteStep === 'warning' ? (
                <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-4 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
                  <p className="font-medium">{t('profileUi.irreversible')}</p>
                  <p className="mt-1">
                    {t('profileUi.deleteWarningBody')}
                  </p>
                </div>
              ) : (
                <>
                  <div className="rounded-2xl border border-[#E5E7EB] bg-[#F9FAFB] px-4 py-3 text-sm text-[#374151] dark:border-[#343842] dark:bg-[#232833] dark:text-[#D1D5DB]">
                    <div className="flex gap-3">
                      <Mail className="mt-0.5 h-4 w-4 text-[var(--dialogly-accent)]" />
                      <p>{deleteInfo || t('profileUi.confirmationCodeSent')}</p>
                    </div>
                  </div>

                  <Field label={t('profileUi.confirmationCode')}>
                    <Input
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      value={deletionCode}
                      onChange={handleDeletionCodeChange}
                      placeholder="123456"
                      autoFocus
                    />
                  </Field>
                </>
              )}

              {deleteError && (
                <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
                  {deleteError}
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3 border-t border-[#F3F4F6] dark:border-[#2F3440] px-6 py-5">
              <Btn variant="outline" onClick={closeDeleteModal} disabled={isDeleteBusy}>
                Cancel
              </Btn>

              {deleteStep === 'warning' ? (
                <Btn
                  variant="danger"
                  onClick={handleRequestDeletionCode}
                  disabled={isRequestingDeletionCode}
                  loading={isRequestingDeletionCode}
                >
                  Send confirmation code
                </Btn>
              ) : (
                <>
                  <Btn
                    variant="outline"
                    onClick={handleResendDeletionCode}
                    disabled={resendCooldown > 0 || isResendingDeletionCode || isConfirmingDeletion}
                    loading={isResendingDeletionCode}
                  >
                    {resendCooldown > 0 ? `Resend code (${resendCooldown}s)` : 'Resend code'}
                  </Btn>
                  <Btn
                    variant="danger"
                    onClick={handleConfirmDeletion}
                    disabled={isConfirmingDeletion}
                    loading={isConfirmingDeletion}
                  >
                    <>
                      {!isConfirmingDeletion && <Trash2 className="w-4 h-4" />}
                      {isConfirmingDeletion ? 'Deleting...' : 'Confirm deletion'}
                    </>
                  </Btn>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default ProfileSettings;
