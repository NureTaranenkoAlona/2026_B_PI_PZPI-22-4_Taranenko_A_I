import { useMemo, useState } from 'react';
import { useAppLanguage } from '../../context/AppLanguageContext';
import { Field, SaveBar, Section, Toggle } from './shared';
import { useToast } from '../../context/ToastContext';

const readSavedChannels = () => ({
  emailNotifications: true,
  desktopPush: localStorage.getItem('dialogly_push') === 'true',
  soundAlerts: localStorage.getItem('dialogly_sound') === 'true',
  newMessagePush: localStorage.getItem('dialogly_push') === 'true',
  newMessageSound: localStorage.getItem('dialogly_sound') === 'true',
  quietHoursEnabled: false,
  quietStart: '22:00',
  quietEnd: '08:00',
});

function NotificationsSettings() {
  const { showSuccess, showError } = useToast();
  const { t } = useAppLanguage();
  const [isSaving, setIsSaving] = useState(false);
  const [savedChannels, setSavedChannels] = useState(readSavedChannels);
  const [channels, setChannels] = useState(readSavedChannels);
  const [pageError, setPageError] = useState('');

  const isDirty = useMemo(
    () =>
      channels.desktopPush !== savedChannels.desktopPush
      || channels.soundAlerts !== savedChannels.soundAlerts
      || channels.newMessagePush !== savedChannels.newMessagePush
      || channels.newMessageSound !== savedChannels.newMessageSound
      || channels.quietHoursEnabled !== savedChannels.quietHoursEnabled
      || channels.quietStart !== savedChannels.quietStart
      || channels.quietEnd !== savedChannels.quietEnd,
    [channels, savedChannels]
  );

  const handleChannelToggle = async (key, value) => {
    if (key === 'desktopPush' && value) {
      if (!('Notification' in window)) {
        showError('Browser notifications are not supported in this browser');
        return;
      }

      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        showError('Please allow notifications in browser settings');
        return;
      }
    }

    setChannels((prev) => ({ ...prev, [key]: value }));
  };

  const handleTimeChange = (event) => {
    const { name, value } = event.target;
    setChannels((prev) => ({ ...prev, [name]: value }));
  };

  const handleEventToggle = (eventKey, channelKey, value) => {
    setEvents((prev) => ({
      ...prev,
      [eventKey]: {
        ...prev[eventKey],
        [channelKey]: value,
      },
    }));
  };

  const handleSave = async () => {
    setPageError('');
    setIsSaving(true);

    try {
      const nextSavedChannels = {
        ...channels,
        desktopPush: channels.desktopPush || channels.newMessagePush,
        soundAlerts: channels.soundAlerts || channels.newMessageSound,
      };

      localStorage.setItem('dialogly_push', String(nextSavedChannels.desktopPush));
      localStorage.setItem('dialogly_sound', String(nextSavedChannels.soundAlerts));
      setSavedChannels(nextSavedChannels);
      setChannels(nextSavedChannels);
      showSuccess('Settings saved');
    } catch {
      const nextError = 'Unable to save notification settings.';
      setPageError(nextError);
      showError(nextError);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDiscard = () => {
    setChannels(savedChannels);
    setPageError('');
  };

  return (
    <div className="space-y-6">
      <Section
        title={t('settingsUi.notificationChannelsTitle')}
        description={t('settingsUi.notificationChannelsDescription')}
      >
        {pageError && (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 dark:border-rose-400/20 dark:bg-rose-500/10 dark:text-rose-300">
            {pageError}
          </div>
        )}

        <div className="space-y-4">
          <Field
            horizontal
            label={t('settingsUi.emailNotifications')}
            hint={t('settingsUi.emailNotificationsHint')}
          >
            <Toggle
              checked={channels.emailNotifications}
              onChange={(value) => handleChannelToggle('emailNotifications', value)}
            />
          </Field>

          <Field
            horizontal
            label={t('settingsUi.browserPush')}
            hint={t('settingsUi.browserPushHint')}
          >
            <Toggle
              checked={channels.desktopPush}
              onChange={(value) => void handleChannelToggle('desktopPush', value)}
            />
          </Field>

          <Field
            horizontal
            label={t('settingsUi.soundAlerts')}
            hint={t('settingsUi.soundAlertsHint')}
          >
            <Toggle
              checked={channels.soundAlerts}
              onChange={(value) => void handleChannelToggle('soundAlerts', value)}
            />
          </Field>
        </div>
      </Section>

      <Section
        title={t('settingsUi.newMessageNotificationsTitle')}
        description={t('settingsUi.newMessageNotificationsDescription')}
      >
        <div className="space-y-4">
          <Field
            horizontal
            label={t('settingsUi.pushNotification')}
            hint={t('settingsUi.pushNotificationHint')}
          >
            <Toggle
              checked={channels.newMessagePush}
              onChange={(value) => void handleChannelToggle('newMessagePush', value)}
            />
          </Field>

          <Field
            horizontal
            label={t('settingsUi.sound')}
            hint={t('settingsUi.soundHint')}
          >
            <Toggle
              checked={channels.newMessageSound}
              onChange={(value) => void handleChannelToggle('newMessageSound', value)}
            />
          </Field>
        </div>
      </Section>

      <Section
        title={t('settingsUi.quietHoursTitle')}
        description={t('settingsUi.quietHoursDescription')}
      >
        <div className="space-y-4">
          <Field
            horizontal
            label={t('settingsUi.enableQuietHours')}
            hint={t('settingsUi.enableQuietHoursHint')}
          >
            <Toggle
              checked={channels.quietHoursEnabled}
              onChange={(value) => void handleChannelToggle('quietHoursEnabled', value)}
            />
          </Field>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label={t('settingsUi.startTime')}>
              <input
                type="time"
                name="quietStart"
                value={channels.quietStart}
                onChange={handleTimeChange}
                disabled={!channels.quietHoursEnabled}
                className="w-full px-3.5 py-2.5 bg-[#F9FAFB] dark:bg-[#232833] border border-[#E5E7EB] dark:border-[#343842] rounded-xl text-sm text-[#1A1D23] dark:text-white focus:outline-none focus:border-[var(--dialogly-accent)] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[var(--dialogly-accent-soft)] transition-all disabled:opacity-50"
              />
            </Field>
            <Field label={t('settingsUi.endTime')}>
              <input
                type="time"
                name="quietEnd"
                value={channels.quietEnd}
                onChange={handleTimeChange}
                disabled={!channels.quietHoursEnabled}
                className="w-full px-3.5 py-2.5 bg-[#F9FAFB] dark:bg-[#232833] border border-[#E5E7EB] dark:border-[#343842] rounded-xl text-sm text-[#1A1D23] dark:text-white focus:outline-none focus:border-[var(--dialogly-accent)] focus:bg-white dark:focus:bg-[#1F2430] focus:ring-2 focus:ring-[var(--dialogly-accent-soft)] transition-all disabled:opacity-50"
              />
            </Field>
          </div>
        </div>
        <SaveBar loading={isSaving} onSave={handleSave} onDiscard={handleDiscard} />
      </Section>
    </div>
  );
}

export default NotificationsSettings;
