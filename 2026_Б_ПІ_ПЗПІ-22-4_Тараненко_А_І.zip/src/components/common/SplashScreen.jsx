import { useEffect, useState } from 'react';
import AppLogo from './AppLogo';
import { useAppLanguage } from '../../context/AppLanguageContext';

function SplashScreen({ onFinish }) {
  const { t } = useAppLanguage();
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const fadeOutTimer = window.setTimeout(() => {
      setIsExiting(true);
    }, 1000);

    const hideTimer = window.setTimeout(() => {
      onFinish?.();
    }, 1500);

    return () => {
      window.clearTimeout(fadeOutTimer);
      window.clearTimeout(hideTimer);
    };
  }, [onFinish]);

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none fixed inset-0 z-[9999] flex items-center justify-center bg-[radial-gradient(circle_at_top,_rgba(255,255,255,0.18),_transparent_42%),linear-gradient(135deg,#4f5dff_0%,#5b6cf8_42%,#7c3aed_100%)] transition-opacity duration-500 ${
        isExiting ? 'opacity-0' : 'opacity-100'
      }`}
    >
      <div className="flex flex-col items-center justify-center px-6 text-center">
        <div className="animate-[dialoglySplashPulse_1.5s_ease-in-out_infinite]">
          <AppLogo size={84} iconSize={38} className="rounded-[28px] shadow-[0_18px_50px_rgba(15,23,42,0.28)]" />
        </div>

        <div className="mt-7 animate-[dialoglySplashFadeIn_0.3s_ease-out]">
          <h1 className="text-4xl font-semibold tracking-tight text-white sm:text-5xl">
            Dialogly
          </h1>
          <p className="mt-3 text-sm text-white/80 sm:text-base">
            {t('landing.footerTagline')}
          </p>
        </div>
      </div>
    </div>
  );
}

export default SplashScreen;
