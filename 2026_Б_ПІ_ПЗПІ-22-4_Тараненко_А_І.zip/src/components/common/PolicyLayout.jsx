import { Link } from 'react-router-dom';
import AppLogo from './AppLogo';
import useSystemTheme from '../../hooks/useSystemTheme';
import { useAppLanguage } from '../../context/AppLanguageContext';

function PolicyLayout({
  title,
  lastUpdated,
  alternateLink,
  alternateLabel,
  children,
}) {
  useSystemTheme();
  const { t } = useAppLanguage();

  return (
    <div className="min-h-screen bg-[#F5F6FA] text-[#151827] transition-colors dark:bg-[#181A20] dark:text-white">
      <div className="mx-auto max-w-4xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center gap-3">
            <AppLogo size={44} iconSize={20} />
            <span className="text-lg font-semibold tracking-tight">Dialogly</span>
          </Link>
        </div>

        <main className="rounded-[28px] border border-[#E5E7EB] bg-white/90 p-6 shadow-xl shadow-slate-200/40 backdrop-blur dark:border-[#2F3440] dark:bg-[#1C1F26]/95 dark:shadow-black/20 sm:p-8">
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">{lastUpdated}</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">{title}</h1>
          <div className="mt-8 space-y-8 text-sm leading-7 text-[#4B5563] dark:text-[#D1D5DB]">
            {children}
          </div>
        </main>

        <footer className="mt-6 flex flex-col items-center justify-between gap-3 text-sm text-[#6B7280] dark:text-[#9CA3AF] sm:flex-row">
          <Link to="/" className="transition hover:text-[#11131E] dark:hover:text-white">
            {t('miscUi.backToHome')}
          </Link>
          <div className="flex items-center gap-5">
            {alternateLink ? (
              <Link to={alternateLink} className="transition hover:text-[#11131E] dark:hover:text-white">
                {alternateLabel}
              </Link>
            ) : null}
          </div>
        </footer>
      </div>
    </div>
  );
}

export default PolicyLayout;
