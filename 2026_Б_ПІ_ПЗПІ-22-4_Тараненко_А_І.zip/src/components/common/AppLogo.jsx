import { MessageCircle } from 'lucide-react';

function AppLogo({ size = 40, iconSize, className = '' }) {
  const resolvedIconSize = iconSize ?? Math.round(size * 0.46);

  return (
    <div
      className={`rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
    >
      <MessageCircle
        className="text-white"
        fill="white"
        strokeWidth={1.5}
        style={{ width: resolvedIconSize, height: resolvedIconSize }}
      />
    </div>
  );
}

export default AppLogo;
