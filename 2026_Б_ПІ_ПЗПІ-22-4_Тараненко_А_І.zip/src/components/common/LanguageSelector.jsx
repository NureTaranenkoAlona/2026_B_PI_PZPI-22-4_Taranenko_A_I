import { ChevronDown, Languages } from 'lucide-react';
import { useState } from 'react';
import { useAppLanguage } from '../../context/AppLanguageContext';

function LanguageSelector({
  compact = false,
  persistOnChange = true,
  showSubtitle = false,
  className = '',
  allowedLanguages = null,
  inline = false,
}) {
  const { language, setLanguage, languageOptions, t } = useAppLanguage();
  const [open, setOpen] = useState(false);
  const visibleLanguages = allowedLanguages
    ? languageOptions.filter((option) => allowedLanguages.includes(option.code))
    : languageOptions;

  const activeLanguage = visibleLanguages.find((option) => option.code === language) ?? visibleLanguages[0] ?? languageOptions[0];

  if (inline) {
    return (
      <div className={`flex items-center gap-2 text-xs ${className}`}>
        {visibleLanguages.map((option, index) => {
          const active = option.code === language;
          return (
            <span key={option.code} className="flex items-center gap-2">
              {index > 0 ? <span className="text-[#9CA3AF]">|</span> : null}
              <button
                type="button"
                onClick={() => setLanguage(option.code, { persist: persistOnChange })}
                className={`transition-colors ${
                  active
                    ? 'font-semibold text-[var(--dialogly-accent)]'
                    : 'text-[#9CA3AF] hover:text-[#6B7280] dark:hover:text-[#D1D5DB]'
                }`}
              >
                {option.name}
              </button>
            </span>
          );
        })}
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className={`inline-flex items-center gap-2 rounded-xl border border-[#D6DBF8] bg-white/80 px-3 py-2 text-sm text-[#1F2540] transition hover:bg-white dark:border-[#313953] dark:bg-[#171C28] dark:text-white dark:hover:bg-[#1C2230] ${
          compact ? 'min-h-10' : ''
        }`}
      >
        <Languages className="h-4 w-4" />
        <span className="max-w-[140px] truncate">{activeLanguage.name}</span>
        <ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {showSubtitle ? (
        <p className="mt-2 text-right text-xs text-[#7A8093] dark:text-[#97A0B8]">
          {t('language.changeLater')}
        </p>
      ) : null}

      {open ? (
        <>
          <button
            type="button"
            aria-label={t('miscUi.closeLanguageSelector')}
            className="fixed inset-0 z-30 cursor-default"
            onClick={() => setOpen(false)}
          />
          <div className="absolute right-0 z-40 mt-2 max-h-[320px] w-[260px] overflow-y-auto rounded-2xl border border-[#D6DBF8] bg-white/95 p-2 shadow-xl shadow-black/10 backdrop-blur dark:border-[#313953] dark:bg-[#171C28]/95 dark:shadow-black/30">
            <div className="space-y-1">
              {visibleLanguages.map((option) => {
                const active = option.code === language;
                return (
                  <button
                    key={option.code}
                    type="button"
                    onClick={() => {
                      setLanguage(option.code, { persist: persistOnChange });
                      setOpen(false);
                    }}
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-sm transition-colors ${
                      active
                        ? 'bg-[var(--dialogly-accent-soft)] text-[var(--dialogly-accent)] dark:bg-[var(--dialogly-accent-soft-dark)]'
                        : 'text-[#374151] hover:bg-[#F5F6FA] dark:text-[#D1D5DB] dark:hover:bg-[#232833]'
                    }`}
                  >
                    <span>{option.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}

export default LanguageSelector;
