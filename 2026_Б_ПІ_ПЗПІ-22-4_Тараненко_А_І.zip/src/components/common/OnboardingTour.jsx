import { useEffect, useMemo, useState } from 'react';
import { useAppLanguage } from '../../context/AppLanguageContext';

const overlayPadding = 12;
const tooltipWidth = 320;
const tooltipHeight = 180;
const tooltipPadding = 16;
const centeredTooltipStyle = {
  position: 'fixed',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  zIndex: 80,
};

function isUsableRect(rect) {
  if (!rect) return false;

  if (
    rect.top === 0 &&
    rect.left === 0 &&
    rect.width === 0 &&
    rect.height === 0
  ) {
    return false;
  }

  if (rect.width === 0 || rect.height === 0) {
    return false;
  }

  if (
    rect.top < 0 ||
    rect.left < 0 ||
    rect.bottom > window.innerHeight ||
    rect.right > window.innerWidth
  ) {
    return false;
  }

  return true;
}

function getTooltipPosition(rect, placement) {
  if (!isUsableRect(rect)) {
    return centeredTooltipStyle;
  }

  const clampedLeft = Math.min(
    Math.max(rect.left, tooltipPadding),
    window.innerWidth - tooltipWidth - tooltipPadding
  );

  const belowTop = rect.bottom + tooltipPadding;
  const aboveTop = rect.top - tooltipHeight - tooltipPadding;

  const preferredAbove = placement?.startsWith('top');
  const canFitBelow = belowTop + tooltipHeight <= window.innerHeight - tooltipPadding;
  const canFitAbove = aboveTop >= tooltipPadding;

  if (preferredAbove && canFitAbove) {
    return {
      position: 'fixed',
      top: aboveTop,
      left: clampedLeft,
      zIndex: 80,
    };
  }

  if (canFitBelow) {
    return {
      position: 'fixed',
      top: belowTop,
      left: clampedLeft,
      zIndex: 80,
    };
  }

  if (canFitAbove) {
    return {
      position: 'fixed',
      top: aboveTop,
      left: clampedLeft,
      zIndex: 80,
    };
  }

  return centeredTooltipStyle;
}

function HighlightOverlay({ rect }) {
  if (!isUsableRect(rect)) return null;

  return (
    <div
      className="pointer-events-none fixed z-[70] rounded-3xl border border-white/80 shadow-[0_0_0_9999px_rgba(0,0,0,0.5)] transition-all duration-200"
      style={{
        top: rect.top - overlayPadding,
        left: rect.left - overlayPadding,
        width: rect.width + overlayPadding * 2,
        height: rect.height + overlayPadding * 2,
      }}
    />
  );
}

function TourTooltip({ step, stepIndex, totalSteps, onNext, onSkip, isLast }) {
  const { t } = useAppLanguage();
  const position = getTooltipPosition(step.rect, step.placement);

  return (
    <div
      className="fixed z-[80] w-[min(22rem,calc(100vw-2rem))] rounded-3xl bg-white px-5 py-4 shadow-2xl text-[#1A1D23]"
      style={position}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-base font-semibold">{step.title}</p>
          <p className="mt-1 text-sm leading-6 text-[#6B7280]">{step.text}</p>
        </div>
        <button
          type="button"
          onClick={onSkip}
          className="text-sm text-[#9CA3AF] hover:text-[#6B7280] transition-colors"
        >
          {t('tour.skip')}
        </button>
      </div>

      <div className="mt-4 flex items-center justify-between gap-3">
        <span className="text-xs text-[#9CA3AF]">
          {t('tour.stepCount', { current: stepIndex + 1, total: totalSteps })}
        </span>
        <button
          type="button"
          onClick={onNext}
          className="inline-flex items-center justify-center rounded-xl bg-[var(--dialogly-accent)] px-4 py-2 text-sm text-white hover:bg-[var(--dialogly-accent-hover)] transition-colors"
        >
          {isLast ? t('tour.gotIt') : t('tour.next')}
        </button>
      </div>
    </div>
  );
}

function WelcomeModal({ totalSteps, onStart, onSkip }) {
  const { t } = useAppLanguage();
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-[28px] bg-white px-7 py-8 shadow-2xl text-center">
        <p className="text-2xl font-semibold text-[#1A1D23]">{t('tour.welcomeTitle')}</p>
        <p className="mt-3 text-sm leading-6 text-[#6B7280]">
          {t('tour.welcomeDescription')}
        </p>

        <div className="mt-6 flex items-center justify-between gap-3">
          <span className="text-xs text-[#9CA3AF]">{t('tour.stepCount', { current: 1, total: totalSteps })}</span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onSkip}
              className="text-sm text-[#9CA3AF] hover:text-[#6B7280] transition-colors"
            >
              {t('tour.skipTour')}
            </button>
            <button
              type="button"
              onClick={onStart}
              className="inline-flex items-center justify-center rounded-xl bg-[var(--dialogly-accent)] px-4 py-2 text-sm text-white hover:bg-[var(--dialogly-accent-hover)] transition-colors"
            >
              {t('tour.startTour')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function OnboardingTour({ isOpen, steps, currentStep, onNext, onSkip }) {
  const [viewportTick, setViewportTick] = useState(0);

  useEffect(() => {
    if (!isOpen) return undefined;

    const handleViewportChange = () => {
      setViewportTick((value) => value + 1);
    };

    window.addEventListener('resize', handleViewportChange);
    window.addEventListener('scroll', handleViewportChange, true);

    return () => {
      window.removeEventListener('resize', handleViewportChange);
      window.removeEventListener('scroll', handleViewportChange, true);
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return undefined;

    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        onSkip();
      }
    };

    window.addEventListener('keydown', handleEscape);

    return () => {
      window.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onSkip]);

  const resolvedStep = useMemo(() => {
    const step = steps[currentStep];
    if (!step) return null;

    const rawRect = step.getRect ? step.getRect(viewportTick) : null;
    const rect = isUsableRect(rawRect) ? rawRect : null;

    return {
      ...step,
      rect,
    };
  }, [currentStep, steps, viewportTick]);

  if (!isOpen || !resolvedStep) return null;

  const isWelcomeStep = resolvedStep.kind === 'welcome';
  const totalSteps = steps.length;

  return (
    <>
      <div className="fixed inset-0 z-[60] bg-black/50 transition-opacity duration-200" />
      {!isWelcomeStep && <HighlightOverlay rect={resolvedStep.rect} />}
      {isWelcomeStep ? (
        <WelcomeModal totalSteps={totalSteps} onStart={onNext} onSkip={onSkip} />
      ) : (
        <TourTooltip
          step={resolvedStep}
          stepIndex={currentStep}
          totalSteps={totalSteps}
          onNext={onNext}
          onSkip={onSkip}
          isLast={currentStep === totalSteps - 1}
        />
      )}
    </>
  );
}

export default OnboardingTour;
