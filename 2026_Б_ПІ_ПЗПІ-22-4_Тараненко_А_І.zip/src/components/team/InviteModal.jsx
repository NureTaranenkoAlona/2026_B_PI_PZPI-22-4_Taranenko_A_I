import { useMemo, useState } from 'react';
import { Check, Copy, Trash, UserPlus, X } from 'lucide-react';
import { useAppLanguage } from '../../context/AppLanguageContext';

function InviteModal({
  open,
  onClose,
  invites,
  onGenerateInvite,
  onRevokeInvite,
  isLoadingInvites,
  isGeneratingInvite,
  revokingToken,
}) {
  const { t } = useAppLanguage();
  const [role, setRole] = useState('Admin');
  const [generatedInvite, setGeneratedInvite] = useState(null);
  const [copiedValue, setCopiedValue] = useState('');

  const sortedInvites = useMemo(() => [...invites].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [invites]);

  if (!open) return null;

  const handleGenerate = async () => {
    const nextInvite = await onGenerateInvite(role);
    if (nextInvite) {
      setGeneratedInvite(nextInvite);
    }
    setCopiedValue('');
  };

  const handleCopy = async (value) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedValue(value);
      setTimeout(() => {
        setCopiedValue((current) => (current === value ? '' : current));
      }, 1400);
    } catch (error) {
      console.error('Failed to copy invite value', error);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-[#0F1117]/50 backdrop-blur-sm" onClick={onClose} />

      <div className="relative z-10 w-full max-w-3xl rounded-[28px] border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] shadow-2xl shadow-slate-300/30 dark:shadow-black/30 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#F3F4F6] dark:border-[#2F3440]">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] text-[var(--dialogly-accent)] flex items-center justify-center">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
            <h2 className="text-[#1A1D23] dark:text-white">{t('invite.title')}</h2>
            <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                {t('invite.description')}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors flex items-center justify-center"
            aria-label={t('invite.closeModal')}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[1.1fr,0.9fr] gap-0">
          <div className="p-6 border-b lg:border-b-0 lg:border-r border-[#F3F4F6] dark:border-[#2F3440]">
            <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-5">
              <p className="text-sm text-[#1A1D23] dark:text-white mb-1">{t('invite.generateInvite')}</p>
              <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF] mb-4">
                {t('invite.generateInviteDescription')}
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-[#374151] dark:text-[#D1D5DB] mb-1.5">{t('invite.role')}</label>
                  <select
                    value={role}
                    onChange={(event) => setRole(event.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#232833] text-sm text-[#1A1D23] dark:text-white focus:outline-none focus:border-[var(--dialogly-accent)] focus:ring-2 focus:ring-[var(--dialogly-accent-soft)] transition-all"
                  >
                    <option value="Admin">{t('invite.admin')}</option>
                    <option value="Operator">{t('invite.operator')}</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleGenerate}
                  disabled={isGeneratingInvite}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--dialogly-accent)] text-white hover:bg-[var(--dialogly-accent-hover)] transition-colors"
                >
                  <UserPlus className="w-4 h-4" />
                  {isGeneratingInvite ? t('invite.generating') : t('invite.generateInvite')}
                </button>
              </div>
            </div>

            {generatedInvite && (
              <div className="mt-5 rounded-2xl border border-[#D9DEFE] dark:border-[#39427A] bg-[#F5F7FF] dark:bg-[#202746] p-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm text-[#1A1D23] dark:text-white">{t('invite.newInviteCreated')}</p>
                    <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF] mt-0.5">
                      {t('invite.shareLinkOrCode')}
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-white/80 dark:bg-[#1C1F26] text-xs text-[var(--dialogly-accent)] border border-[#D9DEFE] dark:border-[#39427A]">
                    {generatedInvite.role}
                  </span>
                </div>

                <div className="mt-4 space-y-3">
                  <div className="rounded-xl border border-[#D9DEFE] dark:border-[#39427A] bg-white dark:bg-[#1C1F26] px-3.5 py-3">
                    <p className="text-[11px] uppercase tracking-wider text-[#9CA3AF] mb-1">{t('invite.inviteCode')}</p>
                    <div className="flex items-center justify-between gap-3">
                    <p className="text-sm text-[#1A1D23] dark:text-white font-medium tracking-[0.2em]">
                        {generatedInvite.token}
                      </p>
                      <button
                        type="button"
                        onClick={() => handleCopy(generatedInvite.token)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors"
                      >
                        {copiedValue === generatedInvite.token ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedValue === generatedInvite.token ? t('invite.copied') : t('invite.copy')}
                      </button>
                    </div>
                  </div>

                  <div className="rounded-xl border border-[#D9DEFE] dark:border-[#39427A] bg-white dark:bg-[#1C1F26] px-3.5 py-3">
                    <p className="text-[11px] uppercase tracking-wider text-[#9CA3AF] mb-1">{t('invite.inviteLink')}</p>
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-sm text-[#1A1D23] dark:text-white break-all">{generatedInvite.inviteUrl}</p>
                      <button
                        type="button"
                        onClick={() => handleCopy(generatedInvite.inviteUrl)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors flex-shrink-0"
                      >
                        {copiedValue === generatedInvite.inviteUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedValue === generatedInvite.inviteUrl ? t('invite.copied') : t('invite.copy')}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-6">
            <div className="flex items-center justify-between gap-3 mb-4">
              <div>
                <p className="text-sm text-[#1A1D23] dark:text-white">{t('invite.existingInvites')}</p>
                <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                  {t('invite.existingInvitesDescription')}
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-[#F5F6FA] dark:bg-[#232833] text-xs text-[#6B7280] dark:text-[#9CA3AF]">
                {t('invite.totalCount', { count: sortedInvites.length })}
              </span>
            </div>

            <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
              {isLoadingInvites && (
                <div className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                  {t('invite.loadingInvites')}
                </div>
              )}

              {!isLoadingInvites && sortedInvites.length === 0 && (
                <div className="rounded-2xl border border-dashed border-[#D1D5DB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4 text-sm text-[#6B7280] dark:text-[#9CA3AF]">
                  {t('invite.noInvitesYet')}
                </div>
              )}

              {sortedInvites.map((invite) => (
                <div
                  key={invite.token}
                  className="rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-[#F9FAFB] dark:bg-[#20242E] p-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm text-[#1A1D23] dark:text-white font-medium tracking-[0.16em]">
                        {invite.token}
                      </p>
                      <p className="text-xs text-[#6B7280] dark:text-[#9CA3AF] mt-1">
                        {invite.role} • {new Date(invite.createdAt).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </p>
                    </div>

                    <span
                      className={`px-2.5 py-1 rounded-full text-[11px] border flex-shrink-0 ${
                        invite.status === 'Active'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:border-emerald-400/20'
                          : invite.status === 'Used'
                            ? 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-500/10 dark:text-indigo-300 dark:border-indigo-400/20'
                            : 'bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-500/10 dark:text-slate-300 dark:border-slate-400/20'
                      }`}
                    >
                      {invite.status}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-3 mt-3">
                    <p className="text-xs text-[#9CA3AF] truncate flex-1">
                      {invite.inviteUrl}
                    </p>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button
                        type="button"
                        onClick={() => handleCopy(invite.inviteUrl)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-[#374151] dark:text-[#D1D5DB] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors"
                      >
                        {copiedValue === invite.inviteUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedValue === invite.inviteUrl ? t('invite.copied') : t('invite.copy')}
                      </button>

                      {invite.status === 'Active' && (
                        <button
                          type="button"
                          onClick={() => onRevokeInvite(invite.token)}
                          disabled={revokingToken === invite.token}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs border border-[#FCA5A5] text-[#DC2626] hover:bg-[#FEF2F2] dark:hover:bg-[#3A1F24] transition-colors flex-shrink-0 disabled:opacity-60 disabled:cursor-not-allowed"
                        >
                          <Trash className="w-3.5 h-3.5" />
                          {revokingToken === invite.token ? t('invite.revoking') : t('invite.revoke')}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default InviteModal;
