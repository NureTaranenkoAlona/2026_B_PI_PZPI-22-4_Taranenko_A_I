import { MoreVertical, Trash } from 'lucide-react';
import RoleBadge from './RoleBadge';
import { useAppLanguage } from '../../context/AppLanguageContext';

function getStatusClasses(status) {
  if (status === 'Active') {
    return 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:border-emerald-400/20';
  }

  return 'bg-slate-50 text-slate-700 border border-slate-200 dark:bg-slate-500/10 dark:text-slate-300 dark:border-slate-400/20';
}

function getInitials(name) {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toUpperCase();
}

function MemberItem({
  member,
  isMenuOpen,
  onToggleMenu,
  onCloseMenu,
  onRemove,
  canManage,
}) {
  const { t } = useAppLanguage();
  return (
    <div className="relative rounded-2xl border border-[#E5E7EB] dark:border-[#2F3440] bg-white dark:bg-[#1C1F26] px-5 py-4 shadow-sm shadow-slate-200/40 dark:shadow-none">
      <div className="flex items-start gap-4">
        <div className="w-11 h-11 rounded-2xl bg-[var(--dialogly-accent-soft)] dark:bg-[var(--dialogly-accent-soft-dark)] text-[var(--dialogly-accent)] flex items-center justify-center text-sm flex-shrink-0">
          {getInitials(member.name)}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-sm text-[#1A1D23] dark:text-white truncate">{member.name}</p>
            {member.isCurrentUser && (
              <span className="px-2 py-0.5 rounded-full bg-[#EEF0FE] text-[#5B6CF8] text-[10px] border border-[#D9DEFE] dark:bg-[#232842] dark:border-[#39427A] dark:text-[#AEB7FF]">
                {t('common.you') ?? 'You'}
              </span>
            )}
          </div>
          <p className="text-sm text-[#6B7280] dark:text-[#9CA3AF] truncate mt-0.5">{member.email}</p>

          <div className="flex items-center gap-2 flex-wrap mt-3">
            <RoleBadge role={member.role} />
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs ${getStatusClasses(member.status)}`}>
              <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
              {member.status}
            </span>
          </div>
        </div>

        {canManage && (
          <button
            type="button"
            onClick={onToggleMenu}
            className="w-9 h-9 rounded-xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] text-[#6B7280] dark:text-[#9CA3AF] hover:bg-[#F9FAFB] dark:hover:bg-[#232833] transition-colors flex items-center justify-center flex-shrink-0"
            aria-label={t('miscUi.openMemberActions')}
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        )}
      </div>

      {canManage && isMenuOpen && (
        <div className="absolute top-14 right-5 z-20 w-48 rounded-2xl border border-[#E5E7EB] dark:border-[#343842] bg-white dark:bg-[#20242E] shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-2">
          <button
            type="button"
            onClick={() => {
              onRemove(member.userId);
              onCloseMenu();
            }}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm text-[#DC2626] hover:bg-[#FEF2F2] dark:hover:bg-[#3A1F24] transition-colors"
          >
            <Trash className="w-4 h-4" />
            {t('team.removeMember') ?? 'Remove member'}
          </button>
        </div>
      )}
    </div>
  );
}

export default MemberItem;
