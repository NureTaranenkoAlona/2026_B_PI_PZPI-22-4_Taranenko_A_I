import { Crown, Shield, Users } from 'lucide-react';
import { useAppLanguage } from '../../context/AppLanguageContext';

const roleConfig = {
  Owner: {
    icon: Crown,
    className:
      'bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:border-amber-400/20',
  },
  Admin: {
    icon: Shield,
    className:
      'bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-500/10 dark:text-indigo-300 dark:border-indigo-400/20',
  },
  Operator: {
    icon: Users,
    className:
      'bg-slate-50 text-slate-700 border border-slate-200 dark:bg-slate-500/10 dark:text-slate-300 dark:border-slate-400/20',
  },
};

function RoleBadge({ role }) {
  const { t } = useAppLanguage();
  const config = roleConfig[role] || roleConfig.Operator;
  const Icon = config.icon;
  const label = role === 'Owner'
    ? t('team.owner')
    : role === 'Admin'
      ? t('invite.admin')
      : t('invite.operator');

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs ${config.className}`}
    >
      <Icon className="w-3.5 h-3.5" />
      {label}
    </span>
  );
}

export default RoleBadge;
