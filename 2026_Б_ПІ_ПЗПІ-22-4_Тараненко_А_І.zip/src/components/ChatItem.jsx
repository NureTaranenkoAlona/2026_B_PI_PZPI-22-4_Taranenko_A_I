const badgeStyles = {
  Telegram: {
    backgroundColor: '#e6f4ff',
    color: '#0b69c7',
  },
  Messenger: {
    backgroundColor: '#f3e8ff',
    color: '#7a22ce',
  },
};

function ChatItem({ title, platform }) {
  const currentBadgeStyle = badgeStyles[platform] || {
    backgroundColor: '#f3f4f6',
    color: '#374151',
  };

  return (
    <div
      style={{
        padding: '12px 14px',
        borderBottom: '1px solid #eee',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '12px',
      }}
    >
      <span
        style={{
          fontSize: '14px',
          fontWeight: 500,
          color: '#111827',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}
      >
        {title}
      </span>

      <span
        style={{
          ...currentBadgeStyle,
          flexShrink: 0,
          padding: '4px 8px',
          borderRadius: '999px',
          fontSize: '12px',
          fontWeight: 600,
          lineHeight: 1,
        }}
      >
        {platform}
      </span>
    </div>
  );
}

export default ChatItem;
