import { useEffect, useState } from 'react';

const mediaQuery = '(prefers-color-scheme: dark)';

function getSystemDarkMode() {
  if (typeof window === 'undefined') return false;
  return window.matchMedia(mediaQuery).matches;
}

function useSystemTheme() {
  const [isDarkMode, setIsDarkMode] = useState(getSystemDarkMode);

  useEffect(() => {
    const matcher = window.matchMedia(mediaQuery);

    const handleChange = (event) => {
      setIsDarkMode(event.matches);
    };

    setIsDarkMode(matcher.matches);
    matcher.addEventListener('change', handleChange);

    return () => {
      matcher.removeEventListener('change', handleChange);
    };
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode);
  }, [isDarkMode]);
}

export default useSystemTheme;
