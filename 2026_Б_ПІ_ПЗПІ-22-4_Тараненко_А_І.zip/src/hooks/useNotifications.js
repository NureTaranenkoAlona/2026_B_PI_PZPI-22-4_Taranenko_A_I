import { useCallback, useMemo } from 'react';

export const useNotifications = () => {
  const soundEnabled = localStorage.getItem('dialogly_sound') === 'true';
  const pushEnabled = localStorage.getItem('dialogly_push') === 'true';

  const playSound = useCallback(() => {
    if (!soundEnabled) return;

    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;

      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.setValueAtTime(660, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

      osc.start();
      osc.stop(ctx.currentTime + 0.4);

      window.setTimeout(() => {
        ctx.close().catch(() => {});
      }, 500);
    } catch {}
  }, [soundEnabled]);

  const showPushNotification = useCallback((title, body) => {
    if (!pushEnabled) return;
    if (!('Notification' in window)) return;
    if (Notification.permission === 'granted') {
      new Notification(title, { body });
    }
  }, [pushEnabled]);

  const playLoginSound = useCallback(() => {
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;

      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.frequency.setValueAtTime(523, ctx.currentTime);
      osc.frequency.setValueAtTime(659, ctx.currentTime + 0.15);
      osc.frequency.setValueAtTime(784, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);

      osc.start();
      osc.stop(ctx.currentTime + 0.5);

      window.setTimeout(() => {
        ctx.close().catch(() => {});
      }, 600);
    } catch {}
  }, []);

  return useMemo(() => ({
    playSound,
    showPushNotification,
    playLoginSound,
  }), [playLoginSound, playSound, showPushNotification]);
};

export default useNotifications;
